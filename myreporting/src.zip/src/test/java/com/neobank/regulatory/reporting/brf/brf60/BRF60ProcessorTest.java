package com.neobank.regulatory.reporting.brf.brf60;

import com.neobank.regulatory.reporting.config.BanksOwnedFundAccountsConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.entity.MainAccountProductId;
import com.neobank.regulatory.reporting.entity.ProductBookValueInfo;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.ProductBookValueRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.util.ConfigUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class BRF60ProcessorTest {

    private static final double DEFAULT_CLOSING_BALANCE = 99.99d;
    static BanksOwnedFundAccountsConfig banksOwnedFundAccountsConfig;

    static {
        banksOwnedFundAccountsConfig = ConfigUtil.read("mapping/banks-owned-fund-accounts.yml",
                "banks-owned-fund-accounts", BanksOwnedFundAccountsConfig.class);

    }

    Workbook wb;
    TransformationContext payloadData;
    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @InjectMocks
    BRF60Processor brf60Processor;

    @Mock
    private AccountClosingBalanceRepository accountClosingBalanceRepository;

    @Mock
    private ProductBookValueRepository productBookValueRepository;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-060.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("060", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
        //
        BRF60Transformer brf60Transformer = Mockito.spy(new BRF60Transformer());
        //
        brf60Processor = new BRF60Processor(brf60Transformer, accountClosingBalanceRepository,
                productBookValueRepository, banksOwnedFundAccountsConfig, new AccountsClosingBalanceService());
    }

    @Test
    void mustPassValidRequest() {
        assertNotNull(brf60Processor);

        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(banksOwnedFundAccountsConfig.getBanksOwnedFundBalanceKeys()));
        Mockito.when(productBookValueRepository.getCountAndTotalBookValueByProduct(Mockito.any(), Mockito.any()))
                .thenReturn(bookValueForProducts());

        brf60Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);

        var cell = getCellByReference(sheet, "D11");
        assertEquals(4, cell.getNumericCellValue(), "D11 must be equal");

        cell = getCellByReference(sheet, "E11");
        assertEquals(149877693.67, cell.getNumericCellValue(), "E11 must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());

        cell = getCellByReference(sheet, "D16");
        assertEquals(9.0, cell.getNumericCellValue(), "D12 must be equal");

        cell = getCellByReference(sheet, "E16");
        assertEquals(899.91d, cell.getNumericCellValue(), "D12 must be equal");

        assertNotNull(brf60Processor.getBrfTransformer());
        assertNull(brf60Processor.getReportingRepository());
    }

    @Test
    void mustPassAllClosingBalanceAccountsCalls() {
        commonTestForAccountsClosingBalance("E16", banksOwnedFundAccountsConfig.getBanksOwnedFundBalanceKeys());

    }

    private void commonTestForAccountsClosingBalance(String cellToCheck, ClosingBalanceQueryKey queryKey) {
        var total = queryKey.getAccounts().size() * DEFAULT_CLOSING_BALANCE;
        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(queryKey));
        Mockito.when(productBookValueRepository.getCountAndTotalBookValueByProduct(Mockito.any(), Mockito.any()))
                .thenReturn(bookValueForProducts());
        brf60Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(total, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());
    }

    private List<ProductBookValueInfo> bookValueForProducts() {
        return List.of(new ProductBookValueInfo("MBILLS Investment", 4, new BigDecimal(149877693.67)));
    }

    private List<AccountClosingBalance> closingBalancingForAccounts(ClosingBalanceQueryKey queryKey) {
        return queryKey.getAccounts().stream()

                .map(account -> CollectionUtils.isEmpty(queryKey.getProducts())
                        ? List.of(build(account, "", DEFAULT_CLOSING_BALANCE))
                        : queryKey.getProducts().stream()
                        .map(product -> build(account, product, DEFAULT_CLOSING_BALANCE))
                        .collect(Collectors.toList())

                ).flatMap(List::stream).collect(Collectors.toList());
    }

    private AccountClosingBalance build(String account, String product, double closingBalance) {
        return AccountClosingBalance.builder()
                .id(MainAccountProductId.builder().mainAccount(account).product(product).build())
                .closingBalance(closingBalance).build();
    }

    private Cell getCellByReference(Sheet sheet, String reference) {
        var cellReference = new CellReference(reference);
        return sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
    }
}
