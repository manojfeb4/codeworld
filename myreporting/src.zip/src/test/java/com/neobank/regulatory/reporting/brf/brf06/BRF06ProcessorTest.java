package com.neobank.regulatory.reporting.brf.brf06;

import com.neobank.regulatory.reporting.config.ClientSegmentConfig;
import com.neobank.regulatory.reporting.entity.AverageAccountBalanceId;
import com.neobank.regulatory.reporting.entity.AverageAccountBalanceInfo;
import com.neobank.regulatory.reporting.entity.ClientSegmentInfo;
import com.neobank.regulatory.reporting.model.AverageAccountBalanceReportingData;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountBalanceRepository;
import com.neobank.regulatory.reporting.repository.ClientSegmentRepository;
import com.neobank.regulatory.reporting.services.AverageAccountBalanceService;
import com.neobank.regulatory.reporting.util.ConfigUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.neobank.regulatory.reporting.util.Resources.verifyCellData;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class BRF06ProcessorTest {

    static ClientSegmentConfig clientSegmentConfig;

    static {
        clientSegmentConfig = ConfigUtil.read("mapping/client-segment-values.yml", "client-segment-classification",
                ClientSegmentConfig.class);

    }

    @InjectMocks
    BRF06Processor underTest;

    Workbook wb;
    TransformationContext payloadData;

    ResourceLoader resourceLoader = new DefaultResourceLoader();


    @Mock
    private AccountBalanceRepository accountBalanceRepository;

    @Mock
    private ClientSegmentRepository clientSegmentRepository;


    private AverageAccountBalanceService averageAccountBalanceService;

    @Mock
    private BRF06Transformer brf06Transformer;

    private AverageAccountBalanceReportingData averageAccountBalanceReportingData;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-006.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        averageAccountBalanceService = spy(new AverageAccountBalanceService());
        averageAccountBalanceReportingData = spy(new AverageAccountBalanceReportingData());
        brf06Transformer = spy(new BRF06Transformer());
        underTest = new BRF06Processor(brf06Transformer,
                clientSegmentConfig,
                accountBalanceRepository,
                clientSegmentRepository, averageAccountBalanceService);
        payloadData = new TransformationContext("006", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
    }

    @Test
    void shouldReturnBrfId() {
        assertEquals("BRF-006", underTest.getBrfId());
    }

    @Test
    void shouldReturnBrfProcessor() {
        assertEquals(brf06Transformer, underTest.getBrfTransformer());
    }


    @Test
    void shouldProcessReportWithoutDataInSource() {

        List<AverageAccountBalanceInfo> averageAccountBalanceInfo = Collections.emptyList();

        when(accountBalanceRepository.getAverageAccountBalance(any(), any(), any(), any()))
                .thenReturn(averageAccountBalanceInfo);

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        verifyCellData("C4", "ADQ Neobank", sheet);
        verifyCellData("D9", "0.0", sheet);
        verifyCellData("D21", "0.0", sheet);

    }

    @Test
    void shouldProcessReportWithDataInSource() {
        var reportingData = List.of(getReportingData());


        underTest.setMonthlyDefaultCells(wb, payloadData);

        var sheet = wb.getSheetAt(0);

        brf06Transformer.transform(sheet, reportingData);

        Row row = sheet.getRow(3);


        assertEquals("ADQ Neobank", row.getCell(2).toString());
        verifyCellData("D9", "60000.0", sheet);
        verifyCellData("D21", "55000.0", sheet);

        verifyCellData("D11", "25000.0", sheet);
        verifyCellData("D23", "100000.0", sheet);


    }


    private AverageAccountBalanceReportingData getReportingData() {

        List<AverageAccountBalanceInfo> averageAccountBalanceInfo = getAverageAccountBalanceInfo();
        List<String> govtClientSegments = List.of("Business_1", "Business_3");
        List<String> otherClientSegments = List.of("Business_2", "Business_4");

        averageAccountBalanceReportingData.setTotalAverageGovtDemand(averageAccountBalanceService.averageAccountBalanceOfClientSegments
                (averageAccountBalanceInfo,
                        govtClientSegments,
                        "CURRENT_ACCOUNT"));
        averageAccountBalanceReportingData.setTotalAverageGovtSavings(averageAccountBalanceService.averageAccountBalanceOfClientSegments
                (averageAccountBalanceInfo,
                        govtClientSegments,
                        "REGULAR_SAVINGS"));
        averageAccountBalanceReportingData.setTotalAverageOtherDemand(averageAccountBalanceService.averageAccountBalanceOfClientSegments
                (averageAccountBalanceInfo,
                        otherClientSegments,
                        "CURRENT_ACCOUNT"));
        averageAccountBalanceReportingData.setTotalAverageOtherSavings(averageAccountBalanceService.averageAccountBalanceOfClientSegments
                (averageAccountBalanceInfo,
                        otherClientSegments,
                        "REGULAR_SAVINGS"));
        return averageAccountBalanceReportingData;

    }

    private List<ClientSegmentInfo> getClientSegmentInfo() {
        return List.of(
                new ClientSegmentInfo("Business_1", "REGULATORY AUTHORITY"),
                new ClientSegmentInfo("Business_2", "FEDERAL GOVT. AUTHORITY"),
                new ClientSegmentInfo("Business_3", "NBFI - PVT.SECTOR"),
                new ClientSegmentInfo("Business_4", "NBFI- GRE")
        );
    }

    private List<AverageAccountBalanceInfo> getAverageAccountBalanceInfo() {
        return List.of(
                setAverageAccountBalanceInfo("Business_1", "CURRENT_ACCOUNT", 15000),
                setAverageAccountBalanceInfo("Business_3", "REGULAR_SAVINGS", 25000),
                setAverageAccountBalanceInfo("Business_2", "REGULAR_SAVINGS", 35000),
                setAverageAccountBalanceInfo("Business_3", "CURRENT_ACCOUNT", 45000),
                setAverageAccountBalanceInfo("Business_2", "CURRENT_ACCOUNT", 55000),
                setAverageAccountBalanceInfo("Business_4", "REGULAR_SAVINGS", 65000)

        );

    }

    private AverageAccountBalanceInfo setAverageAccountBalanceInfo(String businessId,
                                                                   String accountType,
                                                                   double totalBalance) {
        AverageAccountBalanceInfo averageAccountBalanceInfo = new AverageAccountBalanceInfo();
        AverageAccountBalanceId averageAccountBalanceId = new AverageAccountBalanceId();
        averageAccountBalanceId.setBusinessId(businessId);
        averageAccountBalanceId.setAccountType(accountType);
        averageAccountBalanceInfo.setAverageAccountBalanceId(averageAccountBalanceId);
        averageAccountBalanceInfo.setTotalBalance(totalBalance);
        return averageAccountBalanceInfo;
    }

}