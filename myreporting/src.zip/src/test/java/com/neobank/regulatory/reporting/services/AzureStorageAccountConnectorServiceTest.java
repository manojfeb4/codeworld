package com.neobank.regulatory.reporting.services;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobClientBuilder;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.neobank.regulatory.reporting.config.AzureStorageAccountProperties;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.util.Resources;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class AzureStorageAccountConnectorServiceTest {

    @Mock
    BlobContainerClientBuilder blobContainerClientBuilder;

    @Mock
    BlobClientBuilder blobClientBuilder;

    @Mock
    AzureStorageAccountProperties azureStorageAccountProperties;


    TransformationContext payloadData;

    @InjectMocks
    private AzureStorageAccountConnectorService underTest;// = new

    // AzureStorageAccountConnectorService(blobContainerClientBuilder);

    @Mock
    private BlobContainerClient blobContainerClient;

    @Mock
    private BlobClient blobClient;

    @Test
    void uploadExcelSuccessful() {
        blobContainerClientBuilder.endpoint("http://localhost:8080/");

        String fileName = "BRF-033";
        String encodedKey = "1234567";
        String query = "";


        payloadData = new TransformationContext("033", LocalDate.now(), LocalDate.now(), encodedKey, query);
        String containerName = "regreporting";
        String date = DateTimeFormatter.ofPattern("yyyy-MM-dd").format(LocalDate.now());
        String blobName = fileName + "/" + fileName + "_" + date + "_" + encodedKey + ".xls";

        File file = Resources.getFile("transformedBRF/BRF-033.xls");
        when(azureStorageAccountProperties.isEnabled()).thenReturn(true);
        when(azureStorageAccountProperties.getContainerName()).thenReturn(containerName);


        when(blobContainerClientBuilder.buildClient()).thenReturn(blobContainerClient);
        when(blobClientBuilder.blobName(blobName)).thenReturn(blobClientBuilder);
        when(blobContainerClient.getBlobClient(blobName)).thenReturn(blobClient);
        underTest.uploadExcel(file, "BRF-033", payloadData);

        verify(blobClient, times(1)).uploadFromFile(file.toPath().toString(), true);
    }

}