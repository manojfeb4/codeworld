package com.neobank.regulatory.reporting.services;

import com.neobank.regulatory.reporting.entity.ProductIssueRatingBookValue;
import com.neobank.regulatory.reporting.model.LiquidAssetsRatioQueryKey;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ProductsBookValueServiceTest {

    @InjectMocks
    ProductsBookValueService productsBookValueService;

    @Test
    void test() {

        assertEquals(0.0, productsBookValueService.liquidAssetsRatio(null, null));
        assertEquals(0.0d, productsBookValueService.liquidAssetsRatio(null, new LiquidAssetsRatioQueryKey()));
        assertEquals(0.0d, productsBookValueService.liquidAssetsRatio(
                List.of(ProductIssueRatingBookValue.builder().build()), new LiquidAssetsRatioQueryKey()));

        var l = new LiquidAssetsRatioQueryKey();
        l.setAccounts(List.of("dummy"));
        assertEquals(0.0d, productsBookValueService.liquidAssetsRatio(
                List.of(ProductIssueRatingBookValue.builder().id(
                                ProductIssueRatingBookValue.ProductIssueRatingBookValueId.builder().product("dummys").build())
                        .build()),
                l));
    }
}
