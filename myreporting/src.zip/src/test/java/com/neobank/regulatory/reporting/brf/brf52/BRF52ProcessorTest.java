package com.neobank.regulatory.reporting.brf.brf52;

import com.neobank.regulatory.reporting.config.LiabilitiesCapitalAccountsConfig;
import com.neobank.regulatory.reporting.config.ProductsBookValueConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.entity.AccountsCountAndBalance;
import com.neobank.regulatory.reporting.entity.MainAccountProductId;
import com.neobank.regulatory.reporting.model.LiabilitiesCapitalQueryKey;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.AccountsCountAndBalanceRepository;
import com.neobank.regulatory.reporting.services.AccountsCountAndBalanceService;
import com.neobank.regulatory.reporting.services.LiabilitiesCapitalService;
import com.neobank.regulatory.reporting.util.ConfigUtil;
import com.neobank.regulatory.reporting.util.NumberUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class BRF52ProcessorTest {

    private static final double DEFAULT_VALUE = 29.99d;
    private static final double DEFAULT_CLOSING_BALANCE = 99.99d;
    static LiabilitiesCapitalAccountsConfig liabilitiesCapitalAccountsConfig;
    static ProductsBookValueConfig productsBookValueConfig;

    static {
        liabilitiesCapitalAccountsConfig = ConfigUtil.read("mapping/liabilities-capital-accounts.yml",
                "liabilities-capital", LiabilitiesCapitalAccountsConfig.class);
    }

    Workbook wb;
    TransformationContext payloadData;
    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @InjectMocks
    BRF52Processor brf52Processor;

    @Mock
    private AccountClosingBalanceRepository accountClosingBalanceRepository;

    @Mock
    private AccountsCountAndBalanceRepository accountsCountAndBalanceRepository;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-002.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("002", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
        //
        BRF52Transformer brf01Transformer = Mockito.spy(new BRF52Transformer());
        //
        brf52Processor = new BRF52Processor(brf01Transformer, accountClosingBalanceRepository,
                new LiabilitiesCapitalService(), liabilitiesCapitalAccountsConfig, accountsCountAndBalanceRepository,
                new AccountsCountAndBalanceService());
    }

    @Test
    void mustPassValidRequest() {
        assertNotNull(brf52Processor);

        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any())).thenReturn(
                closingBalancingForAccounts(liabilitiesCapitalAccountsConfig.getMoneyBorrowingRemainingBalance()));

        brf52Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, "C47");
        assertEquals(199.98d, cell.getNumericCellValue(), "must be equal");
        assertNotNull(brf52Processor.getBrfTransformer());
        assertNull(brf52Processor.getReportingRepository());
    }

    @Test
    void mustPassValidRequestAndSetDefaultCells() {
        brf52Processor.setQuarterlyDefaultCells(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell1 = getCellByReference(sheet, "B4");
        assertEquals("ADQ Neobank", cell1.getStringCellValue(), "must be equal");
        var cell2 = getCellByReference(sheet, "B5");
        var reportingDate = DateTimeFormatter.ofPattern("yyyy/MM/dd").format(payloadData.getReportingFromDate());
        assertEquals(reportingDate, cell2.getStringCellValue(), "must be equal");
    }

    @Test
    void mustPassAllClosingBalanceRefCAccountsCalls() {
        commonTestForAccountsClosingBalance("C47",
                liabilitiesCapitalAccountsConfig.getMoneyBorrowingRemainingBalance());
        commonTestForAccountsClosingBalance("C48", liabilitiesCapitalAccountsConfig.getInterbankBorrowing());
        commonTestForAccountsClosingBalance("C49", liabilitiesCapitalAccountsConfig.getOtherTermBorrowings());
        commonTestForAccountsClosingBalance("C50", liabilitiesCapitalAccountsConfig.getBorrowingUnderRepurchase());
        commonTestForAccountsClosingBalance("C63", liabilitiesCapitalAccountsConfig.getStaffBenefits());
        commonTestForAccountsClosingBalance("C64", liabilitiesCapitalAccountsConfig.getOtherProvisions());
        commonTestForAccountsClosingBalance("C66", liabilitiesCapitalAccountsConfig.getInterestPayable());
        commonTestForAccountsClosingBalance("C67", liabilitiesCapitalAccountsConfig.getIncomeTaxLiability());
        commonTestForAccountsClosingBalance("C68", liabilitiesCapitalAccountsConfig.getAccountsPayable());
        commonTestForAccountsClosingBalance("C73", liabilitiesCapitalAccountsConfig.getAcceptances());
        commonTestForAccountsClosingBalance("C74", liabilitiesCapitalAccountsConfig.getAllOtherBorrowings());
        commonTestForAccountsClosingBalance("C85", liabilitiesCapitalAccountsConfig.getShareCapital());
        commonTestForAccountsClosingBalance("C86", liabilitiesCapitalAccountsConfig.getTreasuryShares());
        commonTestForAccountsClosingBalance("C88", liabilitiesCapitalAccountsConfig.getLegalReserves());
        commonTestForAccountsClosingBalance("C90", liabilitiesCapitalAccountsConfig.getOtherComprehensiveIncome());
        commonTestForAccountsClosingBalance("C91", liabilitiesCapitalAccountsConfig.getOtherReserves());
        commonTestForAccountsClosingBalance("C92", liabilitiesCapitalAccountsConfig.getRetainedEarnings());
        commonTestForAccountsClosingBalance("C93", liabilitiesCapitalAccountsConfig.getCurrentYearProfit());
        commonTestForAccountsClosingBalance("C94", liabilitiesCapitalAccountsConfig.getInstrumentsPerpetual());
    }

    @Test
    void mustPassAllClosingBalanceRefDAccountsCalls() {
        commonTestForAccountsClosingBalance("D47",
                liabilitiesCapitalAccountsConfig.getMoneyBorrowingRemainingBalance());
        commonTestForAccountsClosingBalance("D48", liabilitiesCapitalAccountsConfig.getInterbankBorrowing());
        commonTestForAccountsClosingBalance("D49", liabilitiesCapitalAccountsConfig.getOtherTermBorrowings());
        commonTestForAccountsClosingBalance("D50", liabilitiesCapitalAccountsConfig.getBorrowingUnderRepurchase());
        commonTestForAccountsClosingBalance("D63", liabilitiesCapitalAccountsConfig.getStaffBenefits());
        commonTestForAccountsClosingBalance("D64", liabilitiesCapitalAccountsConfig.getOtherProvisions());
        commonTestForAccountsClosingBalance("D66", liabilitiesCapitalAccountsConfig.getInterestPayable());
        commonTestForAccountsClosingBalance("D67", liabilitiesCapitalAccountsConfig.getIncomeTaxLiability());
        commonTestForAccountsClosingBalance("D68", liabilitiesCapitalAccountsConfig.getAccountsPayable());
        commonTestForAccountsClosingBalance("D73", liabilitiesCapitalAccountsConfig.getAcceptances());
        commonTestForAccountsClosingBalance("D74", liabilitiesCapitalAccountsConfig.getAllOtherBorrowings());
        commonTestForAccountsClosingBalance("D85", liabilitiesCapitalAccountsConfig.getShareCapital());
        commonTestForAccountsClosingBalance("D86", liabilitiesCapitalAccountsConfig.getTreasuryShares());
        commonTestForAccountsClosingBalance("D88", liabilitiesCapitalAccountsConfig.getLegalReserves());
        commonTestForAccountsClosingBalance("D90", liabilitiesCapitalAccountsConfig.getOtherComprehensiveIncome());
        commonTestForAccountsClosingBalance("D91", liabilitiesCapitalAccountsConfig.getOtherReserves());
        commonTestForAccountsClosingBalance("D92", liabilitiesCapitalAccountsConfig.getRetainedEarnings());
        commonTestForAccountsClosingBalance("D93", liabilitiesCapitalAccountsConfig.getCurrentYearProfit());
        commonTestForAccountsClosingBalance("D94", liabilitiesCapitalAccountsConfig.getInstrumentsPerpetual());
    }

    @Test
    void mustPassAllBookValueForProductsCalls() {
        commonTestForCountAndBalance("C22", 299.9);
        commonTestForCountAndBalance("C23", 299.9);
        commonTestForCountAndBalance("D22", 299.9);
        commonTestForCountAndBalance("D23", 299.9);
    }

    private void commonTestForAccountsClosingBalance(String cellToCheck, LiabilitiesCapitalQueryKey queryKey) {
        var total = NumberUtils.roundOffValue(queryKey.getAccounts().size() * DEFAULT_CLOSING_BALANCE);
        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(queryKey));
        brf52Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(total, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());
    }

    private void commonTestForCountAndBalance(String cellToCheck, double value) {
        Mockito.when(accountsCountAndBalanceRepository.getCountsAndTotalBalanceByAccountType(Mockito.any()))
                .thenReturn(countAndBalance(10));
        brf52Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(value, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());

    }

    private List<AccountClosingBalance> closingBalancingForAccounts(LiabilitiesCapitalQueryKey queryKey) {
        return queryKey.getAccounts().stream()
                .map(c -> AccountClosingBalance.builder()
                        .id(MainAccountProductId.builder().mainAccount(c).product("").build())
                        .closingBalance(DEFAULT_CLOSING_BALANCE).build())
                .collect(Collectors.toList());
    }

    private List<AccountsCountAndBalance> countAndBalance(long count) {
        return List.of(
                AccountsCountAndBalance.builder().totalCounts(count).accountType(BRF52Processor.CURRENT_ACCOUNT)
                        .totalBalance(count * DEFAULT_VALUE).build(),
                AccountsCountAndBalance.builder().accountType(BRF52Processor.REGULAR_SAVINGS).totalCounts(count)
                        .totalBalance(count * DEFAULT_VALUE).build());
    }

    private Cell getCellByReference(Sheet sheet, String reference) {
        var cellReference = new CellReference(reference);
        return sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
    }
}
