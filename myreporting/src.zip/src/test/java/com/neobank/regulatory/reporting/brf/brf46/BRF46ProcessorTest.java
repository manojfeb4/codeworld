package com.neobank.regulatory.reporting.brf.brf46;

import com.neobank.regulatory.reporting.entity.BookValuePerProduct;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.TreasuryProductRepository;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BRF46ProcessorTest {


    private static final String MBILLS_INVESTMENT = "MBILLS Investment";

    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Mock
    TreasuryProductRepository investmentRepository;

    @Mock
    BRF46Transformer brf46Transformer;

    @InjectMocks
    BRF46Processor underTest;

    Workbook wb;
    TransformationContext payloadData;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-046.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("046", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
    }

    @Test
    void shouldReturnBrfId() {
        assertEquals("BRF-046", underTest.getBrfId());
    }

    @Test
    void shouldReturnBrfProcessor() {
        assertEquals(brf46Transformer, underTest.getBrfTransformer());
    }

    @Test
    void shouldReturnReportingRepository() {
        assertEquals(investmentRepository, underTest.getReportingRepository());
    }

    @Test
    void shouldProcessReportWithoutDataInSource() {

        BookValuePerProduct bookValuePerProduct = null;

        when(investmentRepository.getSumOfBookValueForInvestmentsByProductOnDate(any(), any()))
                .thenReturn(bookValuePerProduct);

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);
        Sheet sheet = wb.getSheetAt(0);

        Row row = sheet.getRow(3);
        assertEquals("ADQ Neobank", row.getCell(2).toString());

        row = sheet.getRow(20);
        assertEquals("0.0", row.getCell(5).toString());

    }

    @Test
    void shouldProcessReportWithDataInSource() {

        BookValuePerProduct bookValuePerProduct = getBookValuePerProduct();

        when(investmentRepository.getSumOfBookValueForInvestmentsByProductOnDate(any(), any()))
                .thenReturn(bookValuePerProduct);

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);
        Sheet sheet = wb.getSheetAt(0);

        Row row = sheet.getRow(3);
        assertEquals("ADQ Neobank", row.getCell(2).toString());

        row = sheet.getRow(20);
        assertEquals("12693.47", row.getCell(5).toString());

    }

    @NotNull
    private BookValuePerProduct getBookValuePerProduct() {
        BookValuePerProduct bookValuePerProduct = new BookValuePerProduct();
        bookValuePerProduct.setBookValue(12693.47);
        bookValuePerProduct.setProductName(MBILLS_INVESTMENT);
        return bookValuePerProduct;
    }

}