package com.neobank.regulatory.reporting.brf.brf01;

import com.neobank.regulatory.reporting.config.AccountsClosingBalanceConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.entity.MainAccountProductId;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.util.ConfigUtil;
import com.neobank.regulatory.reporting.util.NumberUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class BRF01ProcessorTest {

    private static final double DEFAULT_CLOSING_BALANCE = 99.99d;
    static AccountsClosingBalanceConfig accountsClosingBalanceConfig;

    static {
        accountsClosingBalanceConfig = ConfigUtil.read("mapping/accounts-closing-balance.yml", "closing-balance",
                AccountsClosingBalanceConfig.class);
    }

    Workbook wb;
    TransformationContext payloadData;
    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @InjectMocks
    BRF01Processor brf01Processor;

    @Mock
    private AccountClosingBalanceRepository accountClosingBalanceRepository;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-001.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("001", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
        //
        BRF01Transformer brf01Transformer = Mockito.spy(new BRF01Transformer());
        //
        brf01Processor = new BRF01Processor(brf01Transformer, accountClosingBalanceRepository,
                accountsClosingBalanceConfig, new AccountsClosingBalanceService());
    }

    @Test
    void mustPassValidRequest() {
        assertNotNull(brf01Processor);

        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(accountsClosingBalanceConfig.getCashInHand()));

        brf01Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, "F12");
        assertEquals(199.98d, cell.getNumericCellValue(), "must be equal");
        assertNotNull(brf01Processor.getBrfTransformer());
        assertNull(brf01Processor.getReportingRepository());
    }

    @Test
    void mustPassAllClosingBalanceAccountsCalls() {
        commonTestForAccountsClosingBalance("F12", accountsClosingBalanceConfig.getCashInHand());
        commonTestForAccountsClosingBalance("F13", accountsClosingBalanceConfig.getReserveHeldCB());
        commonTestForAccountsClosingBalance("F15", accountsClosingBalanceConfig.getOtherBalances());
        commonTestForAccountsClosingBalance("F17", accountsClosingBalanceConfig.getReportedToUAECB());
        commonTestForAccountsClosingBalance("F21", accountsClosingBalanceConfig.getOverseasBRNB());
        commonTestForAccountsClosingBalance("F26", accountsClosingBalanceConfig.getOtherTermPlacements());
        commonTestForAccountsClosingBalance("F29",
                accountsClosingBalanceConfig.getLendingCoveredRepurchaseAgreements());
        commonTestForAccountsClosingBalance("F36", accountsClosingBalanceConfig.getDebtSecurities1());
        commonTestForAccountsClosingBalance("F37", accountsClosingBalanceConfig.getEquities1());
        commonTestForAccountsClosingBalance("F41", accountsClosingBalanceConfig.getDebtSecurities2());
        commonTestForAccountsClosingBalance("F42", accountsClosingBalanceConfig.getEquities2());
        commonTestForAccountsClosingBalance("F45", accountsClosingBalanceConfig.getInvestmentSubsidiaries());
        commonTestForAccountsClosingBalance("F46", accountsClosingBalanceConfig.getInvestmentAffiliates());
        commonTestForAccountsClosingBalance("F68", accountsClosingBalanceConfig.getNetFixedAsset1());
        commonTestForAccountsClosingBalance("F70", accountsClosingBalanceConfig.getNetFixedAsset2());
        commonTestForAccountsClosingBalance("F72", accountsClosingBalanceConfig.getCapitalWorkInProgress());
        commonTestForAccountsClosingBalance("F75", accountsClosingBalanceConfig.getInterestReceivable1());
        commonTestForAccountsClosingBalance("F76", accountsClosingBalanceConfig.getPrepaidExpenses());
        commonTestForAccountsClosingBalance("F78", accountsClosingBalanceConfig.getInterestReceivable2());
        commonTestForAccountsClosingBalance("F81", accountsClosingBalanceConfig.getDividendReceivable());
        commonTestForAccountsClosingBalance("F84", accountsClosingBalanceConfig.getMarketValueForwardContacts());
        commonTestForAccountsClosingBalance("F87", accountsClosingBalanceConfig.getMarketValueFinancialFutures());
        commonTestForAccountsClosingBalance("F88", accountsClosingBalanceConfig.getMarketValueCreditDerivatives());
    }

    @Test
    void mustPassAllBookValueForProductsCalls() {
        commonTestForAccountsClosingBalance("F24", accountsClosingBalanceConfig.getCallAccountBookValue());
        commonTestForAccountsClosingBalance("F25", accountsClosingBalanceConfig.getInterbankPlacements());
        commonTestForAccountsClosingBalanceWithValue("F43", accountsClosingBalanceConfig.getAssetsHeldMBills(),
                799.92d);
    }

    private void commonTestForAccountsClosingBalance(String cellToCheck, ClosingBalanceQueryKey queryKey) {
        var total = NumberUtils.roundOffValue(queryKey.getAccounts().size() * DEFAULT_CLOSING_BALANCE);
        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(queryKey));
        brf01Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(total, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());
    }

    private void commonTestForAccountsClosingBalanceWithValue(String cellToCheck, ClosingBalanceQueryKey queryKey,
                                                              double value) {
        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(queryKey));
        brf01Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(value, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());
    }

    private List<AccountClosingBalance> closingBalancingForAccounts(ClosingBalanceQueryKey queryKey) {
        return queryKey.getAccounts().stream()

                .map(account -> CollectionUtils.isEmpty(queryKey.getProducts())
                        ? List.of(build(account, "", DEFAULT_CLOSING_BALANCE))
                        : queryKey.getProducts().stream()
                        .map(product -> build(account, product, DEFAULT_CLOSING_BALANCE))
                        .collect(Collectors.toList())

                ).flatMap(List::stream).collect(Collectors.toList());
    }

    private AccountClosingBalance build(String account, String product, double closingBalance) {
        return AccountClosingBalance.builder()
                .id(MainAccountProductId.builder().mainAccount(account).product(product).build())
                .closingBalance(closingBalance).build();
    }

    private Cell getCellByReference(Sheet sheet, String reference) {
        var cellReference = new CellReference(reference);
        return sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
    }
}
