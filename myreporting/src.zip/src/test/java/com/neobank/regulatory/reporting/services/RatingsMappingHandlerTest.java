package com.neobank.regulatory.reporting.services;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RatingsMappingHandlerTest {

    @Mock
    private Environment environment;

    @InjectMocks
    private RatingsMappingHandler underTest;

    @Test
    void shouldGetMappedRatingFromEnv() {
        when(environment.getProperty("snp.AAA")).thenReturn("1");
        assertEquals(1, underTest.getMappedRating("AAA"));
    }

    @Test
    void shouldReturnNullWhenMappedRatingDoesNotExist() {
        when(environment.getProperty("snp.AAA")).thenReturn(null);
        assertEquals(0, underTest.getMappedRating("AAA"));
    }

}