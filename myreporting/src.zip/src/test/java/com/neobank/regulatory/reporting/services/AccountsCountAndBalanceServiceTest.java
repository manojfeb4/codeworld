package com.neobank.regulatory.reporting.services;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class AccountsCountAndBalanceServiceTest {

    @InjectMocks
    AccountsCountAndBalanceService accountsCountAndBalanceService;

    @Test
    void test() {
        assertEquals(0, accountsCountAndBalanceService.count(null, null));
        assertEquals(0, accountsCountAndBalanceService.count(null, "dummy"));

        assertEquals(0.0d, accountsCountAndBalanceService.balance(null, null));
        assertEquals(0.0d, accountsCountAndBalanceService.balance(null, "dummy"));
    }
}
