package com.neobank.regulatory.reporting.util;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import static com.neobank.regulatory.reporting.util.NumberUtils.getAmountInThousands;
import static org.junit.jupiter.api.Assertions.assertEquals;

class NumberUtilsTest {

    @Mock
    String amountInString;

    @Test
    void getAmountInThousandsTest() {
        amountInString = "0.0";
        assertEquals(0.0d, getAmountInThousands(amountInString));

        amountInString = "1,234,234.56";
        assertEquals(1234.23, getAmountInThousands(amountInString));
    }
}
