package com.neobank.regulatory.reporting.brf.brf51;

import com.neobank.regulatory.reporting.config.AccountsClosingBalanceConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.entity.MainAccountProductId;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.util.ConfigUtil;
import com.neobank.regulatory.reporting.util.NumberUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class BRF51ProcessorTest {

    private static final double DEFAULT_BOOK_VALUE = 29.99d;
    private static final double DEFAULT_CLOSING_BALANCE = 99.99d;
    static AccountsClosingBalanceConfig accountsClosingBalanceConfig;

    static {
        accountsClosingBalanceConfig = ConfigUtil.read("mapping/accounts-closing-balance.yml", "closing-balance",
                AccountsClosingBalanceConfig.class);
    }

    Workbook wb;
    TransformationContext payloadData;
    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @InjectMocks
    BRF51Processor brf51Processor;

    private BRF51Transformer brf01Transformer;

    @Mock
    private AccountClosingBalanceRepository accountClosingBalanceRepository;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-001.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("001", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
        //
        brf01Transformer = Mockito.spy(new BRF51Transformer());
        //
        brf51Processor = new BRF51Processor(brf01Transformer, accountClosingBalanceRepository,
                accountsClosingBalanceConfig, new AccountsClosingBalanceService());
    }

    @Test
    void mustPassValidRequest() {
        assertNotNull(brf51Processor);

        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(accountsClosingBalanceConfig.getCashInHand()));

        brf51Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, "D11");
        assertEquals(199.98d, cell.getNumericCellValue(), "must be equal");
        assertNotNull(brf51Processor.getBrfTransformer());
        assertNull(brf51Processor.getReportingRepository());
    }

    @Test
    void mustPassValidRequestAndSetDefaultCells() {
        brf51Processor.setQuarterlyDefaultCells(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell1 = getCellByReference(sheet, "B4");
        assertEquals("ADQ Neobank", cell1.getStringCellValue(), "must be equal");
        var cell2 = getCellByReference(sheet, "B5");
        var reportingDate = DateTimeFormatter.ofPattern("yyyy/MM/dd").format(payloadData.getReportingFromDate());
        assertEquals(reportingDate, cell2.getStringCellValue(), "must be equal");
    }

    @Test
    void mustPassAllClosingBalanceAccountsCallsRefC() {
        commonTestForAccountsClosingBalance("C11", accountsClosingBalanceConfig.getCashInHand());
        commonTestForAccountsClosingBalance("C12", accountsClosingBalanceConfig.getReserveHeldCB());
        commonTestForAccountsClosingBalance("C14", accountsClosingBalanceConfig.getOtherBalances());
        commonTestForAccountsClosingBalance("C16", accountsClosingBalanceConfig.getReportedToUAECB());
        commonTestForAccountsClosingBalance("C20", accountsClosingBalanceConfig.getOverseasBRNB());
        commonTestForAccountsClosingBalance("C25", accountsClosingBalanceConfig.getOtherTermPlacements());
        commonTestForAccountsClosingBalance("C28",
                accountsClosingBalanceConfig.getLendingCoveredRepurchaseAgreements());
        commonTestForAccountsClosingBalance("C35", accountsClosingBalanceConfig.getDebtSecurities1());
        commonTestForAccountsClosingBalance("C36", accountsClosingBalanceConfig.getEquities1());
        commonTestForAccountsClosingBalance("C40", accountsClosingBalanceConfig.getDebtSecurities2());
        commonTestForAccountsClosingBalance("C41", accountsClosingBalanceConfig.getEquities2());
        commonTestForAccountsClosingBalance("C44", accountsClosingBalanceConfig.getInvestmentSubsidiaries());
        commonTestForAccountsClosingBalance("C45", accountsClosingBalanceConfig.getInvestmentAffiliates());
        commonTestForAccountsClosingBalance("C67", accountsClosingBalanceConfig.getNetFixedAsset1());
        commonTestForAccountsClosingBalance("C69", accountsClosingBalanceConfig.getNetFixedAsset2());
        commonTestForAccountsClosingBalance("C71", accountsClosingBalanceConfig.getCapitalWorkInProgress());
        commonTestForAccountsClosingBalance("C74", accountsClosingBalanceConfig.getInterestReceivable1());
        commonTestForAccountsClosingBalance("C75", accountsClosingBalanceConfig.getPrepaidExpenses());
        commonTestForAccountsClosingBalance("C77", accountsClosingBalanceConfig.getInterestReceivable2());
        commonTestForAccountsClosingBalance("C80", accountsClosingBalanceConfig.getDividendReceivable());
        commonTestForAccountsClosingBalance("C83", accountsClosingBalanceConfig.getMarketValueForwardContacts());
        commonTestForAccountsClosingBalance("C86", accountsClosingBalanceConfig.getMarketValueFinancialFutures());
        commonTestForAccountsClosingBalance("C87", accountsClosingBalanceConfig.getMarketValueCreditDerivatives());
    }

    @Test
    void mustPassAllClosingBalanceAccountsCallsRefD() {
        commonTestForAccountsClosingBalance("D11", accountsClosingBalanceConfig.getCashInHand());
        commonTestForAccountsClosingBalance("D12", accountsClosingBalanceConfig.getReserveHeldCB());
        commonTestForAccountsClosingBalance("D14", accountsClosingBalanceConfig.getOtherBalances());
        commonTestForAccountsClosingBalance("D16", accountsClosingBalanceConfig.getReportedToUAECB());
        commonTestForAccountsClosingBalance("D20", accountsClosingBalanceConfig.getOverseasBRNB());
        commonTestForAccountsClosingBalance("D25", accountsClosingBalanceConfig.getOtherTermPlacements());
        commonTestForAccountsClosingBalance("D28",
                accountsClosingBalanceConfig.getLendingCoveredRepurchaseAgreements());
        commonTestForAccountsClosingBalance("D35", accountsClosingBalanceConfig.getDebtSecurities1());
        commonTestForAccountsClosingBalance("D36", accountsClosingBalanceConfig.getEquities1());
        commonTestForAccountsClosingBalance("D40", accountsClosingBalanceConfig.getDebtSecurities2());
        commonTestForAccountsClosingBalance("D41", accountsClosingBalanceConfig.getEquities2());
        commonTestForAccountsClosingBalance("D44", accountsClosingBalanceConfig.getInvestmentSubsidiaries());
        commonTestForAccountsClosingBalance("D45", accountsClosingBalanceConfig.getInvestmentAffiliates());
        commonTestForAccountsClosingBalance("D67", accountsClosingBalanceConfig.getNetFixedAsset1());
        commonTestForAccountsClosingBalance("D69", accountsClosingBalanceConfig.getNetFixedAsset2());
        commonTestForAccountsClosingBalance("D71", accountsClosingBalanceConfig.getCapitalWorkInProgress());
        commonTestForAccountsClosingBalance("D74", accountsClosingBalanceConfig.getInterestReceivable1());
        commonTestForAccountsClosingBalance("D75", accountsClosingBalanceConfig.getPrepaidExpenses());
        commonTestForAccountsClosingBalance("D77", accountsClosingBalanceConfig.getInterestReceivable2());
        commonTestForAccountsClosingBalance("D80", accountsClosingBalanceConfig.getDividendReceivable());
        commonTestForAccountsClosingBalance("D83", accountsClosingBalanceConfig.getMarketValueForwardContacts());
        commonTestForAccountsClosingBalance("D86", accountsClosingBalanceConfig.getMarketValueFinancialFutures());
        commonTestForAccountsClosingBalance("D87", accountsClosingBalanceConfig.getMarketValueCreditDerivatives());
    }

    @Test
    void mustPassAllBookValueForProductsCalls() {
        commonTestForAccountsClosingBalance("D23", accountsClosingBalanceConfig.getCallAccountBookValue());
        commonTestForAccountsClosingBalance("D24", accountsClosingBalanceConfig.getInterbankPlacements());
        commonTestForAccountsClosingBalance("D42", accountsClosingBalanceConfig.getAssetsHeldMBills(), 799.92d);
    }

    private void commonTestForAccountsClosingBalance(String cellToCheck, ClosingBalanceQueryKey queryKey) {
        var total = NumberUtils.roundOffValue(queryKey.getAccounts().size() * DEFAULT_CLOSING_BALANCE);
        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(queryKey));
        brf51Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(total, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());
    }

    private void commonTestForAccountsClosingBalance(String cellToCheck, ClosingBalanceQueryKey queryKey, double value) {
        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(queryKey));
        brf51Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(value, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());
    }

    private List<AccountClosingBalance> closingBalancingForAccounts(ClosingBalanceQueryKey queryKey) {
        return queryKey.getAccounts().stream()

                .map(account -> CollectionUtils.isEmpty(queryKey.getProducts())
                        ? List.of(build(account, "", DEFAULT_CLOSING_BALANCE))
                        : queryKey.getProducts().stream()
                        .map(product -> build(account, product, DEFAULT_CLOSING_BALANCE))
                        .collect(Collectors.toList())

                ).flatMap(List::stream).collect(Collectors.toList());
    }

    private AccountClosingBalance build(String account, String product, double closingBalance) {
        return AccountClosingBalance.builder()
                .id(MainAccountProductId.builder().mainAccount(account).product(product).build())
                .closingBalance(closingBalance).build();
    }

    private Cell getCellByReference(Sheet sheet, String reference) {
        var cellReference = new CellReference(reference);
        return sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
    }
}
