package com.neobank.regulatory.reporting.util;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import java.io.File;

public class ConfigUtil {

    public static <T> T read(String file, String prefix, Class<T> t) {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        var configFile = new File(classLoader.getResource(file).getFile());
        var mapper = new ObjectMapper(new YAMLFactory());
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);
        try {
            var tree = mapper.readTree(configFile).get(prefix);
            return mapper.readValue(tree.toString(), t);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }
}
