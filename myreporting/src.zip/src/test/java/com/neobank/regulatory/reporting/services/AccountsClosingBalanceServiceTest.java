package com.neobank.regulatory.reporting.services;

import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.model.AssetsLiabilitesMaturityClassificationQueryKey;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import com.neobank.regulatory.reporting.model.LiquidAssetsRatioQueryKey;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class AccountsClosingBalanceServiceTest {

    @InjectMocks
    private AccountsClosingBalanceService accountsClosingBalanceService;

    @Test
    void test() {
        assertEquals(0.0d, accountsClosingBalanceService.closingBalance(null, null));
        assertEquals(0.0d, accountsClosingBalanceService.closingBalance(null, new ClosingBalanceQueryKey()));
        assertEquals(0.0d, accountsClosingBalanceService.closingBalance(List.of(AccountClosingBalance.builder().build()), new ClosingBalanceQueryKey()));

        assertEquals(0.0d, accountsClosingBalanceService.closingBalanceCount(null, null));
        assertEquals(0.0d, accountsClosingBalanceService.closingBalanceCount(null, new ClosingBalanceQueryKey()));
        assertEquals(0.0d, accountsClosingBalanceService.closingBalanceCount(List.of(AccountClosingBalance.builder().build()), new ClosingBalanceQueryKey()));

        assertEquals(0.0d, accountsClosingBalanceService.liquidAssetsRatio(null, null));
        assertEquals(0.0d, accountsClosingBalanceService.liquidAssetsRatio(null, new LiquidAssetsRatioQueryKey()));
        assertEquals(0.0d, accountsClosingBalanceService.liquidAssetsRatio(List.of(AccountClosingBalance.builder().build()), new LiquidAssetsRatioQueryKey()));

        assertEquals(0.0d, accountsClosingBalanceService.closingBalanceForMaturity(null, null));
        assertEquals(0.0d, accountsClosingBalanceService.closingBalanceForMaturity(null, new AssetsLiabilitesMaturityClassificationQueryKey()));
        assertEquals(0.0d, accountsClosingBalanceService.closingBalanceForMaturity(List.of(AccountClosingBalance.builder().build()), new AssetsLiabilitesMaturityClassificationQueryKey()));

    }
}
