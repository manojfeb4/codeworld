package com.neobank.regulatory.reporting.brf.brf13;

import com.neobank.regulatory.reporting.brf.services.GTreasuryService;
import com.neobank.regulatory.reporting.entity.ResidualMaturityId;
import com.neobank.regulatory.reporting.entity.ResidualMaturityInfo;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.ResidualMaturityRepository;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.neobank.regulatory.reporting.util.Resources.verifyCellData;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BRF13ProcessorTest {

    @Mock
    GTreasuryService gTreasuryService;

    BRF13Processor underTest;

    Workbook wb;
    TransformationContext payloadData;

    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Mock
    private ResidualMaturityRepository residualMaturityRepository;

    private BRF13Transformer brf13Transformer;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-013.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        brf13Transformer = spy(new BRF13Transformer());
        underTest = new BRF13Processor(brf13Transformer, residualMaturityRepository);
        payloadData = new TransformationContext("013", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
    }

    @Test
    void shouldReturnBrfId() {
        assertEquals("BRF-013", underTest.getBrfId());
    }

    @Test
    void shouldReturnBrfProcessor() {
        assertEquals(brf13Transformer, underTest.getBrfTransformer());
    }

    @Test
    void shouldReturnReportingRepository() {
        assertEquals(residualMaturityRepository, underTest.getReportingRepository());
    }

    @Test
    void shouldProcessReportWithoutDataInSource() {

        List<ResidualMaturityInfo> totalBookValue = Collections.emptyList();

        when(residualMaturityRepository.getTotalBookValueByResidualMaturity(any(), any(), any(), any(),
                any())).thenReturn(totalBookValue);
        lenient().doCallRealMethod().when(gTreasuryService).getTotalBookValueForBankAndProducts(any());
        doCallRealMethod().when(brf13Transformer).transform(any(), any());
        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        verifyCellData("C4", "ADQ Neobank", sheet);
        verifyCellData("F13", "0.0", sheet);
        verifyCellData("F14", "0.0", sheet);

    }

    @Test
    void shouldProcessReportWithDataInSource() {

        List<ResidualMaturityInfo> ResidualMaturityInfoList = getResidualMaturityInfo();

        when(residualMaturityRepository.getTotalBookValueByResidualMaturity(any(), any(), any(), any(),
                any())).thenReturn(ResidualMaturityInfoList);

        doCallRealMethod().when(brf13Transformer).transform(any(), any());
        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        Row row = sheet.getRow(3);

        verify(brf13Transformer, times(1)).transform(sheet, ResidualMaturityInfoList);

        assertEquals("ADQ Neobank", row.getCell(2).toString());
        verifyCellData("I13", "299676.43", sheet);
        verifyCellData("J14", "125009.17", sheet);
        verifyCellData("L14", "250009.72", sheet);

    }

    private List<ResidualMaturityInfo> getResidualMaturityInfo() {
        return List.of(setResidualMaturityInfo("NCD", 3, 299676.43),
                setResidualMaturityInfo("DEP", 6, 250009.72),
                setResidualMaturityInfo("DEP", 4, 125009.17));

    }

    private ResidualMaturityInfo setResidualMaturityInfo(String product, int bucket, double totalBookValue) {
        ResidualMaturityId residualMaturityId = new ResidualMaturityId();
        residualMaturityId.setProduct(product);
        residualMaturityId.setBucket(bucket);
        ResidualMaturityInfo residualMaturityInfo = new ResidualMaturityInfo();
        residualMaturityInfo.setResidualMaturityId(residualMaturityId);
        residualMaturityInfo.setTotalBookValue(BigDecimal.valueOf(totalBookValue));
        return residualMaturityInfo;
    }
}