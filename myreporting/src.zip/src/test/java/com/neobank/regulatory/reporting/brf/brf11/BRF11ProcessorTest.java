package com.neobank.regulatory.reporting.brf.brf11;

import com.neobank.regulatory.reporting.config.AssetsLiabilitesMaturityClassificationBrf11Config;
import com.neobank.regulatory.reporting.entity.*;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.AccountSegmentClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.ResidualMaturityCOBRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.services.AssetsLiabilitesMaturityClassificationService;
import com.neobank.regulatory.reporting.util.ConfigUtil;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BRF11ProcessorTest {

    private static final String UNITED_ARAB_EMIRATES = "United Arab Emirates";
    private static final String UNITED_STATES = "United States";
    static AssetsLiabilitesMaturityClassificationBrf11Config assetsLiabilitesMaturityClassificationConfig;

    static {
        assetsLiabilitesMaturityClassificationConfig = ConfigUtil.read("mapping/banking-monetary-statistics-brf11.yml",
                "assets-liabilites-maturity-classification-brf11", AssetsLiabilitesMaturityClassificationBrf11Config.class);
    }

    Workbook wb;
    TransformationContext payloadData;
    ResourceLoader resourceLoader = new DefaultResourceLoader();
    @InjectMocks
    private BRF11Processor brf11Processor;
    @Mock
    private AccountClosingBalanceRepository accountClosingBalanceRepository;
    @Mock
    private ResidualMaturityCOBRepository residualMaturityCOBRepository;
    @Mock
    private AccountSegmentClosingBalanceRepository accountSegmentClosingBalanceRepository;

    @BeforeEach
    void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-011.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("011", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
        //
        BRF11Transformer brf11Transformer = Mockito.spy(new BRF11Transformer());
        //
        brf11Processor = new BRF11Processor(brf11Transformer, assetsLiabilitesMaturityClassificationConfig,
                new AssetsLiabilitesMaturityClassificationService(), accountClosingBalanceRepository,
                residualMaturityCOBRepository, new AccountsClosingBalanceService(),
                accountSegmentClosingBalanceRepository);

    }



    void test() {
        assertNotNull(accountClosingBalanceRepository);
        when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(any())).thenReturn(closingBalances());
        when(residualMaturityCOBRepository.getTotalBookValueResidualMaturityByResidencyAndReference(any(), any(), any(), any(),
                any())).thenReturn(residualMaturities());
        when(accountSegmentClosingBalanceRepository.getTotalBalanceWithSegment(any()))
                .thenReturn(segmentClosingBalance());
        brf11Processor.process(wb, payloadData);

        verifyCell(wb.getSheetAt(0), "P9", 301.0d);

        verifyMBIL();
        verifyDEPResidents();
        verifyDEPNonResidents();
        verifyNCD();

        verifyCell(wb.getSheetAt(0), "P33", 100.0d);
        verifyCell(wb.getSheetAt(0), "P44", 100.0d);
        verifyCell(wb.getSheetAt(0), "E54", 200.0d);
        verifyCell(wb.getSheetAt(0), "E55", 100.0d);
        verifyCell(wb.getSheetAt(0), "E56", 100.0d);
        verifyCell(wb.getSheetAt(0), "E57", 100.0d);
        verifyCell(wb.getSheetAt(0), "E58", 100.0d);
        verifyCell(wb.getSheetAt(0), "E59", 100.0d);
        verifyCell(wb.getSheetAt(0), "P64", 100.0d);
        assertNull(brf11Processor.getReportingRepository());
    }

    private void verifyMBIL() {

        verifyCell(wb.getSheetAt(0), "E11", 100.0d);
        verifyCell(wb.getSheetAt(0), "F11", 200.0d);
        verifyCell(wb.getSheetAt(0), "G11", 300.0d);
        verifyCell(wb.getSheetAt(0), "H11", 400.0d);
        verifyCell(wb.getSheetAt(0), "I11", 400.0d);
        verifyCell(wb.getSheetAt(0), "J11", 300.0d);
        verifyCell(wb.getSheetAt(0), "P11", 200.0d);
    }

    private void verifyDEPNonResidents() {
        verifyCell(wb.getSheetAt(0), "E15", 200.0d);
        verifyCell(wb.getSheetAt(0), "F15", 100.0d);
        verifyCell(wb.getSheetAt(0), "G15", 100.0d);
        verifyCell(wb.getSheetAt(0), "H15", 100.0d);
        verifyCell(wb.getSheetAt(0), "I15", 100.0d);
        verifyCell(wb.getSheetAt(0), "J15", 100.0d);
        verifyCell(wb.getSheetAt(0), "P15", 100.0d);
    }

    private void verifyDEPResidents() {
        verifyCell(wb.getSheetAt(0), "E13", 100.0d);
        verifyCell(wb.getSheetAt(0), "F13", 100.0d);
        verifyCell(wb.getSheetAt(0), "G13", 100.0d);
        verifyCell(wb.getSheetAt(0), "H13", 100.0d);
        verifyCell(wb.getSheetAt(0), "I13", 100.0d);
        verifyCell(wb.getSheetAt(0), "J13", 100.0d);
        verifyCell(wb.getSheetAt(0), "P13", 100.0d);
    }

    private void verifyNCD() {
        verifyCell(wb.getSheetAt(0), "E14", 100.0d);
        verifyCell(wb.getSheetAt(0), "F14", 100.0d);
        verifyCell(wb.getSheetAt(0), "G14", 100.0d);
        verifyCell(wb.getSheetAt(0), "H14", 100.0d);
        verifyCell(wb.getSheetAt(0), "I14", 100.0d);
        verifyCell(wb.getSheetAt(0), "J14", 100.0d);
        verifyCell(wb.getSheetAt(0), "P14", 100.0d);
    }

    private List<AccountClosingBalance> closingBalances() {

        return List.of(closingBalance("100001", "", 100.0d),
                closingBalance("100001", "A", 101.0d),
                closingBalance("100130", "", 100.0d),
                closingBalance("101801", "", 100.0d),
                closingBalance("102001", "", 100.0d),
                closingBalance("300001", null, 100.0d));
    }

    private List<ResidualMaturityCOBInfo> residualMaturities() {
        return List.of(residualMaturity("NCD", 0, UNITED_STATES, 100.0d),
                residualMaturity("NCD", 1, UNITED_STATES, 100.0d),
                residualMaturity("NCD", 2, UNITED_STATES, 100.0d),
                residualMaturity("NCD", 3, UNITED_STATES, 100.0d),
                residualMaturity("NCD", 4, UNITED_STATES, 100.0d),
                residualMaturity("NCD", 5, UNITED_STATES, 100.0d),
                residualMaturity("NCD", 11, UNITED_STATES, 100.0d),

                residualMaturity("DEP", 0, UNITED_STATES, 100.0d),
                residualMaturity("DEP", 1, UNITED_STATES, 100.0d),
                residualMaturity("DEP", 2, UNITED_STATES, 100.0d),
                residualMaturity("DEP", 3, UNITED_STATES, 100.0d),
                residualMaturity("DEP", 4, UNITED_STATES, 100.0d),
                residualMaturity("DEP", 5, UNITED_STATES, 100.0d),
                residualMaturity("DEP", 11, UNITED_STATES, 100.0d),
                residualMaturity("DEP", 0, UNITED_STATES, 100.0d),

                residualMaturity("DEP", 0, UNITED_ARAB_EMIRATES, 100.0d),
                residualMaturity("DEP", 1, UNITED_ARAB_EMIRATES, 100.0d),
                residualMaturity("DEP", 2, UNITED_ARAB_EMIRATES, 100.0d),
                residualMaturity("DEP", 3, UNITED_ARAB_EMIRATES, 100.0d),
                residualMaturity("DEP", 4, UNITED_ARAB_EMIRATES, 100.0d),
                residualMaturity("DEP", 5, UNITED_ARAB_EMIRATES, 100.0d),
                residualMaturity("DEP", 11, UNITED_ARAB_EMIRATES, 100.0d),

                residualMaturity("MBIL", 0, UNITED_ARAB_EMIRATES, 100.0d),
                residualMaturity("MBIL", 1, UNITED_ARAB_EMIRATES, 200.0d),
                residualMaturity("MBIL", 2, UNITED_ARAB_EMIRATES, 300.0d),
                residualMaturity("MBIL", 3, UNITED_ARAB_EMIRATES, 400.0d),
                residualMaturity("MBIL", 4, UNITED_ARAB_EMIRATES, 400.0d),
                residualMaturity("MBIL", 5, UNITED_ARAB_EMIRATES, 300.0d),
                residualMaturity("MBIL", 11, UNITED_ARAB_EMIRATES, 200.0d));
    }

    private List<AccountSegmentClosingBalance> segmentClosingBalance() {

        return List.of(
                segBalance(assetsLiabilitesMaturityClassificationConfig.getGovPubDeposit().getSegments1().get(0), "",
                        100.0),
                segBalance(assetsLiabilitesMaturityClassificationConfig.getGovPubDeposit().getSegments1().get(1), "",
                        100.0),
                segBalance(assetsLiabilitesMaturityClassificationConfig.getGreDeposit().getSegments1().get(0), "",
                        100.0),
                segBalance(assetsLiabilitesMaturityClassificationConfig.getPrivSecDeposit().getSegments1().get(0), "",
                        100.0),
                segBalance(assetsLiabilitesMaturityClassificationConfig.getNbfiDeposit().getSegments1().get(0), "",
                        100.0),
                segBalance(assetsLiabilitesMaturityClassificationConfig.getHniMoreThan20AED().getSegments1().get(0), "",
                        100.0),
                segBalance(assetsLiabilitesMaturityClassificationConfig.getHniUpto20AED1().getSegments1().get(0),
                        assetsLiabilitesMaturityClassificationConfig.getHniUpto20AED1().getSegments2().get(1), 100.0));
    }

    private AccountSegmentClosingBalance segBalance(String seg1, String seg2, double value) {
        return AccountSegmentClosingBalance.builder()
                .accountSegmentClosingBalanceId(
                        AccountSegmentClosingBalanceId.builder().segment1(seg1).segment2(seg2).build())
                .totalBalance(new BigDecimal(value)).build();
    }

    private AccountClosingBalance closingBalance(String account, String product, double closingBalance) {
        return AccountClosingBalance.builder()
                .id(MainAccountProductId.builder().mainAccount(account).product(product).build())
                .closingBalance(closingBalance).build();
    }

    private ResidualMaturityCOBInfo residualMaturity(String product, int bucket, String cob, double bookValue) {
        return ResidualMaturityCOBInfo.builder()
                .residualMaturityCOBId(
                        ResidualMaturityCOBId.builder().product(product).bucket(bucket).countryOfBranch(cob).build())
                .totalBookValue(bookValue).build();
    }

    private Cell getCellByReference(Sheet sheet, String reference) {
        var cellReference = new CellReference(reference);
        return sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
    }

    private void verifyCell(Sheet sheet, String cellToCheck, double value) {
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(value, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());
    }
}
