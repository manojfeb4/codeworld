package com.neobank.regulatory.reporting.brf.brf04;

import com.neobank.regulatory.reporting.config.IncomeExpenseAccountsConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.entity.MainAccountProductId;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.util.ConfigUtil;
import com.neobank.regulatory.reporting.util.NumberUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class BRF04ProcessorTest {

    private static final double DEFAULT_CLOSING_BALANCE = 99.99d;
    static IncomeExpenseAccountsConfig incomeExpenseItemConfig;

    static {
        incomeExpenseItemConfig = ConfigUtil.read("mapping/income-expense-accounts.yml", "income-expense-accounts",
                IncomeExpenseAccountsConfig.class);

    }

    Workbook wb;
    TransformationContext payloadData;
    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @InjectMocks
    BRF04Processor brf04Processor;

    @Mock
    private AccountClosingBalanceRepository accountClosingBalanceRepository;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-004.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("004", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
        //
        BRF04Transformer brf04Transformer = Mockito.spy(new BRF04Transformer());
        //
        brf04Processor = new BRF04Processor(brf04Transformer, accountClosingBalanceRepository,
                new AccountsClosingBalanceService(), incomeExpenseItemConfig);
    }

    @Test
    void mustPassValidRequest() {
        assertNotNull(brf04Processor);

        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(incomeExpenseItemConfig.getPersonalConsumerLoanKeys()));

        brf04Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, "E12");
        assertEquals(99.99d, cell.getNumericCellValue(), "must be equal");
        assertNotNull(brf04Processor.getBrfTransformer());
        assertNull(brf04Processor.getReportingRepository());
    }

    @Test
    void mustPassAllClosingBalanceAccountsCalls() {
        commonTestForAccountsClosingBalance("E12", incomeExpenseItemConfig.getPersonalConsumerLoanKeys());
        commonTestForAccountsClosingBalance("E22", incomeExpenseItemConfig.getCentralBankCdKeys());
        commonTestForAccountsClosingBalance("E23", incomeExpenseItemConfig.getInterbankInterestIncomeFromKeys());
        commonTestForAccountsClosingBalance("E25", incomeExpenseItemConfig.getInvestmentIncomeKeys());
        commonTestForAccountsClosingBalance("E26", incomeExpenseItemConfig.getInterestOrProfitIncomeKeys());
        commonTestForAccountsClosingBalance("E29", incomeExpenseItemConfig.getPrivateSectorCorporateKeys());
        commonTestForAccountsClosingBalance("E32", incomeExpenseItemConfig.getMarginalLendingAndOverdraftKeys());
        commonTestForAccountsClosingBalance("E33", incomeExpenseItemConfig.getInterbankInterestExpensesPaidToKeys());
        commonTestForAccountsClosingBalance("E40", incomeExpenseItemConfig.getForeignExchangeContractKeys());
        commonTestForAccountsClosingBalance("E41", incomeExpenseItemConfig.getDerivativeAndFinancialFutureKeys());

    }

    private void commonTestForAccountsClosingBalance(String cellToCheck, ClosingBalanceQueryKey queryKey) {
        var total = NumberUtils.roundOffValue(queryKey.getAccounts().size() * DEFAULT_CLOSING_BALANCE);
        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(queryKey));
        brf04Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(total, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());
    }

    private List<AccountClosingBalance> closingBalancingForAccounts(ClosingBalanceQueryKey queryKey) {
        return queryKey.getAccounts().stream()

                .map(account -> CollectionUtils.isEmpty(queryKey.getProducts())
                        ? List.of(build(account, "", DEFAULT_CLOSING_BALANCE))
                        : queryKey.getProducts().stream()
                        .map(product -> build(account, product, DEFAULT_CLOSING_BALANCE))
                        .collect(Collectors.toList())

                ).flatMap(List::stream).collect(Collectors.toList());
    }

    private AccountClosingBalance build(String account, String product, double closingBalance) {
        return AccountClosingBalance.builder()
                .id(MainAccountProductId.builder().mainAccount(account).product(product).build())
                .closingBalance(closingBalance).build();
    }

    private Cell getCellByReference(Sheet sheet, String reference) {
        var cellReference = new CellReference(reference);
        return sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
    }
}
