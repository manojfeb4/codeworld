package com.neobank.regulatory.reporting.util;

import lombok.SneakyThrows;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellReference;

import java.io.File;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertEquals;

public final class Resources {

    private Resources() {
    }

    @SneakyThrows
    public static String readFile(String path) {
        URL url = com.google.common.io.Resources.getResource(path);
        return com.google.common.io.Resources.toString(url, StandardCharsets.UTF_8);
    }

    public static File getFile(String path) {
        return new File(path);
    }

    public static void verifyCellData(String cellRef, String data, Sheet sheet) {
        var cellReference = new CellReference(cellRef);
        assertEquals(data, sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol()).toString());
    }

}
