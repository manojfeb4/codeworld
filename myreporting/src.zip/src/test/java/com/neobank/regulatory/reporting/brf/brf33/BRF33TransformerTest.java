package com.neobank.regulatory.reporting.brf.brf33;

import com.neobank.regulatory.reporting.entity.BusinessAccountBalance;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static com.neobank.regulatory.reporting.util.Resources.verifyCellData;

@ExtendWith(MockitoExtension.class)
class BRF33TransformerTest {

    Workbook wb;

    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @InjectMocks
    private BRF33Transformer underTest;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-033.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());

        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
    }

    @Test
    void shouldTransformResidentsSuccessfully() {
        Sheet sheet = wb.getSheetAt(0);
        BusinessAccountBalance businessAccountBalance = getDepositor(100000, "ARE", "Depositor-1");

        BusinessAccountBalance businessAccountBalance2 = getDepositor(9999, "ARE", "Depositor-2");

        List<BusinessAccountBalance> bankingAndMonetaryDataListForResident = List.of(businessAccountBalance,
                businessAccountBalance2);

        underTest.transform(sheet, bankingAndMonetaryDataListForResident);
        verifyResidentTransformation(sheet);
    }

    private BusinessAccountBalance getDepositor(double accountBalance, String country, String name) {
        BusinessAccountBalance residentAccountInfo = new BusinessAccountBalance();
        residentAccountInfo.setAccountBalance(accountBalance);
        residentAccountInfo.setCountryOfIncorporation(country);
        residentAccountInfo.setBusinessName(name);
        return residentAccountInfo;
    }

    private void verifyResidentTransformation(Sheet sheet) {
        verifyCellData("C9", "Depositor-1", sheet);
        verifyCellData("D9", "AE", sheet);
        verifyCellData("E9", "100000.0", sheet);

        verifyCellData("C10", "Depositor-2", sheet);
        verifyCellData("D10", "AE", sheet);
        verifyCellData("E10", "9999.0", sheet);
    }

    @Test
    void shouldTransformNonResidentsSuccessfully() {
        Sheet sheet = wb.getSheetAt(0);
        BusinessAccountBalance businessAccountBalance = getDepositor(100000, "IND", "Depositor-3");

        BusinessAccountBalance businessAccountBalance2 = getDepositor(9999, "IND", "Depositor-4");

        List<BusinessAccountBalance> bankingAndMonetaryDataListForResident = List.of(businessAccountBalance,
                businessAccountBalance2);

        underTest.transform(sheet, bankingAndMonetaryDataListForResident);
        verifyNonResidentTransformation(sheet);
    }

    private void verifyNonResidentTransformation(Sheet sheet) {
        verifyCellData("C28", "Depositor-3", sheet);
        verifyCellData("D28", "IN", sheet);
        verifyCellData("E28", "100000.0", sheet);

        verifyCellData("C29", "Depositor-4", sheet);
        verifyCellData("D29", "IN", sheet);
        verifyCellData("E29", "9999.0", sheet);
    }

}