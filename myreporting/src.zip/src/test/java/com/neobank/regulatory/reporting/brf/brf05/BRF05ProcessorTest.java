package com.neobank.regulatory.reporting.brf.brf05;

import com.neobank.regulatory.reporting.entity.TreasuryInvestment;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.InvestmentRepository;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.neobank.regulatory.reporting.util.Resources.verifyCellData;
import static com.neobank.regulatory.reporting.util.TestConstants.MBILLS_INVESTMENT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BRF05ProcessorTest {

    @InjectMocks
    BRF05Processor underTest;

    Workbook wb;
    TransformationContext payloadData;

    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Mock
    private BRF05Transformer brf05Transformer;

    @Mock
    private InvestmentRepository investmentRepository;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-005.xlsx");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("005", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
    }

    @Test
    void shouldReturnBrfId() {
        assertEquals("BRF-005", underTest.getBrfId());
    }

    @Test
    void shouldReturnBrfProcessor() {
        assertEquals(brf05Transformer, underTest.getBrfTransformer());
    }

    @Test
    void shouldReturnReportingRepository() {
        assertEquals(investmentRepository, underTest.getReportingRepository());
    }

    @Test
    void shouldProcessReportWithoutDataInSource() {

        List<TreasuryInvestment> investments = Collections.emptyList();

        when(investmentRepository.findTreasuryInvestmentByDateEqualsAndProductEquals(any(), any()))
                .thenReturn(investments);

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        verifyCellData("C4", "ADQ Neobank", sheet);
        verifyCellData("J31", "0.0", sheet);
        verifyCellData("K31", "0.0", sheet);

    }

    @Test
    void shouldProcessReportWithDataInSource() {

        List<TreasuryInvestment> investments = getTreasureInvestments();

        when(investmentRepository.findTreasuryInvestmentByDateEqualsAndProductEquals(any(), any()))
                .thenReturn(investments);
        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        Row row = sheet.getRow(3);

        verify(brf05Transformer, times(1)).transform(sheet, investments);

        assertEquals("ADQ Neobank", row.getCell(2).toString());
    }

    private List<TreasuryInvestment> getTreasureInvestments() {
        return List.of(
                TreasuryInvestment.builder().product(MBILLS_INVESTMENT).isin("c12349").bookValue(2533.75).build(),
                TreasuryInvestment.builder().product(MBILLS_INVESTMENT).isin("c12349").bookValue(453454.25).build(),
                TreasuryInvestment.builder().product(MBILLS_INVESTMENT).isin("c12349").bookValue(10.00).build());
    }

}