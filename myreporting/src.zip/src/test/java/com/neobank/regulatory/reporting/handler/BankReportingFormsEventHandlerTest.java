package com.neobank.regulatory.reporting.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neobank.common.event.EventProducer;
import com.neobank.common.exception.NeobankApiException;
import com.neobank.common.exception.model.ErrorMessage;
import com.neobank.regulatory.reporting.services.BRFService;
import com.neobank.regulatory.reporting.util.Resources;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BankReportingFormsEventHandlerTest {

    private final ObjectMapper objectMapper = new ObjectMapper();
    @Mock
    private BRFService brfService;
    @Mock
    private EventProducer eventProducer;


    @Test
    void shouldReadEventSuccessfully() throws IOException {


        BankReportingFormsEventHandler eventHandler = new BankReportingFormsEventHandler(brfService, objectMapper);
        String transformationCompleteNotification = Resources.readFile("event/transformationEvent.json");


        eventHandler.readTransformationCompleteEvent(transformationCompleteNotification);

        verify(brfService, times(1)).processAndUpload(any());

        verifyNoInteractions(eventProducer);
    }

    @Test
    void shouldThrowException() throws IOException {


        BankReportingFormsEventHandler eventHandler = new BankReportingFormsEventHandler(brfService, objectMapper);
        String transformationCompleteNotification = Resources.readFile("event/transformationEvent.json");
        List<ErrorMessage> errorMessages = Lists.newArrayList(ErrorMessage.builder().description("errorid").build());

        doThrow(new NeobankApiException(errorMessages, HttpStatus.BAD_REQUEST)).when(brfService)
                .processAndUpload(any());
        assertThrows(NeobankApiException.class,
                () -> eventHandler.readTransformationCompleteEvent(transformationCompleteNotification));


    }

}