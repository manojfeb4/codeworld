package com.neobank.regulatory.reporting.brf.brf35;

import com.neobank.regulatory.reporting.brf.services.GTreasuryService;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.InvestmentRepository;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellReference;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BRF35ProcessorTest {

    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Mock
    InvestmentRepository investmentRepository;

    @Mock
    GTreasuryService gTreasuryService;

    BRF35Transformer brf35Transformer;

    BRF35Processor underTest;

    Workbook wb;
    TransformationContext payloadData;

    FormulaEvaluator formulaEvaluator;

    @BeforeEach
    public void setup() throws IOException {

        brf35Transformer = spy(new BRF35Transformer(gTreasuryService));

        underTest = new BRF35Processor(brf35Transformer, investmentRepository);

        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-035.xls");

        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("035", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
        formulaEvaluator = wb.getCreationHelper().createFormulaEvaluator();
    }

    @Test
    void shouldReturnBrfId() {
        assertEquals("BRF-035", underTest.getBrfId());
    }

    @Test
    void shouldReturnBrfProcessor() {
        assertEquals(brf35Transformer, underTest.getBrfTransformer());
    }

    @Test
    void shouldReturnReportingRepository() {
        assertEquals(investmentRepository, underTest.getReportingRepository());
    }

    @Test
    void shouldProcessReportWithoutDataInSource() {

        List<String[]> investments = Collections.emptyList();

        when(investmentRepository
                .getTotalBookValueGroupByBranchAndHeadOfficeCountryAndBankAndProductNotForCountry(any(), any(), any(), any(), any()))
                .thenReturn(investments);

        doCallRealMethod().when(gTreasuryService).getTotalBookValueForBankAndProducts(any());
        doCallRealMethod().when(brf35Transformer).transform(any(), any());

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        verifyCellData("C4", "ADQ Neobank", sheet);
        verifyCellData("C11", "NA", sheet);
        verifyCellData("D11", "NA", sheet);
        verifyCellData("E11", "NA", sheet);
        verifyCellFormula("F11", 0.0d, sheet);
        verifyCellFormula("G11", 0.0d, sheet);
        verifyCellFormula("H11", 0.0d, sheet);
        verifyCellFormula("I11", 0.0d, sheet);
        verifyCellData("E12", "TOTAL", sheet);
        verifyCellFormula("F12", 0.0d, sheet);
        verifyCellFormula("G12", 0.0d, sheet);
        verifyCellFormula("H12", 0.0d, sheet);
        verifyCellFormula("I12", 0.0d, sheet);
    }

    @Test
    void shouldProcessReportWithDataInSource() {

        List<String[]> investments = getTotalBookValueGroupByBankAndProduct();

        when(investmentRepository
                .getTotalBookValueGroupByBranchAndHeadOfficeCountryAndBankAndProductNotForCountry(any(), any(), any(), any(), any()))
                .thenReturn(investments);

        doCallRealMethod().when(gTreasuryService).getTotalBookValueForBankAndProducts(any());
        doCallRealMethod().when(brf35Transformer).transform(any(), any());

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        verify(sheet);

    }

    private void verify(Sheet sheet) {
        Row row = sheet.getRow(3);
        assertEquals("ADQ Neobank", row.getCell(2).toString());

        verifyCellData("C4", "ADQ Neobank", sheet);
        verifyCellData("C11", "Any Bank Name 1", sheet);
        verifyCellData("D11", "Bangladesh", sheet);
        verifyCellData("E11", "United Arab Emirates", sheet);
        verifyCellFormula("F11", 300.0d, sheet);
        verifyCellFormula("G11", 0.0d, sheet);
        verifyCellFormula("H11", 150.0d, sheet);
        verifyCellFormula("I11", 0.0d, sheet);
        verifyCellData("C13", "Any Bank Name 3", sheet);
        verifyCellData("D13", "Bangladesh", sheet);
        verifyCellData("E13", "United Arab Emirates", sheet);
        verifyCellFormula("F13", 700.0d, sheet);
        verifyCellFormula("G13", 0.0d, sheet);
        verifyCellFormula("H13", 350.0d, sheet);
        verifyCellFormula("I13", 0.0d, sheet);
        verifyCellData("C14", "Any Bank Name 2", sheet);
        verifyCellData("D14", "Bangladesh", sheet);
        verifyCellData("E14", "Bangladesh", sheet);
        verifyCellFormula("F14", 500.0d, sheet);
        verifyCellFormula("G14", 0.0d, sheet);
        verifyCellFormula("H14", 250.0d, sheet);
        verifyCellFormula("I14", 0.0d, sheet);
        verifyCellData("C12", "Any Bank Name 4", sheet);
        verifyCellData("D12", "Bangladesh", sheet);
        verifyCellData("E12", "Bangladesh", sheet);
        verifyCellFormula("F12", 900.0d, sheet);
        verifyCellFormula("G12", 0.0d, sheet);
        verifyCellFormula("H12", 450.0d, sheet);
        verifyCellFormula("I12", 0.0d, sheet);
        verifyCellData("E16", "TOTAL", sheet);
        verifyCellFormula("F16", 2400.0d, sheet);
        verifyCellFormula("G16", 0.0d, sheet);
        verifyCellFormula("H16", 1200.0d, sheet);
        verifyCellFormula("I16", 0.0d, sheet);
    }

    private List<String[]> getTotalBookValueGroupByBankAndProduct() {
        return List.of(
                new String[]{"Any Bank Name 1", "Bangladesh", "United Arab Emirates", "TERM", "150.00"},
                new String[]{"Any Bank Name 1", "Bangladesh", "United Arab Emirates", "TERM",
                        "150.00"},
                new String[]{"Any Bank Name 1", "Bangladesh", "United Arab Emirates", "CALL",
                        "150.00"},
                new String[]{"Any Bank Name 1", "Bangladesh", "United Arab Emirates", "XXX", "150.00"},
                new String[]{"Any Bank Name 2", "Bangladesh", "Bangladesh", "TERM", "250.00"},
                new String[]{"Any Bank Name 2", "Bangladesh", "Bangladesh", "TERM", "250.00"},
                new String[]{"Any Bank Name 2", "Bangladesh", "Bangladesh", "CALL", "250.00"},
                new String[]{"Any Bank Name 2", "Bangladesh", "Bangladesh", "XXX", "250.00"},
                new String[]{"Any Bank Name 3", "Bangladesh", "United Arab Emirates", "TERM", "350.00"},
                new String[]{"Any Bank Name 3", "Bangladesh", "United Arab Emirates", "TERM",
                        "350.00"},
                new String[]{"Any Bank Name 3", "Bangladesh", "United Arab Emirates", "CALL",
                        "350.00"},
                new String[]{"Any Bank Name 3", "Bangladesh", "United Arab Emirates", "XXX", "350.00"},
                new String[]{"Any Bank Name 4", "Bangladesh", "Bangladesh", "TERM", "450.00"},
                new String[]{"Any Bank Name 4", "Bangladesh", "Bangladesh", "TERM", "450.00"},
                new String[]{"Any Bank Name 4", "Bangladesh", "Bangladesh", "XXX", "450.00"});
    }

    private void verifyCellData(String cellRef, String data, Sheet sheet) {
        var cellReference = new CellReference(cellRef);
        assertEquals(data, sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol()).toString());
    }

    private void verifyCellFormula(String cellRef, Double data, Sheet sheet) {
        var cellReference = new CellReference(cellRef);
        var cell = sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
        assertEquals(data, formulaEvaluator.evaluate(cell).getNumberValue());
    }

}