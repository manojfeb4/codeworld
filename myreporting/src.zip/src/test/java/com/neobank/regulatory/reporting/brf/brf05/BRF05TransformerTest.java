package com.neobank.regulatory.reporting.brf.brf05;

import com.neobank.regulatory.reporting.entity.TreasuryInvestment;
import com.neobank.regulatory.reporting.services.RatingsMappingHandler;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static com.neobank.regulatory.reporting.util.Resources.verifyCellData;
import static com.neobank.regulatory.reporting.util.TestConstants.MBILLS_INVESTMENT;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BRF05TransformerTest {

    public static final String EXTERNAL = "External";

    public static final String FEDERAL_GOVT = "Federal Govt";

    Workbook wb;

    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Mock
    private RatingsMappingHandler ratingsMappingHandler;

    @InjectMocks
    private BRF05Transformer underTest;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-005.xlsx");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());

        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
    }

    @Test
    void shouldTransformSuccessfully() {

        Sheet sheet = wb.getSheetAt(0);

        when(ratingsMappingHandler.getMappedRating("AAA")).thenReturn(1);
        when(ratingsMappingHandler.getMappedRating("AA-")).thenReturn(4);
        when(ratingsMappingHandler.getMappedRating("BB-")).thenReturn(13);

        underTest.transform(sheet, getMBillInvestments());

        verify(sheet);
    }

    private void verify(Sheet sheet) {
        verifyCellData("D31", MBILLS_INVESTMENT, sheet);
        verifyCellData("D32", MBILLS_INVESTMENT, sheet);
        verifyCellData("D33", MBILLS_INVESTMENT, sheet);

        verifyCellData("E31", "ISIN1", sheet);
        verifyCellData("E32", "ISIN2", sheet);
        verifyCellData("E33", "ISIN3", sheet);

        verifyCellData("F31", "1234.65", sheet);
        verifyCellData("F32", "3234.65", sheet);
        verifyCellData("F33", "4234.65", sheet);

        verifyCellData("H31", "United Arab Emirates", sheet);
        verifyCellData("H32", "India", sheet);
        verifyCellData("H33", "Germany", sheet);

        verifyCellData("I31", "AED", sheet);
        verifyCellData("I32", "INR", sheet);
        verifyCellData("I33", "EUR", sheet);

        verifyCellData("K31", "2.53", sheet);
        verifyCellData("K32", "453.45", sheet);
        verifyCellData("K33", "100000.0", sheet);

        verifyCellData("L31", "1.0", sheet);
        verifyCellData("L32", "4.0", sheet);
        verifyCellData("L33", "13.0", sheet);

        verifyCellData("M31", EXTERNAL, sheet);
        verifyCellData("M32", EXTERNAL, sheet);
        verifyCellData("M33", EXTERNAL, sheet);

        verifyCellData("O31", FEDERAL_GOVT, sheet);
        verifyCellData("O32", FEDERAL_GOVT, sheet);
        verifyCellData("O33", FEDERAL_GOVT, sheet);

        verifyCellData("K34", "SUM(K31:K33)", sheet);

    }

    private List<TreasuryInvestment> getMBillInvestments() {
        return List.of(
                TreasuryInvestment.builder().product(MBILLS_INVESTMENT).isin("ISIN1").bookValue(2.53)
                        .faceValue(1234.65).countryOfBranch("United Arab Emirates").currencyDescription("AED")
                        .marketValue(2345.68).issueRating("AAA").build(),
                TreasuryInvestment.builder().product(MBILLS_INVESTMENT).isin("ISIN2").countryOfBranch("India")
                        .currencyDescription("INR").bookValue(453.45).marketValue(100000.00)
                        .faceValue(3234.65).issueRating("AA-").build(),
                TreasuryInvestment.builder().product(MBILLS_INVESTMENT).isin("ISIN3").countryOfBranch("Germany")
                        .currencyDescription("EUR").issueRating("BB-").bookValue(100000.0)
                        .marketValue(90909.09).faceValue(4234.65).build());
    }

}