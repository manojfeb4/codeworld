package com.neobank.regulatory.reporting.brf.brf53;

import com.neobank.regulatory.reporting.config.GlobalIncomeExpenseAccountsConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.entity.MainAccountProductId;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.util.ConfigUtil;
import com.neobank.regulatory.reporting.util.NumberUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class BRF53ProcessorTest {

    private static final double DEFAULT_CLOSING_BALANCE = 99.99d;
    static GlobalIncomeExpenseAccountsConfig globalIncomeExpenseAccountsConfig;

    static {
        globalIncomeExpenseAccountsConfig = ConfigUtil.read("mapping/global-income-expense-accounts.yml",
                "global-income-expense-accounts", GlobalIncomeExpenseAccountsConfig.class);

    }

    Workbook wb;
    TransformationContext payloadData;
    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @InjectMocks
    BRF53Processor brf53Processor;

    @Mock
    private AccountClosingBalanceRepository accountClosingBalanceRepository;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-053.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("053", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
        //
        BRF53Transformer brf53Transformer = Mockito.spy(new BRF53Transformer());
        //
        brf53Processor = new BRF53Processor(brf53Transformer, accountClosingBalanceRepository,
                new AccountsClosingBalanceService(), globalIncomeExpenseAccountsConfig);
    }

    @Test
    void mustPassValidRequest() {
        assertNotNull(brf53Processor);

        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(globalIncomeExpenseAccountsConfig.getInvestmentIncomeKeys()));

        brf53Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, "D12");
        assertEquals(399.96d, cell.getNumericCellValue(), "must be equal");
        assertNotNull(brf53Processor.getBrfTransformer());
        assertNull(brf53Processor.getReportingRepository());
    }

    @Test
    void mustPassAllClosingBalanceAccountsCalls() {
        commonTestForAccountsClosingBalance("D12", globalIncomeExpenseAccountsConfig.getInvestmentIncomeKeys());
        commonTestForAccountsClosingBalance("D13", globalIncomeExpenseAccountsConfig.getOtherOperatingIncomeKeys());
        commonTestForAccountsClosingBalance("D14", globalIncomeExpenseAccountsConfig.getInterestExpenseKeys());
        commonTestForAccountsClosingBalance("D16", globalIncomeExpenseAccountsConfig.getStaffExpenseKeys());
        commonTestForAccountsClosingBalance("D17", globalIncomeExpenseAccountsConfig.getPremisesExpenseKeys());
        commonTestForAccountsClosingBalance("D18",
                globalIncomeExpenseAccountsConfig.getDepreciationAndAmortisationKeys());
        commonTestForAccountsClosingBalance("D19",
                globalIncomeExpenseAccountsConfig.getOtherAdminAndGeneralExpenseKeys());

    }

    private void commonTestForAccountsClosingBalance(String cellToCheck, ClosingBalanceQueryKey queryKey) {
        var total = NumberUtils.roundOffValue(queryKey.getAccounts().size() * DEFAULT_CLOSING_BALANCE);
        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(queryKey));
        brf53Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(total, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());
    }

    private List<AccountClosingBalance> closingBalancingForAccounts(ClosingBalanceQueryKey queryKey) {
        return queryKey.getAccounts().stream()

                .map(account -> CollectionUtils.isEmpty(queryKey.getProducts())
                        ? List.of(build(account, "", DEFAULT_CLOSING_BALANCE))
                        : queryKey.getProducts().stream()
                        .map(product -> build(account, product, DEFAULT_CLOSING_BALANCE))
                        .collect(Collectors.toList())

                ).flatMap(List::stream).collect(Collectors.toList());
    }

    private AccountClosingBalance build(String account, String product, double closingBalance) {
        return AccountClosingBalance.builder()
                .id(MainAccountProductId.builder().mainAccount(account).product(product).build())
                .closingBalance(closingBalance).build();
    }

    private Cell getCellByReference(Sheet sheet, String reference) {
        var cellReference = new CellReference(reference);
        return sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
    }
}
