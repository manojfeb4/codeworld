package com.neobank.regulatory.reporting.services;

import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.model.LiabilitiesCapitalQueryKey;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class LiabilitiesCapitalServiceTest {

    @InjectMocks
    private LiabilitiesCapitalService liabilitiesCapitalService;

    @Test
    void test() {
        assertNotNull(liabilitiesCapitalService);
        assertEquals(0, liabilitiesCapitalService.closingBalance(null, null));
        assertEquals(0, liabilitiesCapitalService.closingBalance(List.of(), null));
        assertEquals(0, liabilitiesCapitalService.closingBalance(List.of(new AccountClosingBalance()),
                new LiabilitiesCapitalQueryKey()));

    }
}
