package com.neobank.regulatory.reporting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class RegulatoryReportPublishServiceApplicationTest {

    @Test
    void contextLoads() {
        assertEquals(2, 1 + 1);
    }

}