package com.neobank.regulatory.reporting.brf.brf34;

import com.neobank.regulatory.reporting.brf.services.GTreasuryService;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.InvestmentRepository;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellReference;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doCallRealMethod;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BRF34ProcessorTest {

    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Mock
    InvestmentRepository investmentRepository;

    @Mock
    BRF34Transformer brf34Transformer;

    @Mock
    GTreasuryService gTreasuryService;

    @InjectMocks
    BRF34Processor underTest;

    Workbook wb;
    TransformationContext payloadData;

    FormulaEvaluator formulaEvaluator;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-034.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("034", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
        formulaEvaluator = wb.getCreationHelper().createFormulaEvaluator();
    }

    @Test
    void shouldReturnBrfId() {
        assertEquals("BRF-034", underTest.getBrfId());
    }

    @Test
    void shouldReturnBrfProcessor() {
        assertEquals(brf34Transformer, underTest.getBrfTransformer());
    }

    @Test
    void shouldReturnReportingRepository() {
        assertEquals(investmentRepository, underTest.getReportingRepository());
    }

    @Test
    void shouldProcessReportWithoutDataInSource() {

        List<String[]> investments = Collections.emptyList();

        when(investmentRepository.getTotalBookValueGroupByHeadOfficeCountryAndBankAndProductForCountry(any(), any(), any(), any(), any()))
                .thenReturn(investments);

        doCallRealMethod().when(gTreasuryService).getTotalBookValueGroupByBankAndProduct(any(), any());

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        verifyCellData("C4", "ADQ Neobank", sheet);
        verifyCellData("C11", "", sheet);
        verifyCellFormula("D10", 0.0d, sheet);
        verifyCellFormula("D42", 0.0d, sheet);
        verifyCellFormula("D99", 0.0d, sheet);
        verifyCellData("C43", "", sheet);
        verifyCellFormula("H10", 0.0d, sheet);
        verifyCellFormula("H42", 0.0d, sheet);
        verifyCellFormula("H99", 0.0d, sheet);
    }

    @Test
    void shouldProcessReportWithDataInSource() {

        List<String[]> investments = getTotalBookValueGroupByBankAndProduct();

        when(investmentRepository.getTotalBookValueGroupByHeadOfficeCountryAndBankAndProductForCountry(any(), any(), any(), any(),any()))
                .thenReturn(investments);

        doCallRealMethod().when(gTreasuryService).getTotalBookValueGroupByBankAndProduct(any(), any());

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);
        Sheet sheet = wb.getSheetAt(0);

        Row row = sheet.getRow(3);
        assertEquals("ADQ Neobank", row.getCell(2).toString());

        verifyCellData("C4", "ADQ Neobank", sheet);
        verifyCellData("C11", "Any Bank Name 1", sheet);
        verifyCellData("C12", "Any Bank Name 3", sheet);
        verifyCellFormula("D10", 500.0, sheet);
        verifyCellFormula("D42", 15350.0, sheet);
        verifyCellFormula("D99", 15850.0, sheet);
        verifyCellData("C43", "Any Bank Name 2", sheet);
        verifyCellData("C44", "Any Bank Name 4", sheet);
        verifyCellFormula("H10", 40001.0, sheet);
        verifyCellFormula("H42", 40001.0, sheet);

        verifyCellFormula("H99", 80002.0, sheet);
    }

    private List<String[]> getTotalBookValueGroupByBankAndProduct() {
        return List.of(new String[]{"United Arab Emirates", "Any Bank Name 1", "TERM", "150.00"},
                new String[]{"United Arab Emirates", "Any Bank Name 1", "TERM", "100.00"},
                new String[]{"United Arab Emirates", "Any Bank Name 1", "CALL", "20000.50"},
                new String[]{"United Arab Emirates", "Any Bank Name 1", "XXX", "20000.50"},
                new String[]{"Banladesh", "Any Bank Name 2", "TERM", "150.00"},
                new String[]{"Banladesh", "Any Bank Name 2", "TERM", "100.000"},
                new String[]{"Banladesh", "Any Bank Name 2", "CALL", "20000.50"},
                new String[]{"Banladesh", "Any Bank Name 2", "XXX", "20000.50"},
                new String[]{"United Arab Emirates", "Any Bank Name 3", "TERM", "150.00"},
                new String[]{"United Arab Emirates", "Any Bank Name 3", "TERM", "100.00"},
                new String[]{"United Arab Emirates", "Any Bank Name 3", "CALL", "20000.50"},
                new String[]{"United Arab Emirates", "Any Bank Name 3", "XXX", "20000.50"},
                new String[]{"Banladesh", "Any Bank Name 4", "TERM", "15000.00"},
                new String[]{"Banladesh", "Any Bank Name 4", "TERM", "100.00"},
                new String[]{"Banladesh", "Any Bank Name 4", "XXX", "20000.50"});
    }

    private void verifyCellData(String cellRef, String data, Sheet sheet) {
        var cellReference = new CellReference(cellRef);
        assertEquals(data, sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol()).toString());
    }

    private void verifyCellFormula(String cellRef, Double data, Sheet sheet) {
        var cellReference = new CellReference(cellRef);
        var cell = sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
        assertEquals(data, formulaEvaluator.evaluate(cell).getNumberValue());
    }

}