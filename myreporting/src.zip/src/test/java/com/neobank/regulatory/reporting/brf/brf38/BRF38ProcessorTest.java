package com.neobank.regulatory.reporting.brf.brf38;


import com.neobank.regulatory.reporting.entity.RemittanceId;
import com.neobank.regulatory.reporting.entity.RemittanceInfo;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.RemittanceRepository;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.neobank.regulatory.reporting.util.Resources.verifyCellData;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BRF38ProcessorTest {

    @Mock

    BRF38Processor underTest;
    Workbook wb;
    TransformationContext payloadData;
    ResourceLoader resourceLoader = new DefaultResourceLoader();
    @Mock
    private RemittanceRepository remittanceRepository;
    private BRF38Transformer brf38Transformer;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-038.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        brf38Transformer = spy(new BRF38Transformer());
        underTest = new BRF38Processor(brf38Transformer, remittanceRepository);
        payloadData = new TransformationContext("038", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
    }

    @Test
    void shouldReturnBrfId() {
        assertEquals("BRF-038", underTest.getBrfId());
    }

    @Test
    void shouldReturnBrfProcessor() {
        assertEquals(brf38Transformer, underTest.getBrfTransformer());
    }

    @Test
    void shouldReturnReportingRepository() {
        assertEquals(remittanceRepository, underTest.getReportingRepository());
    }

    @Test
    void shouldProcessReportWithoutDataInSource() {

        List<RemittanceInfo> remittanceInfoList = Collections.emptyList();

        when(remittanceRepository.getCountryWiseRemittance(any(), any(), any(), any(), any()))
                .thenReturn(remittanceInfoList);


        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        verifyCellData("C4", "ADQ Neobank", sheet);
        verifyCellData("G23", "0.0", sheet);
        verifyCellData("K23", "0.0", sheet);

    }

    @Test
    void shouldProcessReportWithDataInSource() {

        List<RemittanceInfo> remittanceInfoList = getRemittanceInfo();

        when(remittanceRepository.getCountryWiseRemittance(any(), any(), any(), any(), any()))
                .thenReturn(remittanceInfoList);

        doCallRealMethod().when(brf38Transformer).transform(any(), any());

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        Row row = sheet.getRow(3);

        verify(brf38Transformer, times(1)).transform(sheet, remittanceInfoList);

        assertEquals("ADQ Neobank", row.getCell(2).toString());
        verifyCellData("D11", "1111.11", sheet);
        verifyCellData("E19", "2222.22", sheet);
        verifyCellData("D39", "3333.33", sheet);
        verifyCellData("G51", "4444.44", sheet);
        verifyCellData("D55", "5555.56", sheet);
        verifyCellData("E65", "6666.67", sheet);
        verifyCellData("G82", "7777.78", sheet);
        verifyCellData("D85", "8888.89", sheet);
        verifyCellData("E88", "10000.0", sheet);
        verifyCellData("F43", "600.0", sheet);
        verifyCellData("F32", "500.0", sheet);


    }

    private List<RemittanceInfo> getRemittanceInfo() {
        return List.of(
                setRemittanceInfo("CA", "Family", 1111.11),
                setRemittanceInfo("FR", "Investment", 2222.22),
                setRemittanceInfo("QA", "Family", 3333.33),
                setRemittanceInfo("YE", "Other", 4444.44),
                setRemittanceInfo("NG", "Family", 5555.56),
                setRemittanceInfo("JP", "Investment", 6666.67),
                setRemittanceInfo("PE", "Other", 7777.78),
                setRemittanceInfo("AU", "Family", 8888.89),
                setRemittanceInfo("AQ", "Investment", 10000.0),

                setRemittanceInfo("SE", "Trade", 500.0),
                setRemittanceInfo("EG", "Trade", 600.0),
                setRemittanceInfo("XX", "Trade", 600.0));


    }

    private RemittanceInfo setRemittanceInfo(String recipientCountry, String transferPurpose, double totalTransferredAmount) {
        RemittanceId remittanceId = new RemittanceId();
        remittanceId.setRecipientCountry(recipientCountry);
        remittanceId.setTransferPurpose(transferPurpose);
        RemittanceInfo remittanceInfo = new RemittanceInfo();
        remittanceInfo.setRemittanceId(remittanceId);
        remittanceInfo.setTotalTransferredAmount(totalTransferredAmount);
        return remittanceInfo;
    }
}