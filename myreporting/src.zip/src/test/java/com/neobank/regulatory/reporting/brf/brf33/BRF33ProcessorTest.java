package com.neobank.regulatory.reporting.brf.brf33;

import com.neobank.regulatory.reporting.entity.BusinessAccountBalance;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AnalyticsAccountInfoRepository;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.neobank.regulatory.reporting.util.Resources.verifyCellData;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BRF33ProcessorTest {

    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Mock
    AnalyticsAccountInfoRepository accountRepository;

    @Mock
    BRF33Transformer brf33Transformer;

    @InjectMocks
    BRF33Processor underTest;

    Workbook wb;
    TransformationContext payloadData;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-033.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("033", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
    }

    @Test
    void process() {

        List<BusinessAccountBalance> bankingAndMonetaryDataListForResident = getDepositors(100000, "UAE",
                "Depositor-1");

        List<BusinessAccountBalance> bankingAndMonetaryDataListForNonResident = getDepositors(99999, "UK",
                "Depositor-2");

        when(accountRepository.getTop15ResidentDepositors(any())).thenReturn(bankingAndMonetaryDataListForResident);
        when(accountRepository.getTop15NonResidentDepositors(any()))
                .thenReturn(bankingAndMonetaryDataListForNonResident);

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        verifyCellData("C4", "ADQ Neobank", sheet);

        verify(brf33Transformer, times(1)).transform(sheet, bankingAndMonetaryDataListForResident);
        verify(brf33Transformer, times(1)).transform(sheet, bankingAndMonetaryDataListForNonResident);
        /*
         * Row row = sheet.getRow(8); assertEquals("Depositor-1",
         * row.getCell(2).toString()); assertEquals("UAE", row.getCell(3).toString());
         * assertEquals("100000.0", row.getCell(4).toString());
         *
         * row = sheet.getRow(27); assertEquals("Depositor-2", row.getCell(2).toString());
         * assertEquals("UK", row.getCell(3).toString()); assertEquals("99999.0",
         * row.getCell(4).toString());
         */

    }

    @NotNull
    private List<BusinessAccountBalance> getDepositors(double v, String uae, String s) {
        List<BusinessAccountBalance> residentDepositorsByNames = new ArrayList<>();
        BusinessAccountBalance residentAccountInfo = new BusinessAccountBalance();
        residentAccountInfo.setAccountBalance(v);
        residentAccountInfo.setCountryOfIncorporation(uae);
        residentAccountInfo.setBusinessName(s);
        residentDepositorsByNames.add(residentAccountInfo);
        return residentDepositorsByNames;
    }

}