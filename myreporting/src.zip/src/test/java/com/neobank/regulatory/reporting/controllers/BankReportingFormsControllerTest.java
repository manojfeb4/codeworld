package com.neobank.regulatory.reporting.controllers;

import com.neobank.regulatory.reporting.repository.AnalyticsAccountInfoRepository;
import com.neobank.regulatory.reporting.services.AzureStorageAccountConnectorService;
import org.apache.commons.compress.utils.Lists;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@AutoConfigureMockMvc
class BankReportingFormsControllerTest {

    @Autowired
    protected MockMvc mvc;

    @MockBean
    AnalyticsAccountInfoRepository accountRepository;

    @MockBean
    AzureStorageAccountConnectorService azureStorageAccountConnectorService;

    @Test
    void processBrfSuccess() throws Exception {

        var request = post("/api/v1/process/033?download=false");
        when(accountRepository.getTop15NonResidentDepositors(any())).thenReturn(Lists.newArrayList());
        when(accountRepository.getTop15ResidentDepositors(any())).thenReturn(Lists.newArrayList());

        mvc.perform(request).andExpect(status().isOk());
    }

    @Test
    void processBrfUnsupportedRequest() throws Exception {

        var request = get("/api/v1/process/033?download=false");

        mvc.perform(request).andExpect(status().isMethodNotAllowed());

    }

}