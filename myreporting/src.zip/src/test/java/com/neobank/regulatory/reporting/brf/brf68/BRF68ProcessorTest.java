package com.neobank.regulatory.reporting.brf.brf68;


import com.neobank.regulatory.reporting.entity.EmirateDepositId;
import com.neobank.regulatory.reporting.entity.EmirateDepositInfo;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.EmirateDepositRepository;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.neobank.regulatory.reporting.util.Resources.verifyCellData;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BRF68ProcessorTest {

    @Mock
    BRF68Processor underTest;
    Workbook wb;
    ResourceLoader resourceLoader = new DefaultResourceLoader();
    TransformationContext payloadData;

    @Mock
    private EmirateDepositRepository emirateDepositRepository;

    private BRF68Transformer brf68Transformer;

    @BeforeEach
    public void setup() throws IOException {

        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-068.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        brf68Transformer = spy(new BRF68Transformer());
        underTest = new BRF68Processor(brf68Transformer, emirateDepositRepository);
        payloadData = new TransformationContext("068", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
    }

    @Test
    void shouldReturnBrfId() {
        assertEquals("BRF-068", underTest.getBrfId());
    }

    @Test
    void shouldReturnBrfProcessor() {
        assertEquals(brf68Transformer, underTest.getBrfTransformer());
    }

    @Test
    void shouldReturnReportingRepository() {
        assertEquals(emirateDepositRepository, underTest.getReportingRepository());
    }

    @Test
    void shouldProcessReportWithoutDataInSource() {

        List<EmirateDepositInfo> emirateDepositInfoList = Collections.emptyList();

        when(emirateDepositRepository.getEmirateWiseDeposits(any(), any()))
                .thenReturn(emirateDepositInfoList);


        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);
        Sheet sheet = wb.getSheetAt(0);

        verifyCellData("C4", "ADQ Neobank", sheet);


    }

    @Test
    void shouldProcessReportWithDataInSource_CurrentAccount() {

        List<EmirateDepositInfo> emirateDepositInfoList = getEmirateDepositInfoCurrentAccount();


        when(emirateDepositRepository.getEmirateWiseDeposits(any(), any()))
                .thenReturn(emirateDepositInfoList);

        doCallRealMethod().when(brf68Transformer).transform(any(), any());

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);
        Sheet sheet = wb.getSheetAt(0);

        verify(brf68Transformer, times(1)).transform(sheet, emirateDepositInfoList);

        verifyCellData("G23", "35.0", sheet);

        verifyCellData("K23", "4.0", sheet);
        verifyCellData("L23", "10.0", sheet);

        verifyCellData("O23", "10.0", sheet);
        verifyCellData("P23", "1000.0", sheet);

        verifyCellData("S23", "15.0", sheet);
        verifyCellData("T23", "20000.0", sheet);

        verifyCellData("AA23", "120.0", sheet);
        verifyCellData("AB23", "120000.0", sheet);

        verifyCellData("AE23", "140.0", sheet);
        verifyCellData("AF23", "220000.0", sheet);


    }

    @Test
    void shouldProcessReportWithDataInSource_RegularSavings() {

        List<EmirateDepositInfo> emirateDepositInfoList = getEmirateDepositInfoRegularSavings();

        when(emirateDepositRepository.getEmirateWiseDeposits(any(), any()))
                .thenReturn(emirateDepositInfoList);

        doCallRealMethod().when(brf68Transformer).transform(any(), any());
        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);
        Sheet sheet = wb.getSheetAt(0);
        verify(brf68Transformer, times(1)).transform(sheet, emirateDepositInfoList);


        verifyCellData("G24", "35.0", sheet);

        verifyCellData("K24", "4.0", sheet);
        verifyCellData("L24", "10.0", sheet);

        verifyCellData("O24", "10.0", sheet);
        verifyCellData("P24", "1000.0", sheet);

        verifyCellData("S24", "15.0", sheet);
        verifyCellData("T24", "20000.0", sheet);

        verifyCellData("AA24", "120.0", sheet);
        verifyCellData("AB24", "120000.0", sheet);


    }


    private List<EmirateDepositInfo> getEmirateDepositInfoCurrentAccount() {
        return List.of(

                setEmirateDepositInfo("Abu Dhabi", "CURRENT_ACCOUNT", 2, 4, 10.0),
                setEmirateDepositInfo("Dubai", "CURRENT_ACCOUNT", 3, 10, 1000.0),
                setEmirateDepositInfo("Sharjah", "CURRENT_ACCOUNT", 1, 15, 20000.0),
                setEmirateDepositInfo("Ras Al Khaimah", "CURRENT_ACCOUNT", 6, 120, 120000.0),
                setEmirateDepositInfo("Umm Al Quwain", "CURRENT_ACCOUNT", 8, 140, 220000.0),
                setEmirateDepositInfo("Fujairah", "CURRENT_ACCOUNT", 15, 160, 520000.0)


        );

    }


    private List<EmirateDepositInfo> getEmirateDepositInfoRegularSavings() {
        return List.of(

                setEmirateDepositInfo("Abu Dhabi", "REGULAR_SAVINGS", 2, 4, 10.0),
                setEmirateDepositInfo("Dubai", "REGULAR_SAVINGS", 3, 10, 1000.0),
                setEmirateDepositInfo("Sharjah", "REGULAR_SAVINGS", 1, 15, 20000.0),
                setEmirateDepositInfo("Ras Al Khaimah", "REGULAR_SAVINGS", 6, 120, 120000.0),
                setEmirateDepositInfo("Umm Al Quwain", "REGULAR_SAVINGS", 8, 140, 220000.0),
                setEmirateDepositInfo("Fujairah", "REGULAR_SAVINGS", 15, 160, 520000.0)

        );

    }

    private EmirateDepositInfo setEmirateDepositInfo(String registeredAddressEmirate, String accountType, int numberOfCustomers, int numberOfAccounts, double sumOfAccoutBalance) {
        EmirateDepositId emirateDepositId = new EmirateDepositId();
        emirateDepositId.setRegisteredAddressEmirate(registeredAddressEmirate);
        emirateDepositId.setAccountType(accountType);
        EmirateDepositInfo emirateDepositInfo = new EmirateDepositInfo();
        emirateDepositInfo.setEmirateDepositId(emirateDepositId);
        emirateDepositInfo.setNumberOfAccounts(numberOfAccounts);
        emirateDepositInfo.setNumberOfCustomers(numberOfCustomers);
        emirateDepositInfo.setTotalAccountBalance(sumOfAccoutBalance);

        return emirateDepositInfo;
    }
}