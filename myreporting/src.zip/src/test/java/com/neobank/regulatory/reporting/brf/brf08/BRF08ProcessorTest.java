package com.neobank.regulatory.reporting.brf.brf08;

import com.neobank.regulatory.reporting.config.AccountsClosingBalanceConfig;
import com.neobank.regulatory.reporting.config.LiquidAssetsRatioConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.entity.MainAccountProductId;
import com.neobank.regulatory.reporting.entity.ProductIssueRatingBookValue;
import com.neobank.regulatory.reporting.model.LiquidAssetsRatioQueryKey;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.ProductIssueRatingBookValueRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.services.ProductsBookValueService;
import com.neobank.regulatory.reporting.util.ConfigUtil;
import com.neobank.regulatory.reporting.util.NumberUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class BRF08ProcessorTest {

    private static final double DEFAULT_BOOK_VALUE = 29.99d;
    private static final double DEFAULT_CLOSING_BALANCE = 99.99d;
    static AccountsClosingBalanceConfig accountsClosingBalanceConfig;
    static LiquidAssetsRatioConfig liquidAssetsRatioConfig;

    static {
        liquidAssetsRatioConfig = ConfigUtil.read("mapping/liquid-assets-ratio.yml", "liquid-assets-ratio",
                LiquidAssetsRatioConfig.class);
    }

    Workbook wb;
    TransformationContext payloadData;
    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @InjectMocks
    BRF08Processor brf08Processor;

    @Mock
    private AccountClosingBalanceRepository accountClosingBalanceRepository;

    @Mock
    private ProductIssueRatingBookValueRepository productIssueRatingBookValueRepository;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-008.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("008", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
        //
        BRF08Transformer brf01Transformer = Mockito.spy(new BRF08Transformer());
        //
        brf08Processor = new BRF08Processor(brf01Transformer, accountClosingBalanceRepository,
                productIssueRatingBookValueRepository, liquidAssetsRatioConfig, new AccountsClosingBalanceService(),
                new ProductsBookValueService());

    }

    @Test
    void mustPassValidRequest() {
        assertNotNull(brf08Processor);

        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(liquidAssetsRatioConfig.getPhysicalCashInHand()));

//		Mockito.when(productIssueRatingBookValueRepository.getIssueRatingsForProduct(Mockito.any()))
//				.thenReturn(bookValueForProducts(liquidAssetsRatioConfig.getPhysicalCashInHand()));

        brf08Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, "D8");
        assertEquals(199.98d, cell.getNumericCellValue(), "must be equal");
        assertNotNull(brf08Processor.getBrfTransformer());
        assertNull(brf08Processor.getReportingRepository());
    }

    @Test
    void mustPassAllClosingBalanceAccountsCalls() {
        commonTestForAccountsClosingBalance("D9", liquidAssetsRatioConfig.getStatutoryReservesCB());
        commonTestForAccountsClosingBalance("D10", liquidAssetsRatioConfig.getFreeOtherAccountBalancesCB());
        commonTestForAccountsClosingBalance("E21", liquidAssetsRatioConfig.getTotalLiabilities());
    }

    @Test
    void mustPassAllBookValueForProductsCalls() {
        commonTestForProductsBookValue("D14", liquidAssetsRatioConfig.getGovernmentPubliclyTradedDebtSecurities());
//		commonTestForProductsBookValue("F25", productsBookValueConfig.getInterbankPlacements());
//		commonTestForProductsBookValue("F43", productsBookValueConfig.getAssetsHeldMBills());
    }

    private void commonTestForAccountsClosingBalance(String cellToCheck, LiquidAssetsRatioQueryKey queryKey) {
        var total = NumberUtils.roundOffValue(queryKey.getAccounts().size() * DEFAULT_CLOSING_BALANCE);
        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(queryKey));
        brf08Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(total, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());
    }

    private void commonTestForProductsBookValue(String cellToCheck, LiquidAssetsRatioQueryKey queryKey) {
        var total = queryKey.getProducts().size() * DEFAULT_BOOK_VALUE;
        Mockito.when(productIssueRatingBookValueRepository.getIssueRatingsForProduct(Mockito.any()))
                .thenReturn(bookValueForProducts(queryKey));

        brf08Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(total, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());
    }

    private List<AccountClosingBalance> closingBalancingForAccounts(LiquidAssetsRatioQueryKey queryKey) {
        return queryKey.getAccounts().stream()
                .map(c -> AccountClosingBalance.builder().id(MainAccountProductId.builder().mainAccount(c).build())
                        .closingBalance(DEFAULT_CLOSING_BALANCE).build())
                .collect(Collectors.toList());
    }

    private List<ProductIssueRatingBookValue> bookValueForProducts(LiquidAssetsRatioQueryKey queryKey) {
        return queryKey.getProducts().stream().map(c -> ProductIssueRatingBookValue.builder()
                .id(ProductIssueRatingBookValue.ProductIssueRatingBookValueId.builder().issueRating("A+").product(c).build())
                .bookValue(DEFAULT_BOOK_VALUE).build()).collect(Collectors.toList());
    }

    private Cell getCellByReference(Sheet sheet, String reference) {
        var cellReference = new CellReference(reference);
        return sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
    }
}
