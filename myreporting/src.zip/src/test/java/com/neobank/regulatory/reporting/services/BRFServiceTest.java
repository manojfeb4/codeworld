package com.neobank.regulatory.reporting.services;

import com.neobank.regulatory.reporting.brf.BRFProcessor;
import com.neobank.regulatory.reporting.brf.brf33.BRF33Processor;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@RunWith(JUnit4.class)
class BRFServiceTest {


    BRFService underTest;
    @Mock
    AzureStorageAccountConnectorService azureStorageAccountConnectorService;
    private ResourceLoader resourceLoader = new DefaultResourceLoader();
    @Mock
    private BRFUploader brfUploader;
    private List<BRFProcessor> brfProcessors;
    @Mock
    private BRF33Processor brf33Processor;
    @Mock
    private Workbook wb;
    @Mock
    private TransformationContext payloadData;

    @BeforeEach
    public void setup() throws IOException {
        brfProcessors = new ArrayList<>();
        brfProcessors.add(brf33Processor);
        when(brf33Processor.getBrfId()).thenReturn("BRF-033");
        underTest = new BRFService(resourceLoader, brfUploader, brfProcessors);
        underTest.init();
    }

    @Test
    void processAndUpload_Success() throws IOException {
        underTest.processAndUpload(new TransformationContext("033", LocalDate.now(), LocalDate.now(), "", ""));


        Mockito.verify(brf33Processor, times(1)).process(any(), any());
        Mockito.verify(brfUploader, times(1)).uploadWorkbook(any(), any(), any());
    }


    @Test
    void shouldThrowResponseStatusException() {

        doThrow(new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "")).when(brfUploader).uploadWorkbook(any(), any(), any());

        assertThrows(ResponseStatusException.class, () -> brfUploader.uploadWorkbook(wb, "test", payloadData));
    }

}