package com.neobank.regulatory.reporting.brf.brf93;


import com.neobank.regulatory.reporting.config.ClientSegmentConfig;
import com.neobank.regulatory.reporting.config.PaymentTransferPurposeConfig;
import com.neobank.regulatory.reporting.entity.InternationalPaymentId;
import com.neobank.regulatory.reporting.entity.InternationalPaymentInfo;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.InternationalPaymentRepository;
import com.neobank.regulatory.reporting.util.ConfigUtil;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.neobank.regulatory.reporting.util.Resources.verifyCellData;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BRF93ProcessorTest {

    static ClientSegmentConfig clientSegmentConfig;
    static PaymentTransferPurposeConfig paymentTransferPurposeConfig;

    static {
        clientSegmentConfig = ConfigUtil.read("mapping/client-segment-values.yml", "client-segment-classification",
                ClientSegmentConfig.class);
        paymentTransferPurposeConfig = ConfigUtil.read("mapping/payment-transfer-purpose.yml", "payment-transfer-purpose",
                PaymentTransferPurposeConfig.class);
    }


    Workbook wb;
    TransformationContext payloadData;
    ResourceLoader resourceLoader = new DefaultResourceLoader();
    @Mock
    BRF93Processor underTest;
    @Mock
    private InternationalPaymentRepository internationalPaymentRepository;
    @Mock
    private BRF93Transformer brf93Transformer;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-093.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        brf93Transformer = new BRF93Transformer();
        underTest = new BRF93Processor(brf93Transformer,
                paymentTransferPurposeConfig,
                clientSegmentConfig, internationalPaymentRepository
        );
        payloadData = new TransformationContext("093", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
    }

    @Test
    void shouldReturnBrfId() {
        assertEquals("BRF-093", underTest.getBrfId());
    }

    @Test
    void shouldReturnBrfProcessor() {
        assertEquals(brf93Transformer, underTest.getBrfTransformer());
    }


    @Test
    void shouldProcessReportWithoutDataInSource() {

        List<InternationalPaymentInfo> paymentInfoList = Collections.emptyList();

        when(internationalPaymentRepository.getPaymentsByCountryAndClientSegments(any(), any(), any(), any(), any(),
                any(), any(), any(), any()))
                .thenReturn(paymentInfoList);


        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        verifyCellData("C4", "ADQ Neobank", sheet);
        verifyCellData("G23", "0.0", sheet);
        verifyCellData("K23", "0.0", sheet);

    }

    @Test
    void shouldProcessReportWithDataInSource() {

        var paymentInfoList = getInternationalPaymentInfo();

        when(internationalPaymentRepository.getPaymentsByCountryAndClientSegments(any(), any(), any(), any(), any(),
                any(), any(), any(), any()))
                .thenReturn(paymentInfoList);


        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        Row row = sheet.getRow(3);


        assertEquals("ADQ Neobank", row.getCell(2).toString());
        verifyCellData("D11", "10.0", sheet);
        verifyCellData("E11", "1111.11", sheet);

        verifyCellData("F19", "11.0", sheet);
        verifyCellData("G19", "2222.22", sheet);

        verifyCellData("F19", "11.0", sheet);
        verifyCellData("G19", "2222.22", sheet);

        verifyCellData("H51", "13.0", sheet);
        verifyCellData("I51", "4444.44", sheet);

        verifyCellData("H51", "13.0", sheet);
        verifyCellData("I51", "4444.44", sheet);

        verifyCellData("V85", "17.0", sheet);
        verifyCellData("W85", "8888.89", sheet);


    }

    private List<InternationalPaymentInfo> getInternationalPaymentInfo() {
        return List.of(
                setInternationalPaymentInfo("CA", "Financial Investment", 10, 1111.11),
                setInternationalPaymentInfo("FR", "Direct Investment", 11, 2222.22),
                setInternationalPaymentInfo("QA", "Individual - Family Support", 12, 3333.33),
                setInternationalPaymentInfo("YE", "Services", 13, 4444.44),
                setInternationalPaymentInfo("NG", "Individual - Medical", 14, 5555.56),
                setInternationalPaymentInfo("JP", "Individual - Education", 15, 6666.67),
                setInternationalPaymentInfo("PE", "Financial Investment", 16, 7777.78),
                setInternationalPaymentInfo("AU", "Direct Investment", 17, 8888.89),
                setInternationalPaymentInfo("AQ", "Individual - Medical", 18, 10000.0),

                setInternationalPaymentInfo("SE", "Services", 19, 500.0));


    }

    private InternationalPaymentInfo setInternationalPaymentInfo(String recipientCountry, String transferPurpose, long numberOfTransactions, double totalTransferredAmount) {
        InternationalPaymentId paymentId = new InternationalPaymentId();
        paymentId.setRecipientCountry(recipientCountry);
        paymentId.setTransferPurpose(transferPurpose);
        InternationalPaymentInfo paymentInfo = new InternationalPaymentInfo();
        paymentInfo.setInternationalPaymentId(paymentId);
        paymentInfo.setNumberOfTransactions(numberOfTransactions);
        paymentInfo.setTotalTransferredAmount(BigDecimal.valueOf(totalTransferredAmount));
        return paymentInfo;
    }
}