package com.neobank.regulatory.reporting.util;

public class TestConstants {

    public static final String TERM_DEPOSIT_USD = "Term Deposit USD";

    public static final String TERM_DEPOSIT_AED_BORROW = "Term Deposit AED Borrow";

    public static final String MBILLS_INVESTMENT = "MBILLS Investment";

    public static final String NCD_INVESTMENT = "NCD Investment";

    public static final String TERM_DEPOSIT = "Term Deposit AED";

    public static final String CALL_DEPOSIT = "Call Account";

}
