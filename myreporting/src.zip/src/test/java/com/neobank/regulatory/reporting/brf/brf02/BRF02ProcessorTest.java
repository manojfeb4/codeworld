package com.neobank.regulatory.reporting.brf.brf02;

import com.neobank.regulatory.reporting.config.LiabilitiesCapitalAccountsConfig;
import com.neobank.regulatory.reporting.config.ProductsBookValueConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.entity.AccountsCountAndBalance;
import com.neobank.regulatory.reporting.entity.MainAccountProductId;
import com.neobank.regulatory.reporting.model.LiabilitiesCapitalQueryKey;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.AccountsCountAndBalanceRepository;
import com.neobank.regulatory.reporting.services.AccountsCountAndBalanceService;
import com.neobank.regulatory.reporting.services.LiabilitiesCapitalService;
import com.neobank.regulatory.reporting.util.ConfigUtil;
import com.neobank.regulatory.reporting.util.NumberUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class BRF02ProcessorTest {

    private static final double DEFAULT_VALUE = 29.99d;
    private static final double DEFAULT_CLOSING_BALANCE = 99.99d;
    static LiabilitiesCapitalAccountsConfig liabilitiesCapitalAccountsConfig;
    static ProductsBookValueConfig productsBookValueConfig;

    static {
        liabilitiesCapitalAccountsConfig = ConfigUtil.read("mapping/liabilities-capital-accounts.yml",
                "liabilities-capital", LiabilitiesCapitalAccountsConfig.class);
    }

    Workbook wb;
    TransformationContext payloadData;
    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @InjectMocks
    BRF02Processor brf02Processor;

    @Mock
    private AccountClosingBalanceRepository accountClosingBalanceRepository;

    @Mock
    private AccountsCountAndBalanceRepository accountsCountAndBalanceRepository;

    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-002.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        payloadData = new TransformationContext("002", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
        //
        BRF02Transformer brf01Transformer = Mockito.spy(new BRF02Transformer());
        //
        brf02Processor = new BRF02Processor(brf01Transformer, accountClosingBalanceRepository,
                new LiabilitiesCapitalService(), liabilitiesCapitalAccountsConfig, accountsCountAndBalanceRepository,
                new AccountsCountAndBalanceService());
    }

    @Test
    void mustPassValidRequest() {
        assertNotNull(brf02Processor);

        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any())).thenReturn(
                closingBalancingForAccounts(liabilitiesCapitalAccountsConfig.getMoneyBorrowingRemainingBalance()));

        brf02Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, "F48");
        assertEquals(199.98d, cell.getNumericCellValue(), "must be equal");
        assertNotNull(brf02Processor.getBrfTransformer());
        assertNull(brf02Processor.getReportingRepository());
    }

    @Test
    void mustPassAllClosingBalanceAccountsCalls() {
        commonTestForAccountsClosingBalance("F48",
                liabilitiesCapitalAccountsConfig.getMoneyBorrowingRemainingBalance());
        commonTestForAccountsClosingBalance("F49", liabilitiesCapitalAccountsConfig.getInterbankBorrowing());
        commonTestForAccountsClosingBalance("F50", liabilitiesCapitalAccountsConfig.getOtherTermBorrowings());
        commonTestForAccountsClosingBalance("F51", liabilitiesCapitalAccountsConfig.getBorrowingUnderRepurchase());
        commonTestForAccountsClosingBalance("F64", liabilitiesCapitalAccountsConfig.getStaffBenefits());
        commonTestForAccountsClosingBalance("F65", liabilitiesCapitalAccountsConfig.getOtherProvisions());
        commonTestForAccountsClosingBalance("F67", liabilitiesCapitalAccountsConfig.getInterestPayable());
        commonTestForAccountsClosingBalance("F68", liabilitiesCapitalAccountsConfig.getIncomeTaxLiability());
        commonTestForAccountsClosingBalance("F69", liabilitiesCapitalAccountsConfig.getAccountsPayable());
        commonTestForAccountsClosingBalance("F74", liabilitiesCapitalAccountsConfig.getAcceptances());
        commonTestForAccountsClosingBalance("F75", liabilitiesCapitalAccountsConfig.getAllOtherBorrowings());
        commonTestForAccountsClosingBalance("F86", liabilitiesCapitalAccountsConfig.getShareCapital());
        commonTestForAccountsClosingBalance("F87", liabilitiesCapitalAccountsConfig.getTreasuryShares());
        commonTestForAccountsClosingBalance("F89", liabilitiesCapitalAccountsConfig.getLegalReserves());
        commonTestForAccountsClosingBalance("F91", liabilitiesCapitalAccountsConfig.getOtherComprehensiveIncome());
        commonTestForAccountsClosingBalance("F92", liabilitiesCapitalAccountsConfig.getOtherReserves());
        commonTestForAccountsClosingBalance("F93", liabilitiesCapitalAccountsConfig.getRetainedEarnings());
        commonTestForAccountsClosingBalance("F94", liabilitiesCapitalAccountsConfig.getCurrentYearProfit());
        commonTestForAccountsClosingBalance("F95", liabilitiesCapitalAccountsConfig.getInstrumentsPerpetual());
    }

    @Test
    void mustPassAllBookValueForProductsCalls() {
        commonTestForCountAndBalance("E23", 10);
        commonTestForCountAndBalance("E24", 10);
        commonTestForCountAndBalance("F23", 299.9);
        commonTestForCountAndBalance("F24", 299.9);
    }

    private void commonTestForAccountsClosingBalance(String cellToCheck, LiabilitiesCapitalQueryKey queryKey) {
        var total = NumberUtils.roundOffValue(queryKey.getAccounts().size() * DEFAULT_CLOSING_BALANCE);
        Mockito.when(accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(Mockito.any()))
                .thenReturn(closingBalancingForAccounts(queryKey));
        brf02Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(total, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());
    }

    private void commonTestForCountAndBalance(String cellToCheck, double value) {
        Mockito.when(accountsCountAndBalanceRepository.getCountsAndTotalBalanceByAccountType(Mockito.any()))
                .thenReturn(countAndBalance(10));
        brf02Processor.process(wb, payloadData);
        var sheet = wb.getSheetAt(0);
        var cell = getCellByReference(sheet, cellToCheck);
        assertEquals(value, cell.getNumericCellValue(), cellToCheck + " must be equal");
        assertNotEquals(0.0d, cell.getNumericCellValue());

    }

    private List<AccountClosingBalance> closingBalancingForAccounts(LiabilitiesCapitalQueryKey queryKey) {
        return queryKey.getAccounts().stream()
                .map(c -> AccountClosingBalance.builder()
                        .id(MainAccountProductId.builder().mainAccount(c).product("").build())
                        .closingBalance(DEFAULT_CLOSING_BALANCE).build())
                .collect(Collectors.toList());
    }

    private List<AccountsCountAndBalance> countAndBalance(long count) {
        return List.of(
                AccountsCountAndBalance.builder().totalCounts(count).accountType(BRF02Processor.CURRENT_ACCOUNT)
                        .totalBalance(count * DEFAULT_VALUE).build(),
                AccountsCountAndBalance.builder().accountType(BRF02Processor.REGULAR_SAVINGS).totalCounts(count)
                        .totalBalance(count * DEFAULT_VALUE).build());
    }

    private Cell getCellByReference(Sheet sheet, String reference) {
        var cellReference = new CellReference(reference);
        return sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
    }
}
