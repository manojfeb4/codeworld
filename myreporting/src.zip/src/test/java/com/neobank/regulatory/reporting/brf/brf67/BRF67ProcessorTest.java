package com.neobank.regulatory.reporting.brf.brf67;


import com.neobank.regulatory.reporting.entity.OutstandingBalanceId;
import com.neobank.regulatory.reporting.entity.OutstandingBalanceInfo;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.OutstandingBalanceRepository;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.neobank.regulatory.reporting.util.Resources.verifyCellData;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BRF67ProcessorTest {


    BRF67Processor underTest;

    Workbook wb;
    TransformationContext payloadData;

    ResourceLoader resourceLoader = new DefaultResourceLoader();

    @Mock
    private OutstandingBalanceRepository outstandingBalanceRepository;

    private BRF67Transformer brf67Transformer;


    @BeforeEach
    public void setup() throws IOException {
        Resource resource = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResource("classpath:templates/BRF-013.xls");
        byte[] fileBytes = IOUtils.toByteArray(resource.getInputStream());
        brf67Transformer = spy(new BRF67Transformer());
        underTest = new BRF67Processor(brf67Transformer, outstandingBalanceRepository);
        payloadData = new TransformationContext("067", LocalDate.now(), LocalDate.now(), "", "");
        wb = WorkbookFactory.create(new ByteArrayInputStream(Arrays.copyOf(fileBytes, fileBytes.length)));
    }

    @Test
    void shouldReturnBrfId() {
        assertEquals("BRF-067", underTest.getBrfId());
    }

    @Test
    void shouldReturnBrfProcessor() {
        assertEquals(brf67Transformer, underTest.getBrfTransformer());
    }

    @Test
    void shouldReturnReportingRepository() {
        assertEquals(outstandingBalanceRepository, underTest.getReportingRepository());
    }

    @Test
    void shouldProcessReportWithoutDataInSource() {

        List<OutstandingBalanceInfo> outstandingBalanceInfoList = Collections.emptyList();

        when(outstandingBalanceRepository.getSizeWiseDepositsSameNation(any())).thenReturn(outstandingBalanceInfoList);

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);

        Sheet sheet = wb.getSheetAt(0);

        verifyCellData("C4", "ADQ Neobank", sheet);
        verifyCellData("F13", "0.0", sheet);
        verifyCellData("F14", "0.0", sheet);

    }

    @Test
    void shouldProcessReportWithDataInSource() {



        List<OutstandingBalanceInfo> outstandingBalanceInfoList = new ArrayList<>();
        var sameNationList = getOutstandingBalanceSameNationInfo();
        var otherNationList = getOutstandingBalanceOtherNationInfo();
        when(outstandingBalanceRepository.getSizeWiseDepositsSameNation(any()))
                .thenReturn(sameNationList);
        when(outstandingBalanceRepository.getSizeWiseDepositsOtherNation(any())).thenReturn(otherNationList);

        doCallRealMethod().when(brf67Transformer).transform(any(), any());

        underTest.process(wb, payloadData);
        underTest.setMonthlyDefaultCells(wb, payloadData);
        Sheet sheet = wb.getSheetAt(0);

        Row row = sheet.getRow(3);
        outstandingBalanceInfoList.addAll(sameNationList);
        outstandingBalanceInfoList.addAll(otherNationList);

        verify(brf67Transformer, times(1)).transform(sheet, outstandingBalanceInfoList);

        assertEquals("ADQ Neobank", row.getCell(2).toString());
        verifyCellData("D19", "0.0", sheet);
        verifyCellData("D20", "865.2", sheet);
        verifyCellData("D24", "40260.03", sheet);

        verifyCellData("E19", "0.0", sheet);
        verifyCellData("E20", "0.0", sheet);
        verifyCellData("E24", "0.0", sheet);

        verifyCellData("F21", "6.0", sheet);
        verifyCellData("F22", "7.0", sheet);
        verifyCellData("F23", "8.0", sheet);

        verifyCellData("G21", "10010.0", sheet);
        verifyCellData("G22", "50260.03", sheet);
        verifyCellData("G23", "1234865.2", sheet);

    }

    private List<OutstandingBalanceInfo> getOutstandingBalanceSameNationInfo() {
        return List.of(
                setOutstandingBalanceInfo("UAE", 0, 1, 0.0),
                setOutstandingBalanceInfo("UAE", 5, 3, 40260.03),
                setOutstandingBalanceInfo("UAE", 1, 3, 865.2));


    }
    private List<OutstandingBalanceInfo> getOutstandingBalanceOtherNationInfo() {
        return List.of(

                setOutstandingBalanceInfo("OTHER", 2, 6, 10010.0),
                setOutstandingBalanceInfo("OTHER", 3, 7, 50260.03),
                setOutstandingBalanceInfo("OTHER", 4, 8, 1234865.2));

    }

    private OutstandingBalanceInfo setOutstandingBalanceInfo(String nationalityType, int sizeCategory, int numberOfAccounts, double sumOfAccountBalance) {
        OutstandingBalanceId outstandingBalanceId = new OutstandingBalanceId();
        outstandingBalanceId.setNationalityType(nationalityType);
        outstandingBalanceId.setSizeCategory(sizeCategory);
        OutstandingBalanceInfo outstandingBalanceInfo = new OutstandingBalanceInfo();
        outstandingBalanceInfo.setOutstandingBalanceId(outstandingBalanceId);
        outstandingBalanceInfo.setNumberOfAccounts(numberOfAccounts);
        outstandingBalanceInfo.setTotalAccountBalance(sumOfAccountBalance);
        return outstandingBalanceInfo;
    }

}