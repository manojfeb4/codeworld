package com.neobank.regulatory.reporting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InternationalPaymentReportingData {


    private String countryCode;
    private String paymentType;

    private String clientSegment;
    private double numberOfTransactions;
    private double totalTransferredAmount;


}
