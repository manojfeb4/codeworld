package com.neobank.regulatory.reporting.brf.brf06;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.config.ClientSegmentConfig;
import com.neobank.regulatory.reporting.entity.AverageAccountBalanceInfo;
import com.neobank.regulatory.reporting.entity.ClientSegmentInfo;
import com.neobank.regulatory.reporting.model.AverageAccountBalanceReportingData;
import com.neobank.regulatory.reporting.model.ClientSegmentQueryKey;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountBalanceRepository;
import com.neobank.regulatory.reporting.repository.ClientSegmentRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.services.AverageAccountBalanceService;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.Period;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.neobank.ods.schema.enums.BusinessStatus.ACTIVE;
import static com.neobank.regulatory.reporting.model.AccountType.CURRENT_ACCOUNT;
import static com.neobank.regulatory.reporting.model.AccountType.REGULAR_SAVINGS;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_06;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component
public class BRF06Processor extends AbstractBRFProcessor {

    private final BRF06Transformer brf06Transformer;

    private final AccountBalanceRepository accountBalanceRepository;

    private final ClientSegmentRepository clientSegmentRepository;

    private final ClientSegmentConfig clientSegmentConfig;

    private final AverageAccountBalanceService averageAccountBalanceService;

    public BRF06Processor(BRF06Transformer brf06Transformer,
                          ClientSegmentConfig clientSegmentConfig,
                          AccountBalanceRepository accountBalanceRepository,
                          ClientSegmentRepository clientSegmentRepository,
                          AverageAccountBalanceService averageAccountBalanceService) {
        this.brf06Transformer = brf06Transformer;
        this.accountBalanceRepository = accountBalanceRepository;
        this.clientSegmentRepository = clientSegmentRepository;
        this.clientSegmentConfig = clientSegmentConfig;
        this.averageAccountBalanceService = averageAccountBalanceService;

    }

    @Override
    public String getBrfId() {
        return BRF + BRF_06;
    }

    @Override
    public BRFTransformer<AverageAccountBalanceReportingData> getBrfTransformer() {
        return brf06Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return null;
    }


    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingToDate = payloadData.getReportingToDate();
        var reportingFromDate = payloadData.getReportingFromDate();
        var reportingData = List.of(reportingData(reportingFromDate, reportingToDate));

        brf06Transformer.transform(wb.getSheetAt(0), reportingData);
        log.info("{} generated successfully.", getBrfId());
    }


    private List<AverageAccountBalanceInfo> getAverageAccountBalanceInfo(
            String reportingFromDate, String reportingToDate) {
        /* Approved State is not found in ods enum list */
        var accountStateList = List.of("approved", ACTIVE.getValue().toLowerCase());
        var accountTypeList = List.of(CURRENT_ACCOUNT.getType(), REGULAR_SAVINGS.getType());


        return accountBalanceRepository.getAverageAccountBalance(
                reportingFromDate, reportingToDate,
                accountStateList, accountTypeList);
    }

    private double totalAverageBalance(
            List<AverageAccountBalanceInfo> averageAccountBalanceInfo,
            ClientSegmentQueryKey queryKey,
            String accountType
    ) {
        var clientSegmentBusiness = getClientSegmentBusiness(queryKey);
        log.debug("Account Type : {} ", accountType);
        log.debug("Average Account Balance: {} ", Arrays.deepToString(averageAccountBalanceInfo.toArray()));

        return averageAccountBalanceService
                .averageAccountBalanceOfClientSegments(averageAccountBalanceInfo,
                        clientSegmentBusiness, accountType);

    }

    private List<String> getClientSegmentBusiness(ClientSegmentQueryKey queryKey) {

        var clientSegmentInfo = clientSegmentRepository
                .getBusinessesOfClientSegments(queryKey.getClientSegments());
        log.debug("Client Segment Info: {} ", Arrays.deepToString(clientSegmentInfo.toArray()));

        var clientSegmentBusiness =
                clientSegmentInfo.stream()
                        .filter(k -> StringUtils.isNotEmpty(k.getClientSegment1()))
                        .map(ClientSegmentInfo::getBusinessId)
                        .collect(Collectors.toList());
        log.debug("Client Segment Business: {} ", Arrays.deepToString(clientSegmentBusiness.toArray()));
        return clientSegmentBusiness;
    }

    protected AverageAccountBalanceReportingData reportingData
            (LocalDate reportingFromDate, LocalDate reportingToDate) {
        var averageAccountBalanceInfo =
                getAverageAccountBalanceInfo(reportingFromDate.format(ISO_DATE), reportingToDate.format(ISO_DATE));
        var numOfDays = Math.abs(Period.between(reportingFromDate, reportingToDate).getDays()) + 1;
        log.debug("number of days : {} ", numOfDays);
        var govtKeys = clientSegmentConfig.getAverageGovtKeys();
        var otherKeys = clientSegmentConfig.getAverageOtherKeys();
        var currentAccount = CURRENT_ACCOUNT.getType();
        var regularSavings = REGULAR_SAVINGS.getType();
        var govtDemand = NumberUtils.roundOffValue(totalAverageBalance(averageAccountBalanceInfo, govtKeys, currentAccount)/numOfDays) ;
        var govtSavings = NumberUtils.roundOffValue(totalAverageBalance(averageAccountBalanceInfo, govtKeys, regularSavings)/numOfDays) ;
        var otherDemand = NumberUtils.roundOffValue(totalAverageBalance(averageAccountBalanceInfo, otherKeys, currentAccount)/numOfDays) ;
        var otherSavings = NumberUtils.roundOffValue(totalAverageBalance(averageAccountBalanceInfo, otherKeys, regularSavings)/numOfDays) ;


        return AverageAccountBalanceReportingData.builder()
                .totalAverageGovtDemand(govtDemand)
                .totalAverageGovtSavings(govtSavings)
                .totalAverageOtherDemand(otherDemand)
                .totalAverageOtherSavings(otherSavings)
                .build();
    }


}
