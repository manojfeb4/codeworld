package com.neobank.regulatory.reporting.brf;

import com.neobank.regulatory.reporting.model.event.TransformationContext;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellReference;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public abstract class AbstractBRFProcessor implements BRFProcessor {

    public void setMonthlyDefaultCells(Workbook wb, TransformationContext payloadData) {
        LocalDate reportingDate = payloadData.getReportingToDate();


        getCell(wb.getSheetAt(0), "C4").setCellValue("ADQ Neobank");
        getCell(wb.getSheetAt(0), "C5").setCellValue(DateTimeFormatter.ofPattern("yyyy/MM/dd").format(reportingDate));


    }

    public void setQuarterlyDefaultCells(Workbook wb, TransformationContext payloadData) {
        LocalDate reportingDate = payloadData.getReportingToDate();


        getCell(wb.getSheetAt(0), "B4").setCellValue("ADQ Neobank");
        getCell(wb.getSheetAt(0), "B5").setCellValue(DateTimeFormatter.ofPattern("yyyy/MM/dd").format(reportingDate));


    }


    protected Cell getCell(Sheet sheet, int rownum, int cellnum) {
        Row row = sheet.getRow(rownum);
        return row.getCell(cellnum);
    }

    protected Cell getCell(Sheet sheet, String reference) {
        var cellReference = new CellReference(reference);
        return sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
    }

}
