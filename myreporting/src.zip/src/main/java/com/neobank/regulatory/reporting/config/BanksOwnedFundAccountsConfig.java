package com.neobank.regulatory.reporting.config;

import com.neobank.common.config.YamlPropertySourceFactory;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Data
@Configuration
@ConfigurationProperties(prefix = "banks-owned-fund-accounts")
@PropertySource(value = "classpath:mapping/banks-owned-fund-accounts.yml", factory = YamlPropertySourceFactory.class)
public class BanksOwnedFundAccountsConfig {

    private ClosingBalanceQueryKey banksOwnedFundBalanceKeys;


}
