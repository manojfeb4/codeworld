package com.neobank.regulatory.reporting.model;

import lombok.Data;

import java.util.List;

@Data
public class ClientSegmentQueryKey {

    private List<String> clientSegments;


}
