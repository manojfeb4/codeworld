package com.neobank.regulatory.reporting.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;


@Data
@NoArgsConstructor
@Embeddable
public class ResidualMaturityId implements Serializable {

    @Column(name = "PRODUCT")
    private String product;

    @Column(name = "BUCKET")
    private int bucket;

}
