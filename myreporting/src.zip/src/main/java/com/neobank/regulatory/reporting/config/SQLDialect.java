package com.neobank.regulatory.reporting.config;

import org.hibernate.dialect.Dialect;

public class SQLDialect extends Dialect {

}
