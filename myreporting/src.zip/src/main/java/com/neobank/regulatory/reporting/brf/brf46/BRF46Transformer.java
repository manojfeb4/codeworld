package com.neobank.regulatory.reporting.brf.brf46;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.BookValuePerProduct;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BRF46Transformer implements BRFTransformer<BookValuePerProduct> {

    @Override
    public void transform(Sheet sheet, List<BookValuePerProduct> dataset) {
        throw new UnsupportedOperationException();
    }

}
