package com.neobank.regulatory.reporting.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class BusinessAccountBalance {

    @Id
    @Column(name = "BUSINESSNAME")
    private String businessName;

    @Column(name = "COUNTRYOFINCORPORATION")
    private String countryOfIncorporation;

    @Column(name = "ACCOUNTBALANCE")
    private double accountBalance;

}
