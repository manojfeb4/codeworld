package com.neobank.regulatory.reporting.brf.brf11;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.model.AssetsLiabilitesMaturityClassificationReportingData;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class BRF11Transformer implements BRFTransformer<AssetsLiabilitesMaturityClassificationReportingData> {

    private void transform(Sheet sheet, AssetsLiabilitesMaturityClassificationReportingData data) {
        getCell(sheet, "P9").setCellValue(data.getCashReserveBalance());
        mapBuckets(sheet, data.getFederalGovernmentDebtSecurities(), 11);
        mapBuckets(sheet, data.getPlacementHeldResidentBank(), 13);
        mapBuckets(sheet, data.getInterbankCDsHeld(), 14);
        mapBuckets(sheet, data.getPlacementHeldOverseaBank(), 15);
        getCell(sheet, "P33").setCellValue(data.getNetFixedAssets());
        getCell(sheet, "P44").setCellValue(data.getOtherAssets());
        getCell(sheet, "E54").setCellValue(data.getGovPubDeposit());
        getCell(sheet, "E55").setCellValue(data.getGreDeposit());
        getCell(sheet, "E56").setCellValue(data.getPrivSecDeposit());
        getCell(sheet, "E57").setCellValue(data.getNbfiDeposit());
        getCell(sheet, "E58").setCellValue(data.getHniMoreThan20AED());
        getCell(sheet, "E59").setCellValue(data.getHniUpto20AED1() + data.getHniUpto20AED2());
        getCell(sheet, "P64").setCellValue(data.getCapitalAndReserves());
    }

    private void mapBuckets(Sheet sheet, Map<String, Double> values, int row) {
        values.keySet().forEach(k -> getCell(sheet, k + row).setCellValue(NumberUtils.roundOffValue(values.get(k))));
    }

    @Override
    public void transform(Sheet sheet,
                          List<AssetsLiabilitesMaturityClassificationReportingData> residualMaturityInfoList) {
        transform(sheet, residualMaturityInfoList.get(0));
    }

}
