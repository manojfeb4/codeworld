package com.neobank.regulatory.reporting.config;

import com.neobank.common.config.YamlPropertySourceFactory;
import com.neobank.regulatory.reporting.model.AssetsLiabilitesMaturityClassificationQueryKey;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Data
@Configuration
@ConfigurationProperties(prefix = "assets-liabilites-maturity-classification")
@PropertySource(value = "classpath:mapping/banking-monetary-statistics.yml", factory = YamlPropertySourceFactory.class)

public class AssetsLiabilitesMaturityClassificationConfig {

    private AssetsLiabilitesMaturityClassificationQueryKey cashReserveBalance;

    private AssetsLiabilitesMaturityClassificationQueryKey federalGovernmentDebtSecurities;

    private AssetsLiabilitesMaturityClassificationQueryKey placementHeldResidentBank;

    private AssetsLiabilitesMaturityClassificationQueryKey interbankCDsHeld;

    private AssetsLiabilitesMaturityClassificationQueryKey placementHeldOverseaBank;

    private AssetsLiabilitesMaturityClassificationQueryKey netFixedAssets;

    private AssetsLiabilitesMaturityClassificationQueryKey otherAssets;

    private AssetsLiabilitesMaturityClassificationQueryKey govPubDeposit;

    private AssetsLiabilitesMaturityClassificationQueryKey greDeposit;

    private AssetsLiabilitesMaturityClassificationQueryKey privSecDeposit;

    private AssetsLiabilitesMaturityClassificationQueryKey nbfiDeposit;

    private AssetsLiabilitesMaturityClassificationQueryKey hniMoreThan20AED;

    private AssetsLiabilitesMaturityClassificationQueryKey hniUpto20AED1;

    private AssetsLiabilitesMaturityClassificationQueryKey hniUpto20AED2;

    private AssetsLiabilitesMaturityClassificationQueryKey capitalAndReserves;
}
