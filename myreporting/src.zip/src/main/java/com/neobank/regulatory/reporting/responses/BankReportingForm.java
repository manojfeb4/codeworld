package com.neobank.regulatory.reporting.responses;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@Builder
public class BankReportingForm implements Serializable {

    @JsonProperty("brfId")
    private String brfId;

}
