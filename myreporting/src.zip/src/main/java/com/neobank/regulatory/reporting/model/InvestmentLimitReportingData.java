package com.neobank.regulatory.reporting.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class InvestmentLimitReportingData {

    private long numOfDebtSecurities;
    private double totalBookValueOfDebtSecurities;

    private long numOfBankOwnedFunds;
    private double totalBalanceOfBankOwnedFunds;


}
