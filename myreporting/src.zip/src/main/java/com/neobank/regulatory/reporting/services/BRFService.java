package com.neobank.regulatory.reporting.services;

import com.neobank.regulatory.reporting.brf.BRFProcessor;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.*;

@Slf4j
@Component
public class BRFService {

    private final ResourceLoader resourceLoader;

    private final BRFUploader brfUploader;

    private final List<BRFProcessor> brfProcessors;

    private final Map<String, byte[]> map = new HashMap<>();

    private final Map<String, BRFProcessor> mapOfBrfProcessor;

    public BRFService(ResourceLoader resourceLoader, BRFUploader brfUploader, List<BRFProcessor> brfProcessors) {
        this.resourceLoader = resourceLoader;
        this.brfUploader = brfUploader;
        this.brfProcessors = brfProcessors;
        this.mapOfBrfProcessor = new HashMap<>();
    }

    @PostConstruct
    public void init() throws IOException {
        log.info("Loading BRF templates");
        Resource[] resources = ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
                .getResources("classpath:templates/*.xls*");

        for (Resource resource : resources) {
            map.put(resource.getFilename(), IOUtils.toByteArray(resource.getInputStream()));
            String fileNameWithoutExtension = FilenameUtils.removeExtension(resource.getFilename());
            var brfProcessorOpt = brfProcessors.stream()
                    .filter(brfProcessor -> brfProcessor.getBrfId().equalsIgnoreCase(fileNameWithoutExtension))
                    .findFirst();
            brfProcessorOpt.ifPresent(brfProcessor -> mapOfBrfProcessor.put(fileNameWithoutExtension, brfProcessor));
        }
        log.info("Files loaded:{}", map.size());

    }


    public File processAndUpload(TransformationContext payloadData) throws IOException {
        String fileName = "BRF-" + payloadData.getBrfName();
        byte[] fileBytes = getCopyOfFileInBytes(fileName);
        var wb = WorkbookFactory.create(new ByteArrayInputStream(fileBytes));
        var brfProcessor = getMapOfBrfProcessor().get(fileName.toUpperCase(Locale.ROOT));

        brfProcessor.process(wb, payloadData);
        brfProcessor.setMonthlyDefaultCells(wb, payloadData);

        FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
        evaluator.setIgnoreMissingWorkbooks(true);
        evaluator.evaluateAll();


        return brfUploader.uploadWorkbook(wb, fileName, payloadData);


    }

    private byte[] getCopyOfFileInBytes(String fileName) {

        String fileNameWithExtension = fileName + ".xls";
        byte[] fileSource = map.get(fileNameWithExtension);
        if (fileSource == null) {
            fileSource = map.get(fileNameWithExtension + "x");
        }
        return Arrays.copyOf(fileSource, fileSource.length);

    }

    public Map<String, BRFProcessor> getMapOfBrfProcessor() {
        return mapOfBrfProcessor;
    }

}
