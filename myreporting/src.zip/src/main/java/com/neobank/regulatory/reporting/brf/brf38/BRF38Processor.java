package com.neobank.regulatory.reporting.brf.brf38;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.RemittanceInfo;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.RemittanceRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;


import java.time.temporal.TemporalAdjusters;
import java.util.Arrays;
import java.util.List;

import static com.neobank.regulatory.reporting.model.RemittanceType.*;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_38;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component
@AllArgsConstructor
public class BRF38Processor extends AbstractBRFProcessor {


    private final BRF38Transformer brf38Transformer;
    private final RemittanceRepository remittanceRepository;

    @Override
    public String getBrfId() {
        return BRF + BRF_38;
    }

    @Override
    public BRFTransformer<RemittanceInfo> getBrfTransformer() {
        return brf38Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return remittanceRepository;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingToDate = payloadData.getReportingToDate();
        var reportingFromDate = reportingToDate.with(TemporalAdjusters.firstDayOfMonth());
        var remittanceTypeFamilyList = List.of(FAMILY_MAINTENANCE.getType(),
                GIFT_TO_FRIENDS.getType(),
                OTHER_PERSONAL_EXPENSE.getType(),
                FAMILY_EDUCATION.getType(),
                FAMILY_MEDICAL.getType());
        var remittanceTypeOtherList = List.of(EMPLOYEE_COMPENSATION.getType(),
                SAVINGS.getType(), NRE_DEPOSIT.getType());
        var remittanceTypeInvestmentList = List.of(PROPERTY_PURCHASE.getType(), INTEREST_ON_LOAN.getType());
        var remittanceInfoList = remittanceRepository
                .getCountryWiseRemittance(reportingFromDate.format(ISO_DATE),reportingToDate.format(ISO_DATE), remittanceTypeFamilyList,
                        remittanceTypeInvestmentList, remittanceTypeOtherList);

        log.info("Fetched Total {} Records", remittanceInfoList.size());
        log.info("Reporting From Date : {}", reportingFromDate.format(ISO_DATE));
        log.info("Reporting To Date : {}", reportingToDate.format(ISO_DATE));
        log.debug(Arrays.deepToString(remittanceInfoList.toArray()));
        brf38Transformer.transform(wb.getSheetAt(0), remittanceInfoList);


        log.info("{} generated successfully.", getBrfId());
    }


}
