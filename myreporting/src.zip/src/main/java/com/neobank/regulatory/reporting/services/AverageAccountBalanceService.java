package com.neobank.regulatory.reporting.services;

import com.neobank.regulatory.reporting.entity.AverageAccountBalanceInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.util.List;

@Service
public class AverageAccountBalanceService {

    public double averageAccountBalanceOfClientSegments(List<AverageAccountBalanceInfo> averageBalances,
                                                        List<String> clientSegmentBusiness,
                                                        String accountType) {


        double averageBalance;
        final DecimalFormat df = new DecimalFormat("0.00");
        if (ObjectUtils.isNotEmpty(clientSegmentBusiness) && !CollectionUtils.isEmpty(averageBalances)
                && !CollectionUtils.isEmpty(clientSegmentBusiness)) {
            averageBalance = averageBalances.stream()
                    .filter(k -> filterBusiness(k, clientSegmentBusiness, accountType))
                    .mapToDouble(AverageAccountBalanceInfo::getTotalBalance)
                    .sum();
            return Double.parseDouble(df.format(averageBalance));


        }
        return 0.0d;
    }

    private boolean filterBusiness(AverageAccountBalanceInfo averageAccountBalanceInfo,
                                   List<String> clientSegmentBusiness,
                                   String accountType) {

        return (clientSegmentBusiness.contains(averageAccountBalanceInfo.getAverageAccountBalanceId().getBusinessId())
                && accountType.equals(averageAccountBalanceInfo.getAverageAccountBalanceId().getAccountType()));

    }
}







