package com.neobank.regulatory.reporting.brf.brf04;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.model.IncomeExpenseReportingData;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class BRF04Transformer implements BRFTransformer<IncomeExpenseReportingData> {

    private void transform(Sheet sheet, IncomeExpenseReportingData data) {
        getCell(sheet, "E12").setCellValue(data.getPersonalConsumerLoans());
        getCell(sheet, "E13").setCellValue(data.getCarLoans());
        getCell(sheet, "E14").setCellValue(data.getOverdraft());
        getCell(sheet, "E15").setCellValue(data.getCreditCardLoans());
        getCell(sheet, "E17").setCellValue(data.getRealEstateHousingLoans());
        getCell(sheet, "E20").setCellValue(data.getSmallBusinessLoans());
        getCell(sheet, "E22").setCellValue(data.getCentralBankCds());
        getCell(sheet, "E23").setCellValue(data.getInterbankInterestIncomeFrom());
        getCell(sheet, "E25").setCellValue(data.getInvestmentIncome());
        getCell(sheet, "E26").setCellValue(data.getInterestOrProfitIncome());
        getCell(sheet, "E29").setCellValue(data.getPrivateSectorCorporate());
        getCell(sheet, "E32").setCellValue(data.getMarginalLendingAndOverdraft());
        getCell(sheet, "E33").setCellValue(data.getInterbankInterestExpensesPaidTo());
        getCell(sheet, "E35").setCellValue(data.getCapitalMarketOtherBorrowings());
        getCell(sheet, "E40").setCellValue(data.getForeignExchangeContracts());
        getCell(sheet, "E41").setCellValue(data.getDerivativesAndFinancialFutures());
        getCell(sheet, "E44").setCellValue(data.getOtherDerivatives());
        getCell(sheet, "E49").setCellValue(data.getOtherFeesIncome());
        getCell(sheet, "E52").setCellValue(data.getStaffExpenses());
        getCell(sheet, "E53").setCellValue(data.getBonusExpenses());
        getCell(sheet, "E54").setCellValue(data.getPremisesExpenses());
        getCell(sheet, "E55").setCellValue(data.getItExpenses());
        getCell(sheet, "E56").setCellValue(data.getDepreciationAndAmortisation());
        getCell(sheet, "E60").setCellValue(data.getOtherOutsourcingExpenses());

    }

    @Override
    public void transform(Sheet sheet, List<IncomeExpenseReportingData> dataset) {
        transform(sheet, dataset.get(0));
    }

}
