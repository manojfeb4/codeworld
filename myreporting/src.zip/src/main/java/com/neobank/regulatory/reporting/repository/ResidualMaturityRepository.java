package com.neobank.regulatory.reporting.repository;

import com.neobank.regulatory.reporting.entity.ResidualMaturityId;
import com.neobank.regulatory.reporting.entity.ResidualMaturityInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ResidualMaturityRepository extends CrudRepository<ResidualMaturityInfo, ResidualMaturityId>, ReportingRepository {

    @Query(nativeQuery = true)
    List<ResidualMaturityInfo> getTotalBookValueByResidualMaturity(String reportingDate,
                                                                   String ncdInvestment, String callDeposit, String termDeposit, String countryOfBranch);

}
