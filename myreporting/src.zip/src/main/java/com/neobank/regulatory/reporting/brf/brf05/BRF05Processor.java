package com.neobank.regulatory.reporting.brf.brf05;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.TreasuryInvestment;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.InvestmentRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;

import static com.neobank.regulatory.reporting.model.InvestmentProduct.MBILL;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_05;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component
public class BRF05Processor extends AbstractBRFProcessor {

    private final BRF05Transformer brf05Transformer;

    private final InvestmentRepository investmentRepository;

    public BRF05Processor(BRF05Transformer brf05Transformer, InvestmentRepository investmentRepository) {
        this.brf05Transformer = brf05Transformer;
        this.investmentRepository = investmentRepository;
    }

    @Override
    public String getBrfId() {
        return BRF + BRF_05;
    }

    @Override
    public BRFTransformer<TreasuryInvestment> getBrfTransformer() {
        return brf05Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return investmentRepository;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();
        var treasuryInvestments = investmentRepository
                .findTreasuryInvestmentByDateEqualsAndProductEquals(reportingDate.format(ISO_DATE), MBILL.getCode());

        log.info("Fetched Total {} Treasury Investments", treasuryInvestments.size());

        updateSheet(wb.getSheetAt(0), treasuryInvestments);

        log.info("{} generated successfully.", getBrfId());
    }

    private void updateSheet(Sheet sheet, List<TreasuryInvestment> investments) {

        if (CollectionUtils.isEmpty(investments)) {
            return;
        }

        brf05Transformer.transform(sheet, investments);
    }

}
