package com.neobank.regulatory.reporting.brf.brf02;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.model.LiabilitiesCapitalReportingData;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class BRF02Transformer implements BRFTransformer<LiabilitiesCapitalReportingData> {

    private void transform(Sheet sheet, LiabilitiesCapitalReportingData data) {
        getCell(sheet, "E23").setCellValue(data.getCountOfDemands());
        getCell(sheet, "F23").setCellValue(data.getDemands());
        getCell(sheet, "E24").setCellValue(data.getCountOfSavings());
        getCell(sheet, "F24").setCellValue(data.getSavings());
        getCell(sheet, "F48").setCellValue(data.getMoneyBorrowingRemainingBalance());
        getCell(sheet, "F49").setCellValue(data.getInterbankBorrowing());
        getCell(sheet, "F50").setCellValue(data.getOtherTermBorrowings());
        getCell(sheet, "F51").setCellValue(data.getBorrowingUnderRepurchase());
        getCell(sheet, "F64").setCellValue(data.getStaffBenefits());
        getCell(sheet, "F65").setCellValue(data.getOtherProvisions());
        getCell(sheet, "F67").setCellValue(data.getInterestPayable());
        getCell(sheet, "F68").setCellValue(data.getIncomeTaxLiability());
        getCell(sheet, "F69").setCellValue(data.getAccountsPayable());
        getCell(sheet, "F74").setCellValue(data.getAcceptances());
        getCell(sheet, "F75").setCellValue(data.getAllOtherBorrowings());
        getCell(sheet, "F86").setCellValue(data.getShareCapital());
        getCell(sheet, "F87").setCellValue(data.getTreasuryShares());
        getCell(sheet, "F89").setCellValue(data.getLegalReserves());
        getCell(sheet, "F91").setCellValue(data.getOtherComprehensiveIncome());
        getCell(sheet, "F92").setCellValue(data.getOtherReserves());
        getCell(sheet, "F93").setCellValue(data.getRetainedEarnings());
        getCell(sheet, "F94").setCellValue(data.getCurrentYearProfit());
        getCell(sheet, "F95").setCellValue(data.getInstrumentsPerpetual());

    }

    @Override
    public void transform(Sheet sheet, List<LiabilitiesCapitalReportingData> dataset) {
        transform(sheet, dataset.get(0));
    }

}
