package com.neobank.regulatory.reporting.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@NoArgsConstructor


public class EmirateDepositId implements Serializable {

    @Column(name = "REGISTERED_ADDRESS_EMIRATE")
    private String registeredAddressEmirate;

    @Column(name = "ACCOUNT_TYPE")
    private String accountType;

}
