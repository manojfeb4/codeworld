package com.neobank.regulatory.reporting.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import java.io.Serializable;

@Data
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductIssueRatingBookValue {

    @EmbeddedId
    private ProductIssueRatingBookValueId id;

    @Column(name = "SUM_BOOK_VALUE")
    private double bookValue;

    @NoArgsConstructor
    @AllArgsConstructor
    @Data
    @Embeddable
    @Builder
    public static class ProductIssueRatingBookValueId implements Serializable {
        private static final long serialVersionUID = 1L;

        @Column(name = "PRODUCT_NAME")
        private String product;

        @Column(name = "ISSUE_RATING")
        private String issueRating;
    }
}
