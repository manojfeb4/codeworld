package com.neobank.regulatory.reporting.brf.brf35;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.InvestmentRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.neobank.regulatory.reporting.model.InvestmentProduct.*;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_35;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component
@RequiredArgsConstructor
public class BRF35Processor extends AbstractBRFProcessor {

    private static final String UNITED_ARAB_EMIRATES = "United Arab Emirates";

    private final BRF35Transformer brf35Transformer;

    private final InvestmentRepository investmentRepository;

    @Override
    public String getBrfId() {
        return BRF + BRF_35;
    }

    @Override
    public BRFTransformer<String[]> getBrfTransformer() {
        return brf35Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return investmentRepository;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.info("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();
        var totalBookValuesForBanksAndProducts = investmentRepository
                .getTotalBookValueGroupByBranchAndHeadOfficeCountryAndBankAndProductNotForCountry(UNITED_ARAB_EMIRATES,
                        reportingDate.format(ISO_DATE), NCD.getCode(), TERM_DEPOSIT.getCode(),
                        CALL_DEPOSIT.getCode());

        log.debug("Fetched Total {} Banks' Products Records", totalBookValuesForBanksAndProducts.size());

        var sheet = wb.getSheetAt(0);


        getBrfTransformer().transform(sheet, totalBookValuesForBanksAndProducts);

        log.info("{} generated successfully.", getBrfId());
    }

}
