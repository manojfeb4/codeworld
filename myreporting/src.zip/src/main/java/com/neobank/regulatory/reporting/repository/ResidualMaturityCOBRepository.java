package com.neobank.regulatory.reporting.repository;

import com.neobank.regulatory.reporting.entity.ResidualMaturityCOBId;
import com.neobank.regulatory.reporting.entity.ResidualMaturityCOBInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ResidualMaturityCOBRepository
        extends CrudRepository<ResidualMaturityCOBInfo, ResidualMaturityCOBId>, ReportingRepository {

    @Query(nativeQuery = true)
    List<ResidualMaturityCOBInfo> getTotalBookValueResidualMaturityByResidency(String reportingDate,
                                                                               String ncdInvestment, String callDeposit, String termDeposit, String mbill);

    @Query(nativeQuery = true)
    List<ResidualMaturityCOBInfo> getTotalBookValueResidualMaturityByResidencyAndReference(String reportingDate,
                                                                                           String ncdInvestment, String callDeposit, String termDeposit, String mbill);

}
