package com.neobank.regulatory.reporting.model;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum AccountType {
    CURRENT_ACCOUNT("CURRENT_ACCOUNT"),
    REGULAR_SAVINGS("REGULAR_SAVINGS");

    private final String type;

}