package com.neobank.regulatory.reporting.repository;

import com.neobank.regulatory.reporting.entity.AccountSegmentClosingBalance;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface AccountSegmentClosingBalanceRepository extends CrudRepository<AccountSegmentClosingBalance, String>, ReportingRepository {

    @Query(nativeQuery = true)
    public List<AccountSegmentClosingBalance> getTotalBalanceWithSegment(LocalDate reportingDate);
}
