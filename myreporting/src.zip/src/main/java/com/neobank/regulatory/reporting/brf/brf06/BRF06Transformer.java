package com.neobank.regulatory.reporting.brf.brf06;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.model.AverageAccountBalanceReportingData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class BRF06Transformer implements BRFTransformer<AverageAccountBalanceReportingData> {

    public void transform(Sheet sheet, AverageAccountBalanceReportingData data) {
        log.debug("Reporting Data: {} ", data.toString());

        getCell(sheet, "D9").setCellValue(data.getTotalAverageGovtDemand());
        getCell(sheet, "D11").setCellValue(data.getTotalAverageGovtSavings());
        getCell(sheet, "D21").setCellValue(data.getTotalAverageOtherDemand());
        getCell(sheet, "D23").setCellValue(data.getTotalAverageOtherSavings());


    }

    @Override
    public void transform(Sheet sheet, List<AverageAccountBalanceReportingData> dataset) {
        transform(sheet, dataset.get(0));
    }

}
