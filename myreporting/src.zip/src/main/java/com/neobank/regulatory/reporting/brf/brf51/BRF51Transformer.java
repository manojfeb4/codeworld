package com.neobank.regulatory.reporting.brf.brf51;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.model.AccountsReportingData;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class BRF51Transformer implements BRFTransformer<AccountsReportingData> {

    private void transform(Sheet sheet, AccountsReportingData data) {
        getCell(sheet, "D11").setCellValue(data.getCashInHand());
        getCell(sheet, "D12").setCellValue(data.getReserveHeldCB());
        getCell(sheet, "D14").setCellValue(data.getOtherBalances());
        getCell(sheet, "D16").setCellValue(data.getRepoedToUAECB());
        getCell(sheet, "D20").setCellValue(data.getOverseasBRNB());
        getCell(sheet, "D23").setCellValue(data.getCallAccountBookValue());
        getCell(sheet, "D24").setCellValue(data.getInterbankPlacements());
        getCell(sheet, "D25").setCellValue(data.getOtherTermPlacements());
        getCell(sheet, "D28").setCellValue(data.getLendingCoveredRepurchaseAgreements());
        getCell(sheet, "D35").setCellValue(data.getDebtSecurities1());
        getCell(sheet, "D36").setCellValue(data.getEquities1());
        getCell(sheet, "D40").setCellValue(data.getDebtSecurities2());
        getCell(sheet, "D41").setCellValue(data.getEquities2());
        getCell(sheet, "D42").setCellValue(data.getAssetsHeldMBills());
        getCell(sheet, "D44").setCellValue(data.getInvestmentSubsidiaries());
        getCell(sheet, "D45").setCellValue(data.getInvestmentAffiliates());
        getCell(sheet, "D67").setCellValue(data.getNetFixedAsset1());
        getCell(sheet, "D69").setCellValue(data.getNetFixedAsset2());
        getCell(sheet, "D71").setCellValue(data.getCapitalWorkInProgress());
        getCell(sheet, "D74").setCellValue(data.getInterestReceivable1());
        getCell(sheet, "D75").setCellValue(data.getPrepaidExpenses());
        getCell(sheet, "D77").setCellValue(data.getInterestReceivable2());
        getCell(sheet, "D80").setCellValue(data.getDividendReceivable());
        getCell(sheet, "D83").setCellValue(data.getMarketValueForwardContacts());
        getCell(sheet, "D86").setCellValue(data.getMarketValueFinancialFutures());
        getCell(sheet, "D87").setCellValue(data.getMarketValueCreditDerivatives());
        getCell(sheet, "C11").setCellValue(data.getCashInHand());
        getCell(sheet, "C12").setCellValue(data.getReserveHeldCB());
        getCell(sheet, "C14").setCellValue(data.getOtherBalances());
        getCell(sheet, "C16").setCellValue(data.getRepoedToUAECB());
        getCell(sheet, "C20").setCellValue(data.getOverseasBRNB());
        getCell(sheet, "C23").setCellValue(data.getCallAccountBookValue());
        getCell(sheet, "C24").setCellValue(data.getInterbankPlacements());
        getCell(sheet, "C25").setCellValue(data.getOtherTermPlacements());
        getCell(sheet, "C28").setCellValue(data.getLendingCoveredRepurchaseAgreements());
        getCell(sheet, "C35").setCellValue(data.getDebtSecurities1());
        getCell(sheet, "C36").setCellValue(data.getEquities1());
        getCell(sheet, "C40").setCellValue(data.getDebtSecurities2());
        getCell(sheet, "C41").setCellValue(data.getEquities2());
        getCell(sheet, "C42").setCellValue(data.getAssetsHeldMBills());
        getCell(sheet, "C44").setCellValue(data.getInvestmentSubsidiaries());
        getCell(sheet, "C45").setCellValue(data.getInvestmentAffiliates());
        getCell(sheet, "C67").setCellValue(data.getNetFixedAsset1());
        getCell(sheet, "C69").setCellValue(data.getNetFixedAsset2());
        getCell(sheet, "C71").setCellValue(data.getCapitalWorkInProgress());
        getCell(sheet, "C74").setCellValue(data.getInterestReceivable1());
        getCell(sheet, "C75").setCellValue(data.getPrepaidExpenses());
        getCell(sheet, "C77").setCellValue(data.getInterestReceivable2());
        getCell(sheet, "C80").setCellValue(data.getDividendReceivable());
        getCell(sheet, "C83").setCellValue(data.getMarketValueForwardContacts());
        getCell(sheet, "C86").setCellValue(data.getMarketValueFinancialFutures());
        getCell(sheet, "C87").setCellValue(data.getMarketValueCreditDerivatives());
    }

    @Override
    public void transform(Sheet sheet, List<AccountsReportingData> dataset) {
        transform(sheet, dataset.get(0));
    }

}
