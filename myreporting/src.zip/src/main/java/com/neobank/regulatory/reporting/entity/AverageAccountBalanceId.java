package com.neobank.regulatory.reporting.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data

@NoArgsConstructor
@Embeddable
public class AverageAccountBalanceId implements Serializable {

    @Column(name = "BUSINESS_ID")
    private String businessId;

    @Column(name = "ACCOUNT_TYPE")
    private String accountType;

}
