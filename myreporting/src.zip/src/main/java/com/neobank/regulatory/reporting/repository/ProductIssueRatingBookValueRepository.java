package com.neobank.regulatory.reporting.repository;

import com.neobank.regulatory.reporting.entity.ProductIssueRatingBookValue;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ProductIssueRatingBookValueRepository
        extends CrudRepository<ProductIssueRatingBookValue, String>, ReportingRepository {

    @Query(nativeQuery = true)
    public List<ProductIssueRatingBookValue> getIssueRatingsForProduct(LocalDate reportingDate);
}
