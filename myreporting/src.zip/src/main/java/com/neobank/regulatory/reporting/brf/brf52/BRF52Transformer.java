package com.neobank.regulatory.reporting.brf.brf52;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.model.LiabilitiesCapitalReportingData;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class BRF52Transformer implements BRFTransformer<LiabilitiesCapitalReportingData> {

    private void transform(Sheet sheet, LiabilitiesCapitalReportingData data) {
        getCell(sheet, "C22").setCellValue(data.getDemands());
        getCell(sheet, "C23").setCellValue(data.getSavings());
        getCell(sheet, "C47").setCellValue(data.getMoneyBorrowingRemainingBalance());
        getCell(sheet, "C48").setCellValue(data.getInterbankBorrowing());
        getCell(sheet, "C49").setCellValue(data.getOtherTermBorrowings());
        getCell(sheet, "C50").setCellValue(data.getBorrowingUnderRepurchase());
        getCell(sheet, "C63").setCellValue(data.getStaffBenefits());
        getCell(sheet, "C64").setCellValue(data.getOtherProvisions());
        getCell(sheet, "C66").setCellValue(data.getInterestPayable());
        getCell(sheet, "C67").setCellValue(data.getIncomeTaxLiability());
        getCell(sheet, "C68").setCellValue(data.getAccountsPayable());
        getCell(sheet, "C73").setCellValue(data.getAcceptances());
        getCell(sheet, "C74").setCellValue(data.getAllOtherBorrowings());
        getCell(sheet, "C85").setCellValue(data.getShareCapital());
        getCell(sheet, "C86").setCellValue(data.getTreasuryShares());
        getCell(sheet, "C88").setCellValue(data.getLegalReserves());
        getCell(sheet, "C90").setCellValue(data.getOtherComprehensiveIncome());
        getCell(sheet, "C91").setCellValue(data.getOtherReserves());
        getCell(sheet, "C92").setCellValue(data.getRetainedEarnings());
        getCell(sheet, "C93").setCellValue(data.getCurrentYearProfit());
        getCell(sheet, "C94").setCellValue(data.getInstrumentsPerpetual());
        getCell(sheet, "D22").setCellValue(data.getDemands());
        getCell(sheet, "D23").setCellValue(data.getSavings());
        getCell(sheet, "D47").setCellValue(data.getMoneyBorrowingRemainingBalance());
        getCell(sheet, "D48").setCellValue(data.getInterbankBorrowing());
        getCell(sheet, "D49").setCellValue(data.getOtherTermBorrowings());
        getCell(sheet, "D50").setCellValue(data.getBorrowingUnderRepurchase());
        getCell(sheet, "D63").setCellValue(data.getStaffBenefits());
        getCell(sheet, "D64").setCellValue(data.getOtherProvisions());
        getCell(sheet, "D66").setCellValue(data.getInterestPayable());
        getCell(sheet, "D67").setCellValue(data.getIncomeTaxLiability());
        getCell(sheet, "D68").setCellValue(data.getAccountsPayable());
        getCell(sheet, "D73").setCellValue(data.getAcceptances());
        getCell(sheet, "D74").setCellValue(data.getAllOtherBorrowings());
        getCell(sheet, "D85").setCellValue(data.getShareCapital());
        getCell(sheet, "D86").setCellValue(data.getTreasuryShares());
        getCell(sheet, "D88").setCellValue(data.getLegalReserves());
        getCell(sheet, "D90").setCellValue(data.getOtherComprehensiveIncome());
        getCell(sheet, "D91").setCellValue(data.getOtherReserves());
        getCell(sheet, "D92").setCellValue(data.getRetainedEarnings());
        getCell(sheet, "D93").setCellValue(data.getCurrentYearProfit());
        getCell(sheet, "D94").setCellValue(data.getInstrumentsPerpetual());
    }

    @Override
    public void transform(Sheet sheet, List<LiabilitiesCapitalReportingData> dataset) {
        transform(sheet, dataset.get(0));
    }

}
