package com.neobank.regulatory.reporting.services;

import com.neobank.regulatory.reporting.entity.ProductIssueRatingBookValue;
import com.neobank.regulatory.reporting.model.LiquidAssetsRatioQueryKey;
import io.jsonwebtoken.lang.Collections;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductsBookValueService {

    public double liquidAssetsRatio(List<ProductIssueRatingBookValue> bookValues, LiquidAssetsRatioQueryKey queryKey) {
        if (ObjectUtils.isNotEmpty(queryKey) && !Collections.isEmpty(bookValues)
                && !Collections.isEmpty(queryKey.getProducts())) {
            return bookValues.stream().filter(c -> queryKey.getProducts().contains(c.getId().getProduct()))
                    .filter(c -> Collections.isEmpty(queryKey.getIssueRatings()) ? Boolean.FALSE
                            : queryKey.getIssueRatings().contains(c.getId().getIssueRating()))
                    .mapToDouble(ProductIssueRatingBookValue::getBookValue).sum();
        }
        return 0.0d;
    }

}
