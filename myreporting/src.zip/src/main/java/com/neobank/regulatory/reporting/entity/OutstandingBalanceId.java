package com.neobank.regulatory.reporting.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;


@NoArgsConstructor
@Data
@Embeddable
public class OutstandingBalanceId implements Serializable {

    @Column(name = "NATIONALITY_TYPE")
    private String nationalityType;

    @Column(name = "SIZE_CATEGORY")
    private int sizeCategory;

}
