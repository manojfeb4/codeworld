package com.neobank.regulatory.reporting.config;

import com.neobank.common.config.YamlPropertySourceFactory;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Data
@Configuration
@ConfigurationProperties(prefix = "closing-balance")
@PropertySource(value = "classpath:mapping/accounts-closing-balance.yml", factory = YamlPropertySourceFactory.class)
public class AccountsClosingBalanceConfig {
    /**
     * § Cash in hand in AED ('000)
     */
    private ClosingBalanceQueryKey cashInHand;
    /**
     * State reserve held at CB in AED ('000)
     */
    private ClosingBalanceQueryKey reserveHeldCB;
    /**
     * Other balances in AED ('000)
     */
    private ClosingBalanceQueryKey otherBalances;
    /**
     * Reported to UAE Central Bank (gross)
     */
    private ClosingBalanceQueryKey reportedToUAECB;
    /**
     * Due from overseas BR of national banks/ Banking Subs.
     */
    private ClosingBalanceQueryKey overseasBRNB;
    /**
     * Money at call and short notice, placements on demand and remaining balances
     * held with other resident banks
     */
    private ClosingBalanceQueryKey callAccountBookValue;
    /**
     * Interbank placements with other resident banks
     */
    private ClosingBalanceQueryKey interbankPlacements;
    /**
     * Other term placements (loans)
     */
    private ClosingBalanceQueryKey otherTermPlacements;
    /**
     * Lending covered by repurchase agreements
     */
    private ClosingBalanceQueryKey lendingCoveredRepurchaseAgreements;
    /**
     * Debt securities
     */
    private ClosingBalanceQueryKey debtSecurities1;
    /**
     * Equities
     */
    private ClosingBalanceQueryKey equities1;
    /**
     * Debt securities
     */
    private ClosingBalanceQueryKey debtSecurities2;
    /**
     * Equities
     */
    private ClosingBalanceQueryKey equities2;
    /**
     * Assets Held to Maturity (M-Bills) in AED ('000)
     */
    private ClosingBalanceQueryKey assetsHeldMBills;
    /**
     * Investment in subsidiaries (Cost or fair value)
     */
    private ClosingBalanceQueryKey investmentSubsidiaries;
    /**
     * Investment in affiliates (Cost or fair value)
     */
    private ClosingBalanceQueryKey investmentAffiliates;
    /**
     * Net Fixed Assets - Business premises inclduing staff premises in AED ('000)
     */
    private ClosingBalanceQueryKey netFixedAsset1;
    /**
     * Net Fixed Assets - Furniture and fixtures in AED ('000)
     */
    private ClosingBalanceQueryKey netFixedAsset2;
    /**
     * Capital work in progress
     */
    private ClosingBalanceQueryKey capitalWorkInProgress;
    /**
     * Interest receivable
     */
    private ClosingBalanceQueryKey interestReceivable1;
    /**
     * Prepaid Expenses
     */
    private ClosingBalanceQueryKey prepaidExpenses;
    /**
     * Interest receivable
     */
    private ClosingBalanceQueryKey interestReceivable2;
    /**
     * Dividend receivables/Others
     */
    private ClosingBalanceQueryKey dividendReceivable;
    /**
     * Market value Forward contracts (including FX swaps)
     */
    private ClosingBalanceQueryKey marketValueForwardContacts;
    /**
     * Market value Financial Futures
     */
    private ClosingBalanceQueryKey marketValueFinancialFutures;
    /**
     * Market value Credit derivatives
     */
    private ClosingBalanceQueryKey marketValueCreditDerivatives;
}
