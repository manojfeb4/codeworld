package com.neobank.regulatory.reporting.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProductBookValueInfo {

    @Id
    @Column(name = "PRODUCT_NAME")
    private String productName;

    @Column(name = "NUM_OF_PRODUCTS")
    private int numOfProducts;

    @Column(name = "TOTAL_BOOK_VALUE")
    private BigDecimal totalBookValue;

}
