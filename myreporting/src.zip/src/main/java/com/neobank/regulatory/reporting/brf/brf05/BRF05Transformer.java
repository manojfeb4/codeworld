package com.neobank.regulatory.reporting.brf.brf05;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.TreasuryInvestment;
import com.neobank.regulatory.reporting.services.RatingsMappingHandler;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.CellCopyPolicy;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.neobank.regulatory.reporting.model.InvestmentProduct.MBILL;


@Component
@RequiredArgsConstructor
public class BRF05Transformer implements BRFTransformer<TreasuryInvestment> {

    private static final String HELD_TO_MATURITY = "HELD TO MATURITY (amortized cost)";

    private static final Integer START_ROW = 13;

    private final RatingsMappingHandler ratingsMappingHandler;

    public void transform(Sheet sheet, List<TreasuryInvestment> investments) {

        int currentRowNum = getRowNumFor(sheet, HELD_TO_MATURITY);

        int nextRow = currentRowNum + 1;

        sheet.shiftRows(nextRow, sheet.getLastRowNum(), investments.size() - 1, true, true);

        currentRowNum = updateSheetForHeldToMaturity(sheet, investments, currentRowNum);
        getCell(sheet, currentRowNum, 5).setCellFormula(String.format("SUM(F%d:F%d)", nextRow, currentRowNum));
        getCell(sheet, currentRowNum, 10).setCellFormula(String.format("SUM(K%d:K%d)", nextRow, currentRowNum));
        getCell(sheet, currentRowNum, 13).setCellFormula(String.format("SUM(N%d:N%d)", nextRow, currentRowNum));
    }

    private int updateSheetForHeldToMaturity(Sheet sheet, List<TreasuryInvestment> investments, int currentRowNum) {
        for (int rowNum = 0; rowNum < investments.size(); rowNum++) {
            var investment = investments.get(rowNum);
            if (rowNum < investments.size() - 1) {
                ((XSSFSheet) sheet).copyRows(currentRowNum, currentRowNum, currentRowNum + 1, new CellCopyPolicy());
            }

            getCell(sheet, currentRowNum, 1).setCellValue(Integer.toString(rowNum + 1));
            getCell(sheet, currentRowNum, 3).setCellValue(MBILL.getCode());
            getCell(sheet, currentRowNum, 4).setCellValue(investment.getIsin());
            getCell(sheet, currentRowNum, 5).setCellValue(NumberUtils.roundOffValue(investment.getFaceValue()));


            getCell(sheet, currentRowNum, 7).setCellValue(investment.getCountryOfBranch());
            getCell(sheet, currentRowNum, 8).setCellValue(investment.getCurrencyDescription());
            getCell(sheet, currentRowNum, 9).setCellValue(NumberUtils.roundOffValue(investment.getBookValue()));
            getCell(sheet, currentRowNum, 10).setCellValue(NumberUtils.roundOffValue(investment.getBookValue()));
            getCell(sheet, currentRowNum, 11)
                    .setCellValue(ratingsMappingHandler.getMappedRating(investment.getIssueRating()));
            getCell(sheet, currentRowNum, 12).setCellValue("External");
            getCell(sheet, currentRowNum, 13).setCellValue(NumberUtils.roundOffValue(investment.getMarketValue()));
            getCell(sheet, currentRowNum, 14).setCellValue("Federal Govt");

            currentRowNum++;

        }
        return currentRowNum;
    }


    private int getRowNumFor(Sheet sheet, String valueInExcel) {
        int currentRowNum = START_ROW;

        while (!sheet.getRow(currentRowNum).getCell(3).getStringCellValue().equalsIgnoreCase(valueInExcel)) {
            currentRowNum++;
        }
        return currentRowNum + 1;
    }

}
