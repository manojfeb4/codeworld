package com.neobank.regulatory.reporting.services;

import com.neobank.regulatory.reporting.entity.AccountsCountAndBalance;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountsCountAndBalanceService {

    public long count(List<AccountsCountAndBalance> list, String accountType) {
        if (StringUtils.isEmpty(accountType) || CollectionUtils.isEmpty(list)) {
            return 0;
        }
        return list.stream().filter(c -> c.getAccountType().equals(accountType))
                .mapToLong(AccountsCountAndBalance::getTotalCounts).sum();
    }

    public double balance(List<AccountsCountAndBalance> list, String accountType) {
        if (StringUtils.isEmpty(accountType) || CollectionUtils.isEmpty(list)) {
            return 0.0d;
        }
        return list.stream().filter(c -> c.getAccountType().equals(accountType))
                .mapToDouble(AccountsCountAndBalance::getTotalBalance).sum();
    }
}
