package com.neobank.regulatory.reporting.repository;


import com.neobank.regulatory.reporting.entity.InternationalPaymentId;
import com.neobank.regulatory.reporting.entity.InternationalPaymentInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InternationalPaymentRepository
        extends CrudRepository<InternationalPaymentInfo, InternationalPaymentId>, ReportingRepository {

    @Query(nativeQuery = true)
    List<InternationalPaymentInfo> getPaymentsByCountryAndClientSegments(String reportingFromDate, String reportingToDate, List<String> familySupportList,
                                                                         List<String> familyEducationList, List<String> familyMedical, List<String> financialInvestmentList,
                                                                         List<String> directInvestmentList, List<String> servicesList,
                                                                         List<String> clientSegments);

}
