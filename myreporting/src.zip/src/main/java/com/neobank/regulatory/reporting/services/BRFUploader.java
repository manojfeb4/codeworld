package com.neobank.regulatory.reporting.services;

import com.neobank.regulatory.reporting.model.event.TransformationContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

@Slf4j
@Component
@RequiredArgsConstructor
public class BRFUploader {

    private final AzureStorageAccountConnectorService azureStorageAccountConnector;

    @Value("${temp.storage}")
    private String tempStorage;


    public File uploadWorkbook(Workbook workbook, String fileName, TransformationContext payloadData) {

        try {
            var path = Paths.get(Objects.requireNonNull(tempStorage));
            createDirectoryIfPathDoesNotExist(path);
            String fileType = workbook instanceof XSSFWorkbook ? ".xlsx" : ".xls";
            File file = File.createTempFile(fileName + "-", fileType, new File(tempStorage));
            FileOutputStream fos = new FileOutputStream(file);
            workbook.write(fos);
            fos.flush();
            fos.close();
            azureStorageAccountConnector.uploadExcel(file, fileName, payloadData);

            return file;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    String.format("Unable to upload file: %s due to %s", fileName, e.getMessage()));
        }

    }

    private void createDirectoryIfPathDoesNotExist(Path path) throws IOException {
        if (!Files.exists(path)) {
            Files.createDirectories(path);
            log.info("Directory created at the path : {}", path);
        }
    }

}
