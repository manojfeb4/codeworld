package com.neobank.regulatory.reporting.services;

import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@PropertySource("classpath:mapping/rating-mapping.properties")
@Service
@RequiredArgsConstructor
public class RatingsMappingHandler {

    private final Environment env;

    public Integer getMappedRating(String ratingReceived) {
        String rating = env.getProperty(String.format("snp.%s", ratingReceived));
        return StringUtils.isNotEmpty(rating) ? Integer.parseInt(rating) : 0;
    }

}
