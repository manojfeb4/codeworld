package com.neobank.regulatory.reporting.repository;

import com.neobank.regulatory.reporting.entity.BookValuePerProduct;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TreasuryProductRepository extends CrudRepository<BookValuePerProduct, String>, ReportingRepository {

    @Query(nativeQuery = true)
    BookValuePerProduct getSumOfBookValueForInvestmentsByProductOnDate(String reportingDate, String productName);

    @Query(nativeQuery = true)
    List<BookValuePerProduct> getSumOfBookValueForInvestmentsByDate(LocalDate reportingDate);


}
