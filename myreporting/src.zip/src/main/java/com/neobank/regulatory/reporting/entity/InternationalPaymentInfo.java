package com.neobank.regulatory.reporting.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import java.math.BigDecimal;

@Entity
@Data
@NoArgsConstructor
public class InternationalPaymentInfo {

    @EmbeddedId
    InternationalPaymentId internationalPaymentId;

    @Column(name = "NUMBER_OF_TRANSACTIONS")
    private Long numberOfTransactions;

    @Column(name = "TOTAL_TRANSFERRED_AMOUNT")
    private BigDecimal totalTransferredAmount;

}
