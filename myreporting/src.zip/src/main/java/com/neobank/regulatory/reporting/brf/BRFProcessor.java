package com.neobank.regulatory.reporting.brf;

import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import org.apache.poi.ss.usermodel.Workbook;


public interface BRFProcessor {

    String getBrfId();

    <T> BRFTransformer<T> getBrfTransformer();

    ReportingRepository getReportingRepository();

    void process(Workbook wb, TransformationContext payloadData);

    void setMonthlyDefaultCells(Workbook wb, TransformationContext payloadData);

    void setQuarterlyDefaultCells(Workbook wb, TransformationContext payloadData);
}
