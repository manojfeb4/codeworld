package com.neobank.regulatory.reporting.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class GlobalIncomeExpenseReportingData {


    private double interestIncome;
    private double investmentIncome;
    private double otherOperatingIncome;
    private double interestExpenses;
    private double staffExpenses;
    private double premisesExpenses;
    private double depreciationAndAmortisation;
    private double otherAdminAndGeneralExpenses;


}
