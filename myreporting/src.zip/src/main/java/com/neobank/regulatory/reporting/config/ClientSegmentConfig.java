package com.neobank.regulatory.reporting.config;

import com.neobank.common.config.YamlPropertySourceFactory;
import com.neobank.regulatory.reporting.model.ClientSegmentQueryKey;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Data
@Configuration
@ConfigurationProperties(prefix = "client-segment-classification")
@PropertySource(value = "classpath:mapping/client-segment-values.yml", factory = YamlPropertySourceFactory.class)
public class ClientSegmentConfig {

    private ClientSegmentQueryKey averageGovtKeys;
    private ClientSegmentQueryKey averageOtherKeys;
    private ClientSegmentQueryKey paymentGovtKeys;
    private ClientSegmentQueryKey paymentCorporateKeys;
    private ClientSegmentQueryKey paymentGreKeys;
    private ClientSegmentQueryKey paymentIndividualKeys;
    private ClientSegmentQueryKey paymentSmeKeys;


}
