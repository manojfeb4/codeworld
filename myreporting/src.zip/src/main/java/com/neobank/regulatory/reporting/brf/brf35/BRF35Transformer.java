package com.neobank.regulatory.reporting.brf.brf35;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.brf.services.GTreasuryService;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellReference;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static java.lang.String.format;

@Component
@Slf4j
public class BRF35Transformer implements BRFTransformer<String[]> {

    private static final int START_ROW = 11;

    private static final String FORMULA_RANGE_REGEX = "(?<=\\()[^\\)]+";

    private static final String B_D = "B%d";

    private static final String C_D = "C%d";

    private static final String D_D = "D%d";

    private static final String E_D = "E%d";

    private static final String F_D = "F%d";

    private static final String G_D = "G%d";

    private static final String H_D = "H%d";

    private static final String I_D = "I%d";

    private final GTreasuryService gTreasuryService;

    public BRF35Transformer(GTreasuryService gTreasuryService) {
        this.gTreasuryService = gTreasuryService;
    }

    @Override
    public void transform(Sheet sheet, List<String[]> totalBookValuesForBanksAndProducts) {
        var totalBookValueForBankByProduct = gTreasuryService
                .getTotalBookValueForBankAndProducts(totalBookValuesForBanksAndProducts);


        log.debug("investments: {}", totalBookValueForBankByProduct);

        var nonZeroBankBalances = totalBookValueForBankByProduct.entrySet().stream()
                .filter(e -> e.getValue().values().stream().anyMatch(v -> v > 0))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        AtomicInteger rowNum = new AtomicInteger(START_ROW);
        AtomicInteger counter = new AtomicInteger(1);

        nonZeroBankBalances.forEach((bank, products) -> {


            getCell(sheet, format(B_D, rowNum.get())).setCellValue(counter.get());
            getCell(sheet, format(C_D, rowNum.get())).setCellValue(bank.getBankName());
            getCell(sheet, format(D_D, rowNum.get())).setCellValue(bank.getCountryOfBranch());
            getCell(sheet, format(E_D, rowNum.get())).setCellValue(bank.getCountryOfHeadOffice());


            products.entrySet().stream()
                    .filter(e -> e.getValue() > 0.00)
                    .forEach(e -> {

                        String col = e.getKey().equals("TERM") ? F_D : H_D;

                        var amountValue = NumberUtils.roundOffValue(e.getValue());
                        getCell(sheet, format(G_D, rowNum.get())).setCellValue(0.0d);
                        getCell(sheet, format(col, rowNum.get())).setCellValue(amountValue);
                        getCell(sheet, format(I_D, rowNum.get())).setCellValue(0.0d);

                    });

            getCell(sheet, format(B_D, rowNum.get())).setCellValue(counter.get());
            getCell(sheet, format(C_D, rowNum.get())).setCellValue(bank.getBankName());
            getCell(sheet, format(D_D, rowNum.get())).setCellValue(bank.getCountryOfBranch());
            getCell(sheet, format(E_D, rowNum.get())).setCellValue(bank.getCountryOfHeadOffice());
            addRow(sheet, rowNum.get());
            rowNum.getAndAdd(1);
            counter.getAndAdd(1);


        });


        updateFormula(sheet, format(F_D, rowNum.get() + 1), format(F_D, START_ROW) + ":" + format(F_D, rowNum.get()));
        updateFormula(sheet, format(G_D, rowNum.get() + 1), format(G_D, START_ROW) + ":" + format(G_D, rowNum.get()));
        updateFormula(sheet, format(H_D, rowNum.get() + 1), format(H_D, START_ROW) + ":" + format(H_D, rowNum.get()));
        updateFormula(sheet, format(I_D, rowNum.get() + 1), format(I_D, START_ROW) + ":" + format(I_D, rowNum.get()));
    }

    private void addRow(Sheet sheet, int row) {
        var fromRow = row - 1;
        var currentRow = sheet.getRow(fromRow);
        sheet.shiftRows(row, sheet.getLastRowNum(), 1);
        var newRow = sheet.getRow(row);
        for (int i = 0; i < currentRow.getLastCellNum(); i++) {
            var newCell = newRow.createCell(i);
            var oldCell = currentRow.getCell(i);
            newCell.setCellStyle(oldCell.getCellStyle());
        }
    }

    private void updateFormula(Sheet sheet, String cellRef, String formulaRange) {
        var cellReference = new CellReference(cellRef);
        var formulaCell = sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
        var formula = formulaCell.toString();
        formulaCell.setCellFormula(formula.replaceFirst(FORMULA_RANGE_REGEX, formulaRange));
    }

}
