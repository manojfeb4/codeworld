package com.neobank.regulatory.reporting.brf.brf40;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.BookValuePerProduct;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.repository.TreasuryProductRepository;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import static com.neobank.regulatory.reporting.model.InvestmentProduct.MBILL;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_40;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component
public class BRF40Processor extends AbstractBRFProcessor {

    private static final String D38 = "D38";

    private static final String L38 = "L38";

    private final BRF40Transformer brf40Transformer;

    private final TreasuryProductRepository treasuryProductRepository;

    public BRF40Processor(BRF40Transformer brf40Transformer, TreasuryProductRepository treasuryProductRepository) {
        this.brf40Transformer = brf40Transformer;
        this.treasuryProductRepository = treasuryProductRepository;
    }

    @Override
    public String getBrfId() {
        return BRF + BRF_40;
    }

    @Override
    public BRFTransformer<BookValuePerProduct> getBrfTransformer() {
        return brf40Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return treasuryProductRepository;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.info("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();
        var bookValuePerProduct = treasuryProductRepository
                .getSumOfBookValueForInvestmentsByProductOnDate(reportingDate.format(ISO_DATE), MBILL.getCode());
        log.debug("Fetched Treasury Investments: {}", bookValuePerProduct);
        updateSheet(wb.getSheetAt(0), bookValuePerProduct);
        log.info("{} generated successfully.", getBrfId());
    }

    private void updateSheet(Sheet sheet, BookValuePerProduct bookValuePerProduct) {

        if (bookValuePerProduct == null) {
            return;
        }
        var bookValue = NumberUtils.roundOffValue(bookValuePerProduct.getBookValue());
        getCell(sheet, D38).setCellValue(bookValue);
        getCell(sheet, L38).setCellValue(bookValue);
    }

}
