package com.neobank.regulatory.reporting.services;

import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.model.AssetsLiabilitesMaturityClassificationQueryKey;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import com.neobank.regulatory.reporting.model.LiquidAssetsRatioQueryKey;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

import static java.lang.Boolean.TRUE;

@Service
public class AccountsClosingBalanceService {

    public double closingBalance(List<AccountClosingBalance> balances, ClosingBalanceQueryKey queryKey) {
        if (ObjectUtils.isNotEmpty(queryKey) && !CollectionUtils.isEmpty(balances)
                && !CollectionUtils.isEmpty(queryKey.getAccounts())) {
            return balances.stream().filter(c -> filterAccount(c, queryKey.getAccounts()) && filterProduct(c, queryKey))
                    .mapToDouble(AccountClosingBalance::getClosingBalance).sum();
        }
        return 0.0d;
    }

    public long closingBalanceCount(List<AccountClosingBalance> balances, ClosingBalanceQueryKey queryKey) {
        if (ObjectUtils.isNotEmpty(queryKey) && !CollectionUtils.isEmpty(balances)
                && !CollectionUtils.isEmpty(queryKey.getAccounts())) {
            return balances.stream().filter(c -> filterAccount(c, queryKey.getAccounts()))
                    .collect(Collectors.counting());
        }
        return 0l;
    }

    public double liquidAssetsRatio(List<AccountClosingBalance> balances, LiquidAssetsRatioQueryKey queryKey) {
        if (ObjectUtils.isNotEmpty(queryKey) && !CollectionUtils.isEmpty(balances)
                && !CollectionUtils.isEmpty(queryKey.getAccounts())) {
            return balances.stream()
                    .filter(balance -> queryKey.getAccounts().contains(balance.getId()
                            .getMainAccount()))
                    .mapToDouble(AccountClosingBalance::getClosingBalance).sum();
        }
        return 0.0d;
    }

    private boolean filterAccount(AccountClosingBalance acc, List<String> accounts) {
        return accounts.contains(acc.getId().getMainAccount());

    }

    private boolean filterProduct(AccountClosingBalance acc, ClosingBalanceQueryKey queryKey) {
        return CollectionUtils.isEmpty(queryKey.getProducts()) ? TRUE
                : queryKey.getProducts().contains(acc.getId().getProduct().toUpperCase());
    }

    public double closingBalanceForMaturity(List<AccountClosingBalance> accounts,
                                            AssetsLiabilitesMaturityClassificationQueryKey queryKey) {
        if (ObjectUtils.isNotEmpty(queryKey) && !CollectionUtils.isEmpty(accounts)
                && !CollectionUtils.isEmpty(queryKey.getAccounts())) {
            return accounts.stream().filter(c -> filterAccount(c, queryKey.getAccounts()))
                    .mapToDouble(AccountClosingBalance::getClosingBalance).sum();
        }
        return 0.0d;
    }

}
