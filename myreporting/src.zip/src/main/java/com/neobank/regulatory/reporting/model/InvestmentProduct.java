package com.neobank.regulatory.reporting.model;

import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@Getter
@ToString(of = {"code"})
public enum InvestmentProduct implements Serializable {

    CALL_DEPOSIT("Call Account"), MBILL("MBILLS Investment"), NCD("NCD Investment"), TERM_DEPOSIT(
            "Term Deposit AED"), TERM_DEPOSIT_BORROW("Term Deposit AED Borrow"), TERM_DEPOSIT_USD(
            "Term Deposit USD"), TERM_DEPOSIT_USD_BORROW("Term Deposit USD Borrow"), UNKNOWN("unknown");

    private static final Map<String, InvestmentProduct> ipMAp = new HashMap<>();

    static {
        for (var v : values()) {
            InvestmentProduct.ipMAp.put(v.code, v);
        }
    }

    private String code;

    InvestmentProduct(String code) {
        this.code = code;

    }

    public static InvestmentProduct getInvestmentProduct(final String code) {
        var ip = InvestmentProduct.ipMAp.get(code);
        return null == ip ? null : ip;
    }

}
