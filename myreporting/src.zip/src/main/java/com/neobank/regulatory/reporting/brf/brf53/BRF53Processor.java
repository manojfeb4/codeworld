package com.neobank.regulatory.reporting.brf.brf53;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.config.GlobalIncomeExpenseAccountsConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import com.neobank.regulatory.reporting.model.GlobalIncomeExpenseReportingData;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_53;

@Slf4j
@Component
public class BRF53Processor extends AbstractBRFProcessor {

    private final BRF53Transformer brf53Transformer;
    private final AccountClosingBalanceRepository accountClosingBalanceRepository;


    private final AccountsClosingBalanceService accountsClosingBalanceService;


    private final GlobalIncomeExpenseAccountsConfig globalIncomeExpenseAccountsConfig;


    public BRF53Processor(BRF53Transformer brf53Transformer,
                          AccountClosingBalanceRepository accountClosingBalanceRepository,
                          AccountsClosingBalanceService accountClosingBalanceService,
                          GlobalIncomeExpenseAccountsConfig globalIncomeExpenseAccountsConfig) {
        this.brf53Transformer = brf53Transformer;
        this.accountClosingBalanceRepository = accountClosingBalanceRepository;
        this.accountsClosingBalanceService = accountClosingBalanceService;
        this.globalIncomeExpenseAccountsConfig = globalIncomeExpenseAccountsConfig;

    }

    @Override
    public String getBrfId() {
        return BRF + BRF_53;
    }

    @Override
    public BRFTransformer<GlobalIncomeExpenseReportingData> getBrfTransformer() {
        return brf53Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return null;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();
        setQuarterlyDefaultCells(wb, payloadData);
        brf53Transformer.transform(wb.getSheetAt(0), List.of(reportingData(reportingDate)));

        log.info("{} generated successfully.", getBrfId());
    }

    private List<AccountClosingBalance> getClosingBalanceForAccounts(LocalDate reportingDate) {
        return accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(reportingDate);
    }


    private double closingBalance(List<AccountClosingBalance> accounts, ClosingBalanceQueryKey queryKey) {
        return NumberUtils.roundOffValue(accountsClosingBalanceService.closingBalance(accounts, queryKey));
    }

    private GlobalIncomeExpenseReportingData reportingData(LocalDate reportingDate) {
        var accounts = getClosingBalanceForAccounts(reportingDate);
        log.debug("accounts: " + Arrays.deepToString(accounts.toArray()));
        return GlobalIncomeExpenseReportingData.builder()
                .interestIncome(closingBalance(accounts, globalIncomeExpenseAccountsConfig.getInterestIncomeKeys()))
                .investmentIncome(closingBalance(accounts, globalIncomeExpenseAccountsConfig.getInvestmentIncomeKeys()))
                .otherOperatingIncome(closingBalance(accounts, globalIncomeExpenseAccountsConfig.getOtherOperatingIncomeKeys()))
                .interestExpenses(closingBalance(accounts, globalIncomeExpenseAccountsConfig.getInterestExpenseKeys()))
                .staffExpenses(closingBalance(accounts, globalIncomeExpenseAccountsConfig.getStaffExpenseKeys()))
                .premisesExpenses(closingBalance(accounts, globalIncomeExpenseAccountsConfig.getPremisesExpenseKeys()))
                .depreciationAndAmortisation(closingBalance(accounts, globalIncomeExpenseAccountsConfig.getDepreciationAndAmortisationKeys()))
                .otherAdminAndGeneralExpenses(closingBalance(accounts, globalIncomeExpenseAccountsConfig.getOtherAdminAndGeneralExpenseKeys()))
                .build();
    }

}
