package com.neobank.regulatory.reporting.brf;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellReference;

import java.util.List;

public interface BRFTransformer<T> {

    void transform(Sheet sheet, List<T> dataset);

    default Cell getCell(Sheet sheet, int rownum, int cellnum) {
        Row row = sheet.getRow(rownum);
        return row.getCell(cellnum);
    }

    default Cell getCell(Sheet sheet, String reference) {
        var cellReference = new CellReference(reference);
        return sheet.getRow(cellReference.getRow()).getCell(cellReference.getCol());
    }

}
