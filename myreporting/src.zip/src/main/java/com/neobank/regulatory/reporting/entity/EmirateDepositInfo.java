package com.neobank.regulatory.reporting.entity;


import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
@Data
@NoArgsConstructor

public class EmirateDepositInfo {

    @EmbeddedId
    private EmirateDepositId emirateDepositId;

    @Column(name = "NUMBER_OF_CUSTOMERS")
    private int numberOfCustomers;

    @Column(name = "NUMBER_OF_ACCOUNTS")
    private int numberOfAccounts;

    @Column(name = "TOTAL_ACCOUNT_BALANCE")
    private double totalAccountBalance;

}
