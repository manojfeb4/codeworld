package com.neobank.regulatory.reporting.repository;


import com.neobank.regulatory.reporting.entity.RemittanceId;
import com.neobank.regulatory.reporting.entity.RemittanceInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RemittanceRepository
        extends CrudRepository<RemittanceInfo, RemittanceId>, ReportingRepository {

    @Query(nativeQuery = true)
    List<RemittanceInfo> getCountryWiseRemittance(String reportingFromDate, String reportingToDate, List<String> remittanceTypeFamilyList,
                                                  List<String> remittanceTypeInvestmentList, List<String> remittanceTypeOtherList);

}
