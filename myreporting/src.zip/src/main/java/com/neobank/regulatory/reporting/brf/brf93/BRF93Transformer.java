package com.neobank.regulatory.reporting.brf.brf93;

import com.neobank.ods.schema.enums.Country;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.InternationalPaymentInfo;
import com.neobank.regulatory.reporting.model.RemittanceCountries;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class BRF93Transformer implements BRFTransformer<InternationalPaymentInfo> {
    private static final List<String> individualTransferPurpose = List.of("Financial Investment", "Direct Investment", "Family Support", "Education", "Medical", "Tourism", "Debt Settlement", "Other Services");
    private static final List<String> nonIndividualTransferPurpose = List.of("Financial Investment", "Direct Investment", "Services", "Trade");
    private static final List<String> clientSegmentList = List.of("government", "reserve", "gre", "corporate", "sme", "individual");

    List<String> getRemittanceCountriesList() {
        return EnumSet.allOf(RemittanceCountries.class)
                .stream()
                .map(RemittanceCountries::getCountryName)
                .collect(Collectors.toList());
    }

    public void transform(Sheet sheet, Map<String, List<InternationalPaymentInfo>> paymentInfoMap) {
        var countriesList = getRemittanceCountriesList();


        paymentInfoMap.forEach((clientSegment, paymentInfoList) -> {
            int startCol = (clientSegmentList.indexOf(clientSegment) * 8) + 3;

            var tempStartCol = startCol;
            log.debug("Client Segment : {}", clientSegment);
            paymentInfoList.stream().forEach(paymentInfo -> {
                var transferPurpose = paymentInfo.getInternationalPaymentId().getTransferPurpose();
                var subCol = clientSegment.equals("individual") ?
                        (individualTransferPurpose.indexOf(transferPurpose) * 2) :
                        (nonIndividualTransferPurpose.indexOf(transferPurpose) * 2);

                var startRow = 9;

                var dRow = 0;
                var dCol = 0;
                var countryIndex = -1;


                var totalTransferredAmount = paymentInfo.getTotalTransferredAmount();
                var numberOfTransfers = paymentInfo.getNumberOfTransactions();
                var recipientCountryCode = paymentInfo.getInternationalPaymentId().getRecipientCountry();
                var recipientCountryIso2 = Country.getEnumByCountryIso2(recipientCountryCode);
                if (recipientCountryIso2 != null) {
                    var recipientCountryValue = recipientCountryIso2.getCountryName();
                    countryIndex = countriesList.indexOf(recipientCountryValue);
                    log.debug("recipientCountryCode: {}, recipientCountry: {}, transferPurpose: {}, ", recipientCountryCode, recipientCountryValue, transferPurpose);

                }


                dRow = countryIndex >= 0 ? (startRow + countryIndex) : (startRow + countriesList.size() + 1);
                dCol = tempStartCol + subCol;


                log.debug("numberOfTransfers: {}, totalTransferredAmount: {}, row: {}, col: {}",
                        numberOfTransfers, totalTransferredAmount, dRow, dCol);
                if (dCol > 1) {
                    getCell(sheet, dRow, dCol).setCellValue(numberOfTransfers);

                    getCell(sheet, dRow, dCol + 1).setCellValue(NumberUtils.roundOffValue(totalTransferredAmount.doubleValue()));
                }
            });


        });

    }


    @Override
    public void transform(Sheet sheet, List<InternationalPaymentInfo> paymentInfo) {
        transform(sheet, (Map<String, List<InternationalPaymentInfo>>) paymentInfo);
    }

}