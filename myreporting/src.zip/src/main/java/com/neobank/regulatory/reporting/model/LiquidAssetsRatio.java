package com.neobank.regulatory.reporting.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LiquidAssetsRatio {

    /**
     * Physical cash in hand at the bank (AED '000)
     */
    private double physicalCashInHand;

    /**
     * Statutory reserves with Central Bank (AED '000)
     */
    private double statutoryReservesCB;

    /**
     * Free and other account balances at the Central Bank (excluding statutory
     * reserves) (AED '000)
     */
    private double freeOtherAccountBalancesCB;

    /**
     * UAE local governments publicly traded debt securities (0% Risk Weighted under
     * Bill Standardised approach) Rated A+ and above (AED '000)
     */
    private double governmentPubliclyTradedDebtSecurities;

    /**
     * Total Liabilities
     */
    private double totalLiabilities;
}
