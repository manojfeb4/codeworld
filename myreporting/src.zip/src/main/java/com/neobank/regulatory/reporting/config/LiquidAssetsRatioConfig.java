package com.neobank.regulatory.reporting.config;

import com.neobank.common.config.YamlPropertySourceFactory;
import com.neobank.regulatory.reporting.model.LiquidAssetsRatioQueryKey;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Data
@Configuration
@ConfigurationProperties(prefix = "liquid-assets-ratio")
@PropertySource(value = "classpath:mapping/liquid-assets-ratio.yml", factory = YamlPropertySourceFactory.class)
public class LiquidAssetsRatioConfig {

    /**
     * Physical cash in hand at the bank (AED '000)
     */
    private LiquidAssetsRatioQueryKey physicalCashInHand;

    /**
     * Statutory reserves with Central Bank (AED '000)
     */
    private LiquidAssetsRatioQueryKey statutoryReservesCB;

    /**
     * Free and other account balances at the Central Bank (excluding statutory
     * reserves) (AED '000)
     */
    private LiquidAssetsRatioQueryKey freeOtherAccountBalancesCB;

    /**
     * UAE local governments publicly traded debt securities (0% Risk Weighted under
     * Bill Standardised approach) Rated A+ and above (AED '000)
     */
    private LiquidAssetsRatioQueryKey governmentPubliclyTradedDebtSecurities;

    /**
     * Total Liabilities
     */
    private LiquidAssetsRatioQueryKey totalLiabilities;
}
