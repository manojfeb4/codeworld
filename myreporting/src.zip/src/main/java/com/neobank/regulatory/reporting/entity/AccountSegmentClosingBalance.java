package com.neobank.regulatory.reporting.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import java.math.BigDecimal;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class AccountSegmentClosingBalance {
    @EmbeddedId
    AccountSegmentClosingBalanceId accountSegmentClosingBalanceId;

    @Column(name = "TOTAL_BALANCE")
    private BigDecimal totalBalance;
}
