package com.neobank.regulatory.reporting.brf.brf60;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.model.InvestmentLimitReportingData;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class BRF60Transformer implements BRFTransformer<InvestmentLimitReportingData> {

    private void transform(Sheet sheet, InvestmentLimitReportingData data) {
        getCell(sheet, "D11").setCellValue(data.getNumOfDebtSecurities());
        getCell(sheet, "E11").setCellValue(data.getTotalBookValueOfDebtSecurities());
        getCell(sheet, "D16").setCellValue(data.getNumOfBankOwnedFunds());
        getCell(sheet, "E16").setCellValue(data.getTotalBalanceOfBankOwnedFunds());
    }

    @Override
    public void transform(Sheet sheet, List<InvestmentLimitReportingData> dataset) {
        transform(sheet, dataset.get(0));
    }

}
