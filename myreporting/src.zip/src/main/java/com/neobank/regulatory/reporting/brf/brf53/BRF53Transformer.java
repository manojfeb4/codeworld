package com.neobank.regulatory.reporting.brf.brf53;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.model.GlobalIncomeExpenseReportingData;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class BRF53Transformer implements BRFTransformer<GlobalIncomeExpenseReportingData> {

    private void transform(Sheet sheet, GlobalIncomeExpenseReportingData data) {

        getCell(sheet, "D11").setCellValue(data.getInterestIncome());
        getCell(sheet, "D12").setCellValue(data.getInvestmentIncome());
        getCell(sheet, "D13").setCellValue(data.getOtherOperatingIncome());
        getCell(sheet, "D14").setCellValue(data.getInterestExpenses());

        getCell(sheet, "D16").setCellValue(data.getStaffExpenses());
        getCell(sheet, "D17").setCellValue(data.getPremisesExpenses());
        getCell(sheet, "D18").setCellValue(data.getDepreciationAndAmortisation());
        getCell(sheet, "D19").setCellValue(data.getOtherAdminAndGeneralExpenses());

    }

    @Override
    public void transform(Sheet sheet, List<GlobalIncomeExpenseReportingData> dataset) {
        transform(sheet, dataset.get(0));
    }

}
