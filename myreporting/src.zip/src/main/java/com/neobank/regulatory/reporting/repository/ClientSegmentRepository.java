package com.neobank.regulatory.reporting.repository;

import com.neobank.regulatory.reporting.entity.ClientSegmentInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClientSegmentRepository extends CrudRepository<ClientSegmentInfo, String>, ReportingRepository {

    @Query(nativeQuery = true)
    List<ClientSegmentInfo> getBusinessesOfClientSegments(List<String> clientSegments);

}
