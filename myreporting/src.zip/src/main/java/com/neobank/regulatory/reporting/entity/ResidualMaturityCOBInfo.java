package com.neobank.regulatory.reporting.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;


/**
 * Residual Maturity with Country of Branch
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class ResidualMaturityCOBInfo {

    @EmbeddedId
    ResidualMaturityCOBId residualMaturityCOBId;

    @Column(name = "TOTALBOOKVALUE")
    private double totalBookValue;

}
