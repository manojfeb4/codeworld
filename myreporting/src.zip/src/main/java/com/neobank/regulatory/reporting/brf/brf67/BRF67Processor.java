package com.neobank.regulatory.reporting.brf.brf67;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.OutstandingBalanceInfo;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.OutstandingBalanceRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_67;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component
@AllArgsConstructor
public class BRF67Processor extends AbstractBRFProcessor {

    private final BRF67Transformer brf67Transformer;

    private final OutstandingBalanceRepository outstandingBalanceRepository;

    @Override
    public String getBrfId() {
        return BRF + BRF_67;
    }

    @Override
    public BRFTransformer<OutstandingBalanceInfo> getBrfTransformer() {
        return brf67Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return outstandingBalanceRepository;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();
        List<OutstandingBalanceInfo> sameNationDepositsInfoList = outstandingBalanceRepository
                .getSizeWiseDepositsSameNation(reportingDate.format(ISO_DATE));
        List<OutstandingBalanceInfo> otherNationDepositsInfoList = outstandingBalanceRepository
               .getSizeWiseDepositsOtherNation(reportingDate.format(ISO_DATE));

        List<OutstandingBalanceInfo> outstandingBalanceInfoList = new ArrayList<>();
        outstandingBalanceInfoList.addAll(sameNationDepositsInfoList);
        outstandingBalanceInfoList.addAll(otherNationDepositsInfoList);
        log.info("Fetched Total {} Records", outstandingBalanceInfoList.size());
        log.info("Reporting Date : {}", reportingDate.format(ISO_DATE));
        log.debug(Arrays.deepToString(outstandingBalanceInfoList.toArray()));
        brf67Transformer.transform(wb.getSheetAt(0), outstandingBalanceInfoList);
        log.info("{} generated successfully.", getBrfId());
    }


}
