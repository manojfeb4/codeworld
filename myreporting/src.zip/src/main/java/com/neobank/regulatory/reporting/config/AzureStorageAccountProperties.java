package com.neobank.regulatory.reporting.config;

import com.azure.storage.blob.BlobContainerClientBuilder;
import lombok.Data;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.neobank.regulatory.reporting.util.BankReportingForms.HTTPS_PROTOCOL;

@Data
@Configuration
@ConfigurationProperties("regulatory.reporting.storageaccount")
public class AzureStorageAccountProperties {

    private String name;

    private String key;

    private String containerName;

    private boolean enabled;

    @Bean
    @ConditionalOnProperty(name = "regulatory.reporting.storageaccount.enabled", havingValue = "false")
    public BlobContainerClientBuilder getTestClient() {
        return new BlobContainerClientBuilder();
    }

    @Bean
    @ConditionalOnProperty(name = "regulatory.reporting.storageaccount.enabled", havingValue = "true")
    public BlobContainerClientBuilder getClient() {
        var client = new BlobContainerClientBuilder();
        client.connectionString(
                String.format("DefaultEndpointsProtocol=%s;AccountName=%s;AccountKey=%s", HTTPS_PROTOCOL, name, key));
        client.containerName(containerName);
        return client;
    }

}
