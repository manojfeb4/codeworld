package com.neobank.regulatory.reporting.config;

import com.neobank.common.config.YamlPropertySourceFactory;
import com.neobank.regulatory.reporting.model.ClientSegmentQueryKey;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Data
@Configuration
@ConfigurationProperties(prefix = "cross-brf-validation")
@PropertySource(value = "classpath:mapping/cross-brf-validation.yml", factory = YamlPropertySourceFactory.class)
public class CrossBrfValidationConfig {

    private ClosingBalanceQueryKey mbillKeys;
    private ClosingBalanceQueryKey termDepositKeys;
    private ClosingBalanceQueryKey callDepositKeys;
    private ClosingBalanceQueryKey ncdInvestmentKeys;
    private ClosingBalanceQueryKey currentAccountKeys;
    private ClosingBalanceQueryKey regularSavingKeys;



}
