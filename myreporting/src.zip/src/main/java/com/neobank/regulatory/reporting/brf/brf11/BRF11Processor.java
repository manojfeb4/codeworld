package com.neobank.regulatory.reporting.brf.brf11;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.config.AssetsLiabilitesMaturityClassificationBrf11Config;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.entity.AccountSegmentClosingBalance;
import com.neobank.regulatory.reporting.entity.ResidualMaturityCOBInfo;
import com.neobank.regulatory.reporting.model.AssetsLiabilitesMaturityClassificationQueryKey;
import com.neobank.regulatory.reporting.model.AssetsLiabilitesMaturityClassificationReportingData;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.AccountSegmentClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.repository.ResidualMaturityCOBRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.services.AssetsLiabilitesMaturityClassificationService;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;


import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.neobank.regulatory.reporting.model.InvestmentProduct.*;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_11;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component

public class BRF11Processor extends AbstractBRFProcessor {

	private static final String UNITED_ARAB_EMIRATES = "United Arab Emirates";

	private final BRF11Transformer brf11Transformer;

	private final AssetsLiabilitesMaturityClassificationBrf11Config assetsLiabilitesMaturityClassificationBrf11Config;

	private final AssetsLiabilitesMaturityClassificationService assetsLiabilitesMaturityClassificationService;

	private final AccountClosingBalanceRepository accountClosingBalanceRepository;

	private final AccountsClosingBalanceService accountsClosingBalanceService;

	private final ResidualMaturityCOBRepository residualMaturityCOMRepository;

	private final AccountSegmentClosingBalanceRepository accountSegmentClosingBalanceRepository;

	public BRF11Processor(BRF11Transformer brf11Transformer,
			AssetsLiabilitesMaturityClassificationBrf11Config assetsLiabilitesMaturityClassificationBrf11Config,
			AssetsLiabilitesMaturityClassificationService assetsLiabilitesMaturityClassificationService,
			AccountClosingBalanceRepository accountClosingBalanceRepository,
			ResidualMaturityCOBRepository residualMaturityCOMRepository,
			AccountsClosingBalanceService accountsClosingBalanceService,
			AccountSegmentClosingBalanceRepository accountSegmentClosingBalanceRepository) {
		this.brf11Transformer = brf11Transformer;
		this.assetsLiabilitesMaturityClassificationBrf11Config = assetsLiabilitesMaturityClassificationBrf11Config;
		this.assetsLiabilitesMaturityClassificationService = assetsLiabilitesMaturityClassificationService;
		this.accountClosingBalanceRepository = accountClosingBalanceRepository;
		this.residualMaturityCOMRepository = residualMaturityCOMRepository;
		this.accountsClosingBalanceService = accountsClosingBalanceService;
		this.accountSegmentClosingBalanceRepository = accountSegmentClosingBalanceRepository;
	}

	@Override
	public String getBrfId() {
		return BRF + BRF_11;
	}

	@Override
	public ReportingRepository getReportingRepository() {
		return null;
	}

	@Override
	public BRFTransformer<AssetsLiabilitesMaturityClassificationReportingData> getBrfTransformer() {
		return brf11Transformer;
	}

	@Override
	public void process(Workbook wb, TransformationContext payloadData) {
		log.info("Start processing {}.", getBrfId());
		var reportingDate = payloadData.getReportingToDate();
		getBrfTransformer().transform(wb.getSheetAt(0), List.of(reportingData(reportingDate)));
		log.info("{} generated successfully.", getBrfId());
	}

	private List<AccountClosingBalance> getClosingBalanceForAccounts(LocalDate reportingDate) {
		return accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(reportingDate);
	}

	private double closingBalance(List<AccountClosingBalance> accounts,
			AssetsLiabilitesMaturityClassificationQueryKey queryKey) {
		return accountsClosingBalanceService.closingBalanceForMaturity(accounts, queryKey);
	}

	private Map<String, Double> residualMaturity(List<ResidualMaturityCOBInfo> rdList,
			AssetsLiabilitesMaturityClassificationQueryKey queryKey) {
		return assetsLiabilitesMaturityClassificationService.residualMaturityWithReference(rdList, queryKey);
	}

	private Map<String, Double> residualMaturityForcountry(List<ResidualMaturityCOBInfo> rdList,
			AssetsLiabilitesMaturityClassificationQueryKey queryKey, String cob, boolean resident) {
		return assetsLiabilitesMaturityClassificationService.residualMaturityWithReferenceAndCountry(rdList, queryKey,
				cob, resident);
	}

	private double segment1Balance(List<AccountSegmentClosingBalance> data, List<String> segments) {
		return data.stream().filter(s -> segments.contains(s.getAccountSegmentClosingBalanceId().getSegment1()))
				.mapToDouble(d -> d.getTotalBalance().doubleValue()).sum();
	}

	private double segment1AndSegment2Balance(List<AccountSegmentClosingBalance> data, List<String> segments1,
			List<String> segments2) {
		return data.stream().filter(s -> segments1.contains(s.getAccountSegmentClosingBalanceId().getSegment1()))
				.filter(s -> segments2.contains(s.getAccountSegmentClosingBalanceId().getSegment2()))
				.mapToDouble(d -> d.getTotalBalance().doubleValue()).sum();
	}

	private double segment1ButNotSegment2Balance(List<AccountSegmentClosingBalance> data, List<String> segments1,
			List<String> segments2) {
		return data.stream().filter(s -> segments1.contains(s.getAccountSegmentClosingBalanceId().getSegment1()))
				.filter(s -> !segments2.contains(s.getAccountSegmentClosingBalanceId().getSegment2()))
				.mapToDouble(d -> d.getTotalBalance().doubleValue()).sum();
	}

	private AssetsLiabilitesMaturityClassificationReportingData reportingData(LocalDate reportingDate) {
		var accounts = getClosingBalanceForAccounts(reportingDate);
		var totalBookValueByResidualMaturity = residualMaturityCOMRepository
				.getTotalBookValueResidualMaturityByResidencyAndReference(reportingDate.format(ISO_DATE), NCD.getCode(),
						CALL_DEPOSIT.getCode(), TERM_DEPOSIT.getCode(), MBILL.getCode());
		var accountSegmentClosingBalances = accountSegmentClosingBalanceRepository
				.getTotalBalanceWithSegment(reportingDate);

		log.info("Fetched Residual Maturity {} Banks' Products Records", totalBookValueByResidualMaturity.size());
		log.info("Reporting Date : {}", reportingDate.format(ISO_DATE));
		log.debug(Arrays.deepToString(totalBookValueByResidualMaturity.toArray()));

		return AssetsLiabilitesMaturityClassificationReportingData.builder()
				.cashReserveBalance(closingBalance(accounts,
						assetsLiabilitesMaturityClassificationBrf11Config.getCashReserveBalance()))
				.federalGovernmentDebtSecurities(residualMaturity(totalBookValueByResidualMaturity,
						assetsLiabilitesMaturityClassificationBrf11Config.getFederalGovernmentDebtSecurities()))
				.placementHeldResidentBank(residualMaturityForcountry(totalBookValueByResidualMaturity,
						assetsLiabilitesMaturityClassificationBrf11Config.getPlacementHeldResidentBank(),
						UNITED_ARAB_EMIRATES, true))
				.placementHeldOverseaBank(residualMaturityForcountry(totalBookValueByResidualMaturity,
						assetsLiabilitesMaturityClassificationBrf11Config.getPlacementHeldOverseaBank(),
						UNITED_ARAB_EMIRATES, false))
				.interbankCDsHeld(residualMaturityForcountry(totalBookValueByResidualMaturity,
						assetsLiabilitesMaturityClassificationBrf11Config.getInterbankCDsHeld(), UNITED_ARAB_EMIRATES,
						false))
				.netFixedAssets(
						closingBalance(accounts, assetsLiabilitesMaturityClassificationBrf11Config.getNetFixedAssets()))
				.otherAssets(
						closingBalance(accounts, assetsLiabilitesMaturityClassificationBrf11Config.getOtherAssets()))
				.govPubDeposit(segment1Balance(accountSegmentClosingBalances,
						assetsLiabilitesMaturityClassificationBrf11Config.getGovPubDeposit().getSegments1()))
				.greDeposit(segment1Balance(accountSegmentClosingBalances,
						assetsLiabilitesMaturityClassificationBrf11Config.getGreDeposit().getSegments1()))
				.privSecDeposit(segment1Balance(accountSegmentClosingBalances,
						assetsLiabilitesMaturityClassificationBrf11Config.getPrivSecDeposit().getSegments1()))
				.nbfiDeposit(segment1Balance(accountSegmentClosingBalances,
						assetsLiabilitesMaturityClassificationBrf11Config.getNbfiDeposit().getSegments1()))
				.hniMoreThan20AED(segment1ButNotSegment2Balance(accountSegmentClosingBalances,
						assetsLiabilitesMaturityClassificationBrf11Config.getHniMoreThan20AED().getSegments1(),
						assetsLiabilitesMaturityClassificationBrf11Config.getHniMoreThan20AED().getSegments2()))
				.hniUpto20AED1(segment1AndSegment2Balance(accountSegmentClosingBalances,
						assetsLiabilitesMaturityClassificationBrf11Config.getHniUpto20AED1().getSegments1(),
						assetsLiabilitesMaturityClassificationBrf11Config.getHniUpto20AED1().getSegments2()))
				.hniUpto20AED2(segment1Balance(accountSegmentClosingBalances,
						assetsLiabilitesMaturityClassificationBrf11Config.getHniUpto20AED2().getSegments1()))

				.capitalAndReserves(closingBalance(accounts,
						assetsLiabilitesMaturityClassificationBrf11Config.getCapitalAndReserves()))
				.build();
	}

}
