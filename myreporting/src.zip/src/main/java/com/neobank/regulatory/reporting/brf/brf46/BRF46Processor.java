package com.neobank.regulatory.reporting.brf.brf46;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.BookValuePerProduct;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.repository.TreasuryProductRepository;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import static com.neobank.regulatory.reporting.model.InvestmentProduct.MBILL;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_46;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component
public class BRF46Processor extends AbstractBRFProcessor {

    private static final String F21 = "F21";

    private final BRF46Transformer brf46Transformer;

    private final TreasuryProductRepository investmentRepository;

    public BRF46Processor(BRF46Transformer brf46Transformer, TreasuryProductRepository investmentRepository) {
        this.brf46Transformer = brf46Transformer;
        this.investmentRepository = investmentRepository;

    }

    @Override
    public String getBrfId() {
        return BRF + BRF_46;
    }

    @Override
    public BRFTransformer<BookValuePerProduct> getBrfTransformer() {
        return brf46Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return investmentRepository;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.info("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();
        var bookValuePerProduct = investmentRepository
                .getSumOfBookValueForInvestmentsByProductOnDate(reportingDate.format(ISO_DATE), MBILL.getCode());
        log.debug("Fetched Treasury Investments: {}", bookValuePerProduct);
        updateSheet(wb.getSheetAt(0), bookValuePerProduct);
        log.info("{} generated successfully.", getBrfId());
    }

    private void updateSheet(Sheet sheet, BookValuePerProduct bookValuePerProduct) {

        if (bookValuePerProduct == null) {
            return;
        }
        var bookValue = NumberUtils.roundOffValue(bookValuePerProduct.getBookValue());
        getCell(sheet, F21).setCellValue(bookValue);
    }

}
