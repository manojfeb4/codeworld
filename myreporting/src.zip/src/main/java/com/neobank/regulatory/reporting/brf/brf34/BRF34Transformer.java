package com.neobank.regulatory.reporting.brf.brf34;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.TreasuryInvestment;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BRF34Transformer implements BRFTransformer<TreasuryInvestment> {

    @Override
    public void transform(Sheet sheet, List<TreasuryInvestment> dataset) {
        throw new UnsupportedOperationException();
    }

}
