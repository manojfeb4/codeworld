package com.neobank.regulatory.reporting.model;

import lombok.Data;

import java.util.List;

@Data
public class LiquidAssetsRatioQueryKey {

    private List<String> accounts;

    private List<String> products;

    private List<String> issueRatings;

}
