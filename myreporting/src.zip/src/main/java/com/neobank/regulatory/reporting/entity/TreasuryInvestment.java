package com.neobank.regulatory.reporting.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "TREASURY_REG_REPORT_DATAMART")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TreasuryInvestment {

    @Id
    @Column(name = "ISIN")
    @NotNull
    private String isin;

    @Column(name = "INSTRUMENT_CLASS")
    private String instrumentClass;

    @Column(name = "PRODUCT_NAME")
    private String product;

    @Column(name = "ISSUER_NAME")
    private String issuerName;

    @Column(name = "ISSUE_RATING")
    private String issueRating;

    @Column(name = "CURRENCY_DESCRIPTION")
    private String currencyDescription;

    @Column(name = "PORTFOLIO_NAME")
    private String portfolioName;

    @Column(name = "FACE_VALUE")
    private double faceValue;

    @Column(name = "MARKET_VALUE")
    private double marketValue;

    @Column(name = "COUNTERPARTY_NAME")
    private String counterpartyName;

    @Column(name = "BOOK_VALUE")
    @NotNull
    private double bookValue;

    @Column(name = "BANK_NAME")
    private String bankName;

    @Column(name = "COUNTERPARTY_TYPE")
    private String counterpartyType;

    @Column(name = "COUNTRY_OF_BRANCH")
    private String countryOfBranch;

    @Column(name = "COUNTRY_OF_HEAD_OFFICE")
    private String countryOfHeadOffice;

    @Column(name = "DATE")
    private String date;

    @Column(name = "END_DATE")
    private String endDate;

    @Column(name = "RATE_SET_FREQUENCY_DESCRIPTION")
    private String rateSetFrequencyDescription;

    @Column(name = "REFERENCE_RATE_DESCRIPTION")
    private String referenceRateDescription;

    public TreasuryInvestment(String isin, double bookValue, String productName) {
        this.isin = isin;
        this.bookValue = bookValue;
        this.product = productName;
    }

}
