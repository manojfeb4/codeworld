package com.neobank.regulatory.reporting.model;

import lombok.Data;

import java.util.List;

@Data
public class TransferPurposeQueryKey {

    private List<String> transferPurpose;


}
