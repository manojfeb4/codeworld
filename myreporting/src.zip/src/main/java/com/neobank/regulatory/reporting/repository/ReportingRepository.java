package com.neobank.regulatory.reporting.repository;

public interface ReportingRepository {

}
