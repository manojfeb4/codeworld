package com.neobank.regulatory.reporting.model;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum RemittanceType {
    FAMILY_MAINTENANCE("Family maintenance"),
    FAMILY_EDUCATION("Education related expenses for family"),
    GIFT_TO_FRIENDS("Payments to friends"),
    OTHER_PERSONAL_EXPENSE("Other personal expenses"),
    FAMILY_MEDICAL("Medical treatment for family"),
    PROPERTY_PURCHASE("Property purchase"), EMPLOYEE_COMPENSATION("Compensation for employees"),
    SAVINGS("Savings"), NRE_DEPOSIT("Deposit to Non-Resident Rupee (NRE) accounts"),
    INTEREST_ON_LOAN("Interest on loan");

    private final String type;


}