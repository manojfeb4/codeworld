package com.neobank.regulatory.reporting.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "ACCOUNT_BALANCE_DETAILS")
@Data
public class AnalyticsAccountInfo {

    @EmbeddedId
    private AnalyticsAccountId analyticsAccountId;

    @Column(name = "BUSINESS_ID")
    private String businessId;

    @Column(name = "DEPOSIT_ACCOUNT_NAME")
    private String depositAccountName;

    @Column(name = "ACCOUNT_BALANCE")
    private Float accountBalance;

    @Column(name = "COUNTRY_OF_INCORPORATION")
    private String countryOfIncorporation;

    @Column(name = "EOD_DATE")
    private String eodDate;

    @Column(name = "COMPANY_LEGAL_FORM")
    private String companyLegalForm;

    @Column(name = "ACCOUNT_STATE")
    private String accountState;

    @Column(name = "AVG_BAL_CURNT_MNTH")
    private String averageBalanceCurrentMonth;

    @Column(name = "LOADED_BY")
    private String loadedBy;

}