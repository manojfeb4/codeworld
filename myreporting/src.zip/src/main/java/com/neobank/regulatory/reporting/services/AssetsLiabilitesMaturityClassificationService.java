package com.neobank.regulatory.reporting.services;

import com.neobank.regulatory.reporting.entity.ResidualMaturityCOBInfo;
import com.neobank.regulatory.reporting.model.AssetsLiabilitesMaturityClassificationQueryKey;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AssetsLiabilitesMaturityClassificationService {
    private static final char BUCKETSTART = 'F';
    private static final char REFBUCKETSTART = 'E';

    public Map<String, Double> residualMaturity(List<ResidualMaturityCOBInfo> maturities,
                                                AssetsLiabilitesMaturityClassificationQueryKey queryKey) {
        Map<String, Double> aMap = new HashMap<>();
        maturities.stream().filter(c -> forProduct(c, queryKey)).forEach(c -> updateCell(c, aMap, BUCKETSTART));
        return aMap;
    }

    public Map<String, Double> residualMaturityWithReference(List<ResidualMaturityCOBInfo> maturities,
                                                             AssetsLiabilitesMaturityClassificationQueryKey queryKey) {
        Map<String, Double> aMap = new HashMap<>();
        maturities.stream().filter(c -> forProduct(c, queryKey)).forEach(c -> updateCell(c, aMap, REFBUCKETSTART));
        return aMap;
    }

    public Map<String, Double> residualMaturityForCountry(List<ResidualMaturityCOBInfo> maturities,
                                                          AssetsLiabilitesMaturityClassificationQueryKey queryKey, String countryOfBranch) {
        Map<String, Double> aMap = new HashMap<>();
        maturities.stream().filter(c -> residentProducts(c, countryOfBranch)).filter(c -> forProduct(c, queryKey))
                .forEach(c -> updateCell(c, aMap, BUCKETSTART));
        return aMap;
    }

    public Map<String, Double> residualMaturityNotForCountry(List<ResidualMaturityCOBInfo> maturities,
                                                             AssetsLiabilitesMaturityClassificationQueryKey queryKey, String countryOfBranch) {
        Map<String, Double> aMap = new HashMap<>();
        maturities.stream().filter(c -> !residentProducts(c, countryOfBranch)).filter(c -> forProduct(c, queryKey))
                .forEach(c -> updateCell(c, aMap, BUCKETSTART));

        return aMap;
    }

    private boolean forProduct(ResidualMaturityCOBInfo c, AssetsLiabilitesMaturityClassificationQueryKey queryKey) {
        return queryKey.getProducts().contains(c.getResidualMaturityCOBId().getProduct());
    }

    private boolean residentProducts(ResidualMaturityCOBInfo c, String countryOfBranch) {
        return c.getResidualMaturityCOBId().getCountryOfBranch().equalsIgnoreCase(countryOfBranch);
    }

    private boolean residentProducts(ResidualMaturityCOBInfo c, String countryOfBranch, boolean resident) {
        var result = c.getResidualMaturityCOBId().getCountryOfBranch().equalsIgnoreCase(countryOfBranch);
        if (!resident) {
            result = !result;
        }
        return result;
    }

    private void updateCell(ResidualMaturityCOBInfo c, Map<String, Double> aMap, char cellRef) {
        var cell = bucketCell(c.getResidualMaturityCOBId().getBucket(), cellRef);
        var value = c.getTotalBookValue();
        if (aMap.containsKey(cell)) {
            value = aMap.get(cell);
        }
        aMap.put(cell, value);
    }

    private String bucketCell(int bucket, char cellRef) {
        return "" + (char) (cellRef + bucket);
    }

    public Map<String, Double> residualMaturityWithReferenceAndCountry(List<ResidualMaturityCOBInfo> maturities,
                                                                       AssetsLiabilitesMaturityClassificationQueryKey queryKey, String countryOfBranch, boolean resident) {
        Map<String, Double> aMap = new HashMap<>();
        maturities.stream().filter(c -> residentProducts(c, countryOfBranch, resident))
                .filter(c -> forProduct(c, queryKey)).forEach(c -> updateCell(c, aMap, REFBUCKETSTART));
        return aMap;
    }

}
