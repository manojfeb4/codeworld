package com.neobank.regulatory.reporting.brf.brf60;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.config.BanksOwnedFundAccountsConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import com.neobank.regulatory.reporting.model.InvestmentLimitReportingData;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.ProductBookValueRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static com.neobank.regulatory.reporting.model.InvestmentProduct.MBILL;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_60;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component
public class BRF60Processor extends AbstractBRFProcessor {

    private final BRF60Transformer brf60Transformer;

    private final AccountClosingBalanceRepository accountClosingBalanceRepository;

    private final BanksOwnedFundAccountsConfig banksOwnedFundAccountsConfig;


    private final AccountsClosingBalanceService accountsClosingBalanceService;

    private final ProductBookValueRepository productBookValueRepository;

    public BRF60Processor(BRF60Transformer brf60Transformer,
                          AccountClosingBalanceRepository accountClosingBalanceRepository,

                          ProductBookValueRepository productBookValueRepository,
                          BanksOwnedFundAccountsConfig banksOwnedFundAccountsConfig,

                          AccountsClosingBalanceService accountsClosingBalanceService
    ) {
        this.brf60Transformer = brf60Transformer;
        this.accountClosingBalanceRepository = accountClosingBalanceRepository;

        this.productBookValueRepository = productBookValueRepository;
        this.banksOwnedFundAccountsConfig = banksOwnedFundAccountsConfig;

        this.accountsClosingBalanceService = accountsClosingBalanceService;

    }

    @Override
    public String getBrfId() {
        return BRF + BRF_60;
    }

    @Override
    public BRFTransformer<InvestmentLimitReportingData> getBrfTransformer() {
        return brf60Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return null;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();
        setQuarterlyDefaultCells(wb, payloadData);
        var investmentLimitReportingData = List.of(investmentLimitReportingData(reportingDate));
        log.debug("InvestmentLimitReporting: " + Arrays.deepToString(investmentLimitReportingData.toArray()));
        brf60Transformer.transform(wb.getSheetAt(0), investmentLimitReportingData);

        log.info("{} generated successfully.", getBrfId());
    }

    private List<AccountClosingBalance> getClosingBalanceForAccounts(LocalDate reportingDate) {
        return accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(reportingDate);
    }

    private long closingBalanceCount(List<AccountClosingBalance> accounts, ClosingBalanceQueryKey queryKey) {
        return accountsClosingBalanceService.closingBalanceCount(accounts, queryKey);
    }

    private double closingBalance(List<AccountClosingBalance> accounts, ClosingBalanceQueryKey queryKey) {
        return NumberUtils.roundOffValue(accountsClosingBalanceService.closingBalance(accounts, queryKey));
    }

    private InvestmentLimitReportingData investmentLimitReportingData(LocalDate reportingDate) {
        var accounts = getClosingBalanceForAccounts(reportingDate);
        var productBookValues = productBookValueRepository
                .getCountAndTotalBookValueByProduct(reportingDate.format(ISO_DATE), MBILL.getCode());
        var numOfDebtSecuritities = !(productBookValues.isEmpty()) ? productBookValues.get(0).getNumOfProducts() : 0;
        var totalBookValueOfDebtSecurities = NumberUtils.roundOffValue(
                !(productBookValues.isEmpty()) ? productBookValues.get(0).getTotalBookValue().doubleValue() : 0);
        log.debug("accounts: " + Arrays.deepToString(accounts.toArray()));
        log.debug("productBookValues: " + Arrays.deepToString(productBookValues.toArray()));
        return InvestmentLimitReportingData.builder()
                .numOfDebtSecurities(numOfDebtSecuritities)
                .totalBookValueOfDebtSecurities(totalBookValueOfDebtSecurities)
                .numOfBankOwnedFunds(closingBalanceCount(accounts, banksOwnedFundAccountsConfig.getBanksOwnedFundBalanceKeys()))
                .totalBalanceOfBankOwnedFunds(closingBalance(accounts, banksOwnedFundAccountsConfig.getBanksOwnedFundBalanceKeys()))
                .build();
    }

}
