package com.neobank.regulatory.reporting.config;

import com.neobank.common.config.YamlPropertySourceFactory;
import com.neobank.regulatory.reporting.model.BookValueQueryKey;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Data
@Configuration
@ConfigurationProperties(prefix = "book-value")
@PropertySource(value = "classpath:mapping/products-book-value.yml", factory = YamlPropertySourceFactory.class)
public class ProductsBookValueConfig {

    /**
     * Money at call and short notice, placements on demand and remaining balances
     * held with other resident banks
     */
    private BookValueQueryKey callAccountBookValue;
    /**
     * Interbank placements with other resident banks
     */
    private BookValueQueryKey interbankPlacements;
    /**
     * Assets Held to Maturity (M-Bills) in AED ('000)
     */
    private BookValueQueryKey assetsHeldMBills;
}
