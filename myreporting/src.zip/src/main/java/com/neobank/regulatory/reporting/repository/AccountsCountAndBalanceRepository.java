package com.neobank.regulatory.reporting.repository;

import com.neobank.regulatory.reporting.entity.AccountsCountAndBalance;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface AccountsCountAndBalanceRepository extends CrudRepository<AccountsCountAndBalance, String>, ReportingRepository {

    @Query(nativeQuery = true)
    public List<AccountsCountAndBalance> getCountsAndTotalBalanceByAccountType(LocalDate reportingDate);
}
