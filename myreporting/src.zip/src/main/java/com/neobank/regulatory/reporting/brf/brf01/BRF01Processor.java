package com.neobank.regulatory.reporting.brf.brf01;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.config.AccountsClosingBalanceConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.model.AccountsReportingData;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_01;

@Slf4j
@Component
public class BRF01Processor extends AbstractBRFProcessor {

    private final BRF01Transformer brf01Transformer;

    private final AccountClosingBalanceRepository accountClosingBalanceRepository;

    private final AccountsClosingBalanceConfig accountsClosingBalanceConfig;

    private final AccountsClosingBalanceService accountsClosingBalanceService;

    public BRF01Processor(BRF01Transformer brf01Transformer,
                          AccountClosingBalanceRepository accountClosingBalanceRepository,
                          AccountsClosingBalanceConfig accountsClosingBalanceConfig,
                          AccountsClosingBalanceService accountsClosingBalanceService) {
        this.brf01Transformer = brf01Transformer;
        this.accountClosingBalanceRepository = accountClosingBalanceRepository;
        this.accountsClosingBalanceConfig = accountsClosingBalanceConfig;
        this.accountsClosingBalanceService = accountsClosingBalanceService;
    }

    @Override
    public String getBrfId() {
        return BRF + BRF_01;
    }

    @Override
    public BRFTransformer<AccountsReportingData> getBrfTransformer() {
        return brf01Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return null;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();

        brf01Transformer.transform(wb.getSheetAt(0), List.of(reportingData(reportingDate)));

        log.info("{} generated successfully.", getBrfId());
    }

    private List<AccountClosingBalance> getClosingBalanceForAccounts(LocalDate reportingDate) {
        return accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(reportingDate);
    }

    private double closingBalance(List<AccountClosingBalance> accounts, ClosingBalanceQueryKey queryKey) {
        return NumberUtils.roundOffValue(accountsClosingBalanceService.closingBalance(accounts, queryKey));

    }

    private AccountsReportingData reportingData(LocalDate reportingDate) {
        var accounts = getClosingBalanceForAccounts(reportingDate);
        log.debug("accounts: " + Arrays.deepToString(accounts.toArray()));
        var accountReportingData = AccountsReportingData.builder()
                .cashInHand(closingBalance(accounts, accountsClosingBalanceConfig.getCashInHand()))
                .reserveHeldCB(closingBalance(accounts, accountsClosingBalanceConfig.getReserveHeldCB()))
                .otherBalances(closingBalance(accounts, accountsClosingBalanceConfig.getOtherBalances()))
                .repoedToUAECB(closingBalance(accounts, accountsClosingBalanceConfig.getReportedToUAECB()))
                .overseasBRNB(closingBalance(accounts, accountsClosingBalanceConfig.getOverseasBRNB()))
                .callAccountBookValue(closingBalance(accounts, accountsClosingBalanceConfig.getCallAccountBookValue()))
                .interbankPlacements(closingBalance(accounts, accountsClosingBalanceConfig.getInterbankPlacements()))
                .otherTermPlacements(closingBalance(accounts, accountsClosingBalanceConfig.getOtherTermPlacements()))
                .lendingCoveredRepurchaseAgreements(
                        closingBalance(accounts, accountsClosingBalanceConfig.getLendingCoveredRepurchaseAgreements()))
                .debtSecurities1(closingBalance(accounts, accountsClosingBalanceConfig.getDebtSecurities1()))
                .equities1(closingBalance(accounts, accountsClosingBalanceConfig.getEquities1()))
                .debtSecurities2(closingBalance(accounts, accountsClosingBalanceConfig.getDebtSecurities2()))
                .equities2(closingBalance(accounts, accountsClosingBalanceConfig.getEquities2()))
                .assetsHeldMBills(closingBalance(accounts, accountsClosingBalanceConfig.getAssetsHeldMBills()))
                .investmentSubsidiaries(
                        closingBalance(accounts, accountsClosingBalanceConfig.getInvestmentSubsidiaries()))
                .investmentAffiliates(closingBalance(accounts, accountsClosingBalanceConfig.getInvestmentAffiliates()))
                .netFixedAsset1(closingBalance(accounts, accountsClosingBalanceConfig.getNetFixedAsset1()))
                .netFixedAsset2(closingBalance(accounts, accountsClosingBalanceConfig.getNetFixedAsset2()))
                .capitalWorkInProgress(
                        closingBalance(accounts, accountsClosingBalanceConfig.getCapitalWorkInProgress()))
                .interestReceivable1(closingBalance(accounts, accountsClosingBalanceConfig.getInterestReceivable1()))
                .prepaidExpenses(closingBalance(accounts, accountsClosingBalanceConfig.getPrepaidExpenses()))
                .interestReceivable2(closingBalance(accounts, accountsClosingBalanceConfig.getInterestReceivable2()))
                .dividendReceivable(closingBalance(accounts, accountsClosingBalanceConfig.getDividendReceivable()))
                .marketValueForwardContacts(
                        closingBalance(accounts, accountsClosingBalanceConfig.getMarketValueForwardContacts()))
                .marketValueFinancialFutures(
                        closingBalance(accounts, accountsClosingBalanceConfig.getMarketValueFinancialFutures()))
                .marketValueCreditDerivatives(
                        closingBalance(accounts, accountsClosingBalanceConfig.getMarketValueCreditDerivatives()))
                .build();
        log.debug("accountReportingData: " + accountReportingData);
        return accountReportingData;
    }

}
