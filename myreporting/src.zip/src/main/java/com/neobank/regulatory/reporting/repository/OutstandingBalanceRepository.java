package com.neobank.regulatory.reporting.repository;

import com.neobank.regulatory.reporting.entity.OutstandingBalanceId;
import com.neobank.regulatory.reporting.entity.OutstandingBalanceInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OutstandingBalanceRepository
        extends CrudRepository<OutstandingBalanceInfo, OutstandingBalanceId>, ReportingRepository {

    @Query(nativeQuery = true)
    List<OutstandingBalanceInfo> getSizeWiseDepositsSameNation(String reportingDate);

    @Query(nativeQuery = true)
    List<OutstandingBalanceInfo> getSizeWiseDepositsOtherNation(String reportingDate);

}
