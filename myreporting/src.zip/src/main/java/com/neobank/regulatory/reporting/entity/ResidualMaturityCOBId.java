package com.neobank.regulatory.reporting.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;


/**
 * Residual Maturity Id with Country of Branch
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class ResidualMaturityCOBId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "PRODUCT")
    private String product;

    @Column(name = "BUCKET")
    private int bucket;

    @Column(name = "COUNTRY_OF_BRANCH")
    private String countryOfBranch;

}
