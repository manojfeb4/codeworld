package com.neobank.regulatory.reporting.brf.brf38;

import com.neobank.ods.schema.enums.Country;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.RemittanceInfo;
import com.neobank.regulatory.reporting.model.RemittanceCountries;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class BRF38Transformer implements BRFTransformer<RemittanceInfo> {
    private static final List<String> transferPurposeList = List.of("Family", "Investment", "Trade", "Other");


    public void transform(Sheet sheet, List<RemittanceInfo> remittanceInfoList) {


        var remittanceCountriesList = EnumSet.allOf(RemittanceCountries.class)
                .stream()
                .map(RemittanceCountries::getCountryName)
                .collect(Collectors.toList());


        remittanceInfoList.stream().forEach(remittanceInfo -> {
                    var startRow = 9;
                    var startCol = 3;
                    var dRow = 0;
                    var dCol = 0;
                    var countryIndex = -1;
                    var transferPurpose = remittanceInfo.getRemittanceId().getTransferPurpose();
                    var totalTransferredAmount = remittanceInfo.getTotalTransferredAmount();
                    var recipientCountryCode = remittanceInfo.getRemittanceId().getRecipientCountry();
                    log.debug("transferPurpose: {}, recipientCountry: {}", transferPurpose, recipientCountryCode);
                    var recipientCountryIso2 = Country.getEnumByCountryIso2(recipientCountryCode);
                    if (recipientCountryIso2 != null) {
                        var recipientCountryValue = recipientCountryIso2.getCountryName();
                        countryIndex = remittanceCountriesList.indexOf(recipientCountryValue);
                        log.debug("recipientCountryValue: {}", recipientCountryValue);
                    }


                    dRow = countryIndex >= 0 ? (startRow + countryIndex) : (startRow + remittanceCountriesList.size() + 1);
                    dCol = startCol + transferPurposeList.indexOf(transferPurpose);


                    log.debug("totalTransferredAmount: {}, row: {}, col: {}",
                            totalTransferredAmount, dRow, dCol);


                    getCell(sheet, dRow, dCol).setCellValue(NumberUtils.roundOffValue(totalTransferredAmount));
                }


        );

    }

}
