package com.neobank.regulatory.reporting.brf.services;

import com.neobank.regulatory.reporting.model.BankDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Component
@Slf4j
public class GTreasuryService {

    public Map<String, Map<String, Double>> getTotalBookValueGroupByBankAndProduct(List<String[]> investments,
                                                                                   Predicate<String> filter) {
        if (investments.isEmpty()) {
            return Collections.emptyMap();
        }
        return investments.stream().filter(s -> filter.test(s[0]))
                .collect(Collectors.groupingBy(s -> s[1],
                        Collectors.groupingBy(s -> s[2], Collectors.summingDouble(s -> Double.parseDouble(s[3])))));
    }

    public Map<BankDetails, Map<String, Double>> getTotalBookValueForBankAndProducts(
            List<String[]> bankAndProductByBranchAndHeaderOfficeCountry) {
        return bankAndProductByBranchAndHeaderOfficeCountry.stream()
                .collect(Collectors.groupingBy(s -> new BankDetails(s[0], s[1], s[2]),
                        Collectors.groupingBy(s -> s[3], Collectors.summingDouble(s -> Double.parseDouble(s[4])))));

    }


}
