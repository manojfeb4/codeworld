package com.neobank.regulatory.reporting.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountsCountAndBalance {

    @Id
    @Column(name = "ACCOUNT_TYPE")
    private String accountType;

    @Column(name = "COUNTS")
    private long totalCounts;

    @Column(name = "TOTAL_BALANCE")
    private double totalBalance;

}
