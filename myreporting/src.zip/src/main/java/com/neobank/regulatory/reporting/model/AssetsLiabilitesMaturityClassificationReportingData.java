package com.neobank.regulatory.reporting.model;

import lombok.Builder;
import lombok.Data;

import java.util.Map;

@Data
@Builder
public class AssetsLiabilitesMaturityClassificationReportingData {

    private double cashReserveBalance;

    private Map<String, Double> federalGovernmentDebtSecurities;

    private Map<String, Double> placementHeldResidentBank;

    private Map<String, Double> interbankCDsHeld;

    private Map<String, Double> placementHeldOverseaBank;

    private double netFixedAssets;

    private double otherAssets;

    private double govPubDeposit;

    private double greDeposit;

    private double privSecDeposit;

    private double nbfiDeposit;

    private double hniMoreThan20AED;

    private double hniUpto20AED1;

    private double hniUpto20AED2;

    private double capitalAndReserves;

}
