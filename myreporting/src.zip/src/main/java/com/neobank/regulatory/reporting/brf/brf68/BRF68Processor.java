package com.neobank.regulatory.reporting.brf.brf68;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.EmirateDepositInfo;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.EmirateDepositRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

import static com.neobank.ods.schema.enums.Emirate.*;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_68;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component
@AllArgsConstructor
public class BRF68Processor extends AbstractBRFProcessor {


    private final BRF68Transformer brf68Transformer;

    private final EmirateDepositRepository emirateDepositRepository;


    @Override
    public String getBrfId() {
        return BRF + BRF_68;
    }

    @Override
    public BRFTransformer<EmirateDepositInfo> getBrfTransformer() {
        return brf68Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return emirateDepositRepository;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();
        var registeredEmirateAddressList = List.of(DUBAI.getValue(), ABU_DHABI.getValue(), SHARJAH.getValue(),
                AJMAN.getValue(), RAS_AL_KHAIMAH.getValue(), UMM_AL_QUWAIN.getValue(), FUJAIRAH.getValue());

        var emirateDepositInfoList =
                emirateDepositRepository.getEmirateWiseDeposits(
                        reportingDate.format(ISO_DATE), registeredEmirateAddressList);

        log.info("Fetched Total {} Records", emirateDepositInfoList.size());
        log.info("Reporting Date : {}", reportingDate.format(ISO_DATE));
        log.debug(Arrays.deepToString(emirateDepositInfoList.toArray()));
        brf68Transformer.transform(wb.getSheetAt(0), emirateDepositInfoList);


        log.info("{} generated successfully.", getBrfId());
    }


}
