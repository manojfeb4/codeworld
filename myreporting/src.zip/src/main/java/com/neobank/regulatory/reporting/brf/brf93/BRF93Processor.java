package com.neobank.regulatory.reporting.brf.brf93;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.config.ClientSegmentConfig;
import com.neobank.regulatory.reporting.config.PaymentTransferPurposeConfig;
import com.neobank.regulatory.reporting.entity.InternationalPaymentInfo;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.InternationalPaymentRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.temporal.IsoFields;
import java.time.temporal.TemporalAdjuster;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_93;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component
public class BRF93Processor extends AbstractBRFProcessor {

    private final PaymentTransferPurposeConfig paymentTransferPurposeConfig;
    private final ClientSegmentConfig clientSegmentConfig;
    private final BRF93Transformer brf93Transformer;
    private final InternationalPaymentRepository internationalPaymentRepository;
    List<String> directInvestmentList;
    List<String> financialInvestmentList;
    List<String> individualSupportList;
    List<String> individualEducationList;
    List<String> individualMedicalList;
    List<String> servicesList;
    List<String> govtClientSegments;
    List<String> corporateClientSegments;
    List<String> greClientSegments;
    List<String> smeClientSegments;
    List<String> individualClientSegments;

    public BRF93Processor(BRF93Transformer brf93Transformer,
                          PaymentTransferPurposeConfig paymentTransferPurposeConfig,
                          ClientSegmentConfig clientSegmentConfig,
                          InternationalPaymentRepository internationalPaymentRepository) {
        this.brf93Transformer = brf93Transformer;
        this.paymentTransferPurposeConfig = paymentTransferPurposeConfig;
        this.clientSegmentConfig = clientSegmentConfig;
        this.internationalPaymentRepository = internationalPaymentRepository;
    }

    @Override
    public String getBrfId() {
        return BRF + BRF_93;
    }

    @Override
    public BRFTransformer<InternationalPaymentInfo> getBrfTransformer() {
        return brf93Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return null;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingToDate = payloadData.getReportingToDate();


        brf93Transformer.transform(wb.getSheetAt(0), getPaymentReportingData(reportingToDate));


        log.info("{} generated successfully.", getBrfId());
    }

    private void getConfigValues() {
        directInvestmentList = paymentTransferPurposeConfig.getDirectInvestmentKeys().getTransferPurpose();
        financialInvestmentList = paymentTransferPurposeConfig.getFinancialInvestmentKeys().getTransferPurpose();
        servicesList = paymentTransferPurposeConfig.getServicesKeys().getTransferPurpose();
        individualSupportList = paymentTransferPurposeConfig.getIndividualSupportKeys().getTransferPurpose();
        individualEducationList = paymentTransferPurposeConfig.getIndividualEducationKeys().getTransferPurpose();
        individualMedicalList = paymentTransferPurposeConfig.getIndividualMedicalKeys().getTransferPurpose();

        govtClientSegments = clientSegmentConfig.getPaymentGovtKeys().getClientSegments();
        corporateClientSegments = clientSegmentConfig.getPaymentCorporateKeys().getClientSegments();
        greClientSegments = clientSegmentConfig.getPaymentGreKeys().getClientSegments();
        smeClientSegments = clientSegmentConfig.getPaymentSmeKeys().getClientSegments();
        individualClientSegments = clientSegmentConfig.getPaymentIndividualKeys().getClientSegments();
        log.debug("Client Segment Config : {} ", Arrays.deepToString(govtClientSegments.toArray()));
        log.debug("Transfer Purpose Config : {} ", Arrays.deepToString(directInvestmentList.toArray()));
    }

    private List<InternationalPaymentInfo> getPaymentInfoByClientSegment(
            LocalDate reportingFromDate,
            LocalDate reportingToDate,
            List<String> clientSegments) {

        clientSegments.add("XXXXX");
        return internationalPaymentRepository
                .getPaymentsByCountryAndClientSegments(reportingFromDate.format(ISO_DATE),
                        reportingToDate.format(ISO_DATE),
                        individualSupportList,
                        individualEducationList, individualMedicalList,
                        financialInvestmentList, directInvestmentList,
                        servicesList, clientSegments);


    }


    protected Map<String, List<InternationalPaymentInfo>> getPaymentReportingData(
            LocalDate reportingToDate
    ) {

        var reportingFromDate = reportingToDate.with(IsoFields.DAY_OF_QUARTER, 1L);
        log.info("reporting From Date {}.", reportingFromDate);
        log.info("reporting To Date {}.", reportingToDate);
        getConfigValues();
        var govtPaymentInfo = getPaymentInfoByClientSegment(reportingFromDate, reportingToDate, govtClientSegments);
        Map<String, List<InternationalPaymentInfo>> govtPaymentMap = new HashMap<>();

        govtPaymentMap.put("government", govtPaymentInfo);
        log.debug("Govt Payment Info : {} ", Arrays.deepToString(govtPaymentInfo.toArray()));

        var corporatePaymentInfo = getPaymentInfoByClientSegment(reportingFromDate, reportingToDate, corporateClientSegments);
        Map<String, List<InternationalPaymentInfo>> corporatePaymentMap = new HashMap<>();
        corporatePaymentMap.put("corporate", corporatePaymentInfo);
        log.debug("Corporate Payment Info : {} ", Arrays.deepToString(corporatePaymentInfo.toArray()));

        var grePaymentInfo = getPaymentInfoByClientSegment(reportingFromDate, reportingToDate, greClientSegments);
        Map<String, List<InternationalPaymentInfo>> grePaymentMap = new HashMap<>();
        grePaymentMap.put("gre", grePaymentInfo);
        log.debug("Gre Payment Info : {} ", Arrays.deepToString(grePaymentInfo.toArray()));

        var individualPaymentInfo = getPaymentInfoByClientSegment(reportingFromDate, reportingToDate, individualClientSegments);
        Map<String, List<InternationalPaymentInfo>> individualPaymentMap = new HashMap<>();
        individualPaymentMap.put("individual", individualPaymentInfo);
        log.debug("Individual Payment Info : {} ", Arrays.deepToString(individualPaymentInfo.toArray()));

        var smePaymentInfo = getPaymentInfoByClientSegment(reportingFromDate, reportingToDate, smeClientSegments);
        Map<String, List<InternationalPaymentInfo>> smePaymentMap = new HashMap<>();
        smePaymentMap.put("sme", smePaymentInfo);
        log.debug("Individual Payment Info : {} ", Arrays.deepToString(smePaymentInfo.toArray()));

        return Stream.of(
                        govtPaymentMap, corporatePaymentMap, grePaymentMap, individualPaymentMap, smePaymentMap)
                .flatMap(map -> map.entrySet().stream())
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue));


    }


}
