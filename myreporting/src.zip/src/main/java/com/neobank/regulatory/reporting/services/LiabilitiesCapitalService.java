package com.neobank.regulatory.reporting.services;

import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.model.LiabilitiesCapitalQueryKey;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LiabilitiesCapitalService {

    public double closingBalance(List<AccountClosingBalance> balances, LiabilitiesCapitalQueryKey queryKey) {
        if (ObjectUtils.isNotEmpty(queryKey) && !CollectionUtils.isEmpty(balances)
                && !CollectionUtils.isEmpty(queryKey.getAccounts())) {
            return balances.stream().filter(k -> queryKey.getAccounts().contains(k.getId().getMainAccount()))
                    .mapToDouble(AccountClosingBalance::getClosingBalance).sum();
        }
        return 0.0d;
    }
}
