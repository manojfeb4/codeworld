package com.neobank.regulatory.reporting.controllers;

import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.responses.BankReportingForm;
import com.neobank.regulatory.reporting.services.BRFService;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Api(tags = "BankReportingFormsController")
@RestController
@RequestMapping("/api/v1")
@Slf4j
public class BankReportingFormsController {

    private final BRFService brfService;


    public BankReportingFormsController(BRFService brfService) {
        this.brfService = brfService;


    }


    @ApiOperation(value = "Processes and pushes the Bank Reporting Form to the storage account",
            nickname = "upload-brf", notes = "", tags = {"BankReportingFormsController"})
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Uploaded", response = BankReportingForm.class)})
    @PostMapping(path = "/process/{brfId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> process(
            @ApiParam(example = "033-A",
                    value = "BRF Form ID to be processed") @PathVariable(value = "brfId") String id,
            @ApiParam(value = "Should download the file") @RequestParam(required = false) boolean download,
            @ApiParam(value = "BRF reporting date - To (yyyy-MM-dd)") @RequestParam(required = false) String reportingToDate,
            @ApiParam(value = "BRF reporting date - From (yyyy-MM-dd)") @RequestParam(required = false) String reportingFromDate)
            throws IOException {

        var runToDate = StringUtils.isEmpty(reportingToDate) ? LocalDate.now()
                : LocalDate.parse(reportingToDate, DateTimeFormatter.ISO_DATE);
        var runFromDate = StringUtils.isEmpty(reportingFromDate) ? LocalDate.now()
                : LocalDate.parse(reportingFromDate, DateTimeFormatter.ISO_DATE);
        log.debug("runToDate: {}, runFromDate: {}", runToDate, runFromDate);
        TransformationContext payloadData = new TransformationContext(id, runFromDate, runToDate, "", "");


        File uploadedFile = brfService.processAndUpload(payloadData);
        if (download) {
            return downloadAndReturn(uploadedFile);
        }
        return ResponseEntity.ok().body(BankReportingForm.builder().brfId(id).build());
    }


    private ResponseEntity<Object> downloadAndReturn(File file) throws IOException {


        InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
        HttpHeaders headers = new HttpHeaders();

        headers.add("Content-Disposition", "attachment; filename=" + file.getName());


        return ResponseEntity.ok().contentLength(file.length()).headers(headers)
                .contentType(MediaType.APPLICATION_OCTET_STREAM).body(resource);

    }

}
