package com.neobank.regulatory.reporting.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Data
@Entity
@NoArgsConstructor
public class AverageAccountBalanceInfo {

    @EmbeddedId
    private AverageAccountBalanceId averageAccountBalanceId;

    @Column(name = "TOTAL_BALANCE")
    private double totalBalance;

}
