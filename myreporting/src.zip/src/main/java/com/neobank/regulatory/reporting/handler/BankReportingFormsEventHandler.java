package com.neobank.regulatory.reporting.handler;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.neobank.common.exception.NeobankCustomException;
import com.neobank.regulatory.reporting.model.event.TransformationCompleteEvent;
import com.neobank.regulatory.reporting.services.BRFService;
import io.swagger.annotations.Api;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@Api(tags = "BankReportingFormsController")
@RestController
@Slf4j
@RequiredArgsConstructor
public class BankReportingFormsEventHandler {


    private final BRFService brfService;

    private final ObjectMapper objectMapper;

    @KafkaListener(id = "app-reporting.publish-service-consumer",
            topics = {"${kafka.consumer.reg-reporting-transformation-complete.topic}"},
            groupId = "${kafka.consumer.reg-reporting-transformation-complete.groupId}")
    public void readTransformationCompleteEvent(String transformationCompleteNotification)
            throws IOException {
        log.info("Reading Transformation Complete Event : {}", transformationCompleteNotification);
        try {
            objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
            var transformationCompleteNotificationEvent = objectMapper.readValue(transformationCompleteNotification,
                    TransformationCompleteEvent.class);

            brfService.processAndUpload(transformationCompleteNotificationEvent.getPayload().getData());
        } catch (NeobankCustomException | IOException ex) {
            log.error("Exception occurred while consuming account update notification event ", ex);
            throw ex;
        }
    }


}
