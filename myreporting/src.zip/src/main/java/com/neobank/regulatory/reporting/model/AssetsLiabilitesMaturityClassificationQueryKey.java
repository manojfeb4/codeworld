package com.neobank.regulatory.reporting.model;

import lombok.Data;

import java.util.List;

@Data
public class AssetsLiabilitesMaturityClassificationQueryKey {

    private List<String> accounts;

    private List<String> products;

    private List<String> segments1;

    private List<String> segments2;


}
