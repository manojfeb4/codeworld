package com.neobank.regulatory.reporting.config;

import com.neobank.common.config.YamlPropertySourceFactory;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Data
@Configuration
@ConfigurationProperties(prefix = "income-expense-accounts")
@PropertySource(value = "classpath:mapping/income-expense-accounts.yml", factory = YamlPropertySourceFactory.class)
public class IncomeExpenseAccountsConfig {

    private ClosingBalanceQueryKey personalConsumerLoanKeys;
    private ClosingBalanceQueryKey carLoanKeys;
    private ClosingBalanceQueryKey overdraftKeys;
    private ClosingBalanceQueryKey creditCardLoanKeys;
    private ClosingBalanceQueryKey realEstateHousingLoanKeys;
    private ClosingBalanceQueryKey smallBusinessLoanKeys;

    private ClosingBalanceQueryKey centralBankCdKeys;
    private ClosingBalanceQueryKey interbankInterestIncomeFromKeys;
    private ClosingBalanceQueryKey investmentIncomeKeys;
    private ClosingBalanceQueryKey interestOrProfitIncomeKeys;
    private ClosingBalanceQueryKey privateSectorCorporateKeys;
    private ClosingBalanceQueryKey marginalLendingAndOverdraftKeys;
    private ClosingBalanceQueryKey interbankInterestExpensesPaidToKeys;

    private ClosingBalanceQueryKey capitalMarketOtherBorrowingKeys;
    private ClosingBalanceQueryKey foreignExchangeContractKeys;
    private ClosingBalanceQueryKey derivativeAndFinancialFutureKeys;
    private ClosingBalanceQueryKey otherDerivativeKeys;
    private ClosingBalanceQueryKey otherFeesIncomeKeys;

    private ClosingBalanceQueryKey staffExpenseKeys;
    private ClosingBalanceQueryKey bonusExpenseKeys;
    private ClosingBalanceQueryKey premisesExpenseKeys;
    private ClosingBalanceQueryKey itExpenseKeys;
    private ClosingBalanceQueryKey depreciationAndAmortisationKeys;

    private ClosingBalanceQueryKey otherOutsourcingExpenseKeys;


}
