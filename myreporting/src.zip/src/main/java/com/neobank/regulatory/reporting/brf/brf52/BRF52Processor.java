package com.neobank.regulatory.reporting.brf.brf52;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.config.LiabilitiesCapitalAccountsConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.entity.AccountsCountAndBalance;
import com.neobank.regulatory.reporting.model.LiabilitiesCapitalQueryKey;
import com.neobank.regulatory.reporting.model.LiabilitiesCapitalReportingData;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.AccountsCountAndBalanceRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.services.AccountsCountAndBalanceService;
import com.neobank.regulatory.reporting.services.LiabilitiesCapitalService;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_52;

@Slf4j
@Component
public class BRF52Processor extends AbstractBRFProcessor {

    public static final String REGULAR_SAVINGS = "REGULAR_SAVINGS";

    public static final String CURRENT_ACCOUNT = "CURRENT_ACCOUNT";

    private final BRF52Transformer brf52Transformer;

    private final AccountClosingBalanceRepository accountClosingBalanceRepository;

    private final LiabilitiesCapitalAccountsConfig liabilitiesCapitalAccountsConfig;

    private final LiabilitiesCapitalService liabilitiesCapitalService;

    private final AccountsCountAndBalanceRepository accountsCountAndBalanceRepository;

    private final AccountsCountAndBalanceService accountsCountAndBalanceService;

    public BRF52Processor(BRF52Transformer brf52Transformer,
                          AccountClosingBalanceRepository accountClosingBalanceRepository,
                          LiabilitiesCapitalService liabilitiesCapitalService,
                          LiabilitiesCapitalAccountsConfig liabilitiesCapitalAccountsConfig,
                          AccountsCountAndBalanceRepository accountsCountAndBalanceRepository,
                          AccountsCountAndBalanceService accountsCountAndBalanceService) {
        this.brf52Transformer = brf52Transformer;
        this.accountClosingBalanceRepository = accountClosingBalanceRepository;
        this.liabilitiesCapitalAccountsConfig = liabilitiesCapitalAccountsConfig;
        this.liabilitiesCapitalService = liabilitiesCapitalService;
        this.accountsCountAndBalanceRepository = accountsCountAndBalanceRepository;
        this.accountsCountAndBalanceService = accountsCountAndBalanceService;
    }

    @Override
    public String getBrfId() {
        return BRF + BRF_52;
    }

    @Override
    public BRFTransformer<LiabilitiesCapitalReportingData> getBrfTransformer() {
        return brf52Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return null;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();
        setQuarterlyDefaultCells(wb, payloadData);
        brf52Transformer.transform(wb.getSheetAt(0), List.of(reportingData(reportingDate)));

        log.info("{} generated successfully.", getBrfId());
    }

    private List<AccountClosingBalance> getClosingBalanceForAccounts(LocalDate reportingDate) {
        return accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(reportingDate);
    }

    private List<AccountsCountAndBalance> getCountsAndBalance(LocalDate reportingDate) {
        return accountsCountAndBalanceRepository.getCountsAndTotalBalanceByAccountType(reportingDate);
    }

    private double closingBalance(List<AccountClosingBalance> accounts, LiabilitiesCapitalQueryKey queryKey) {
        return NumberUtils.roundOffValue(liabilitiesCapitalService.closingBalance(accounts, queryKey));
    }

    private long countOfType(List<AccountsCountAndBalance> countAndBalances, String accountType) {
        return accountsCountAndBalanceService.count(countAndBalances, accountType);
    }

    private double totalBalance(List<AccountsCountAndBalance> countAndBalances, String accountType) {
        return NumberUtils.roundOffValue(accountsCountAndBalanceService.balance(countAndBalances, accountType));
    }

    private LiabilitiesCapitalReportingData reportingData(LocalDate reportingDate) {
        var accounts = getClosingBalanceForAccounts(reportingDate);
        var countsAndBalance = getCountsAndBalance(reportingDate);
        return LiabilitiesCapitalReportingData.builder().countOfDemands(countOfType(countsAndBalance, CURRENT_ACCOUNT))
                .demands(totalBalance(countsAndBalance, CURRENT_ACCOUNT))
                .countOfSavings(countOfType(countsAndBalance, REGULAR_SAVINGS))
                .savings(totalBalance(countsAndBalance, REGULAR_SAVINGS))
                .moneyBorrowingRemainingBalance(
                        closingBalance(accounts, liabilitiesCapitalAccountsConfig.getMoneyBorrowingRemainingBalance()))
                .interbankBorrowing(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getInterbankBorrowing()))
                .otherTermBorrowings(
                        closingBalance(accounts, liabilitiesCapitalAccountsConfig.getOtherTermBorrowings()))
                .borrowingUnderRepurchase(
                        closingBalance(accounts, liabilitiesCapitalAccountsConfig.getBorrowingUnderRepurchase()))
                .staffBenefits(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getStaffBenefits()))
                .otherProvisions(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getOtherProvisions()))
                .interestPayable(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getInterestPayable()))
                .incomeTaxLiability(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getIncomeTaxLiability()))
                .accountsPayable(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getAccountsPayable()))
                .acceptances(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getAcceptances()))
                .allOtherBorrowings(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getAllOtherBorrowings()))
                .shareCapital(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getShareCapital()))
                .treasuryShares(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getTreasuryShares()))
                .legalReserves(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getLegalReserves()))
                .otherComprehensiveIncome(
                        closingBalance(accounts, liabilitiesCapitalAccountsConfig.getOtherComprehensiveIncome()))
                .otherReserves(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getOtherReserves()))
                .retainedEarnings(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getRetainedEarnings()))
                .currentYearProfit(closingBalance(accounts, liabilitiesCapitalAccountsConfig.getCurrentYearProfit()))
                .instrumentsPerpetual(
                        closingBalance(accounts, liabilitiesCapitalAccountsConfig.getInstrumentsPerpetual()))
                .build();
    }

}
