package com.neobank.regulatory.reporting.repository;


import com.neobank.regulatory.reporting.entity.EmirateDepositId;
import com.neobank.regulatory.reporting.entity.EmirateDepositInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmirateDepositRepository extends
        CrudRepository<EmirateDepositInfo, EmirateDepositId>, ReportingRepository {


    @Query(nativeQuery = true)
    List<EmirateDepositInfo> getEmirateWiseDeposits(String reportingDate, List<String> registeredAddressEmirate);

}
