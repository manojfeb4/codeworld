package com.neobank.regulatory.reporting.model.event;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.neobank.common.event.model.Header;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransformationCompleteEvent {

    @JsonProperty(value = "Header")
    private Header header;

    @JsonProperty(value = "Payload", required = true)
    private TransformationCompletePayload payload;

}
