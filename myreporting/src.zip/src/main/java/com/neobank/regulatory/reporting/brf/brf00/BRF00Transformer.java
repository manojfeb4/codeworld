package com.neobank.regulatory.reporting.brf.brf00;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.model.CrossBrfValidationReportingData;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class BRF00Transformer implements BRFTransformer<CrossBrfValidationReportingData> {

    private void transform(Sheet sheet, CrossBrfValidationReportingData data) {
        getCell(sheet, "G8").setCellValue(data.getMbillDynamicsBalance());
        getCell(sheet, "G9").setCellValue(data.getTermDynamicsBalance());
        getCell(sheet, "G10").setCellValue(data.getCallDynamicsBalance());
        getCell(sheet, "G11").setCellValue(data.getNcdDynamicsBalance());
        getCell(sheet, "G12").setCellValue(data.getCurrentDynamicsBalance());
        getCell(sheet, "G13").setCellValue(data.getSavingsDynamicsBalance());


        getCell(sheet, "H8").setCellValue(data.getMbillTreasuryBalance());
        getCell(sheet, "H9").setCellValue(data.getTermTreasuryBalance());
        getCell(sheet, "H10").setCellValue(data.getCallTreasuryBalance());
        getCell(sheet, "H11").setCellValue(data.getNcdTreasuryBalance());
        getCell(sheet, "H12").setCellValue(data.getCurrentTreasuryBalance());
        getCell(sheet, "H13").setCellValue(data.getSavingsTreasuryBalance());

    }

    @Override
    public void transform(Sheet sheet, List<CrossBrfValidationReportingData> dataset) {
        transform(sheet, dataset.get(0));
    }

}
