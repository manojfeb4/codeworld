package com.neobank.regulatory.reporting.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class BankReportingForms {

    public static final String BRF = "BRF-";

    public static final String BRF_00 = "000";

    public static final String BRF_01 = "001";

    public static final String BRF_02 = "002";

    public static final String BRF_04 = "004";

    public static final String BRF_05 = "005";

    public static final String BRF_08 = "008";

    public static final String BRF_09 = "009";

    public static final String BRF_11 = "011";

    public static final String BRF_33 = "033";

    public static final String BRF_34 = "034";

    public static final String BRF_35 = "035";

    public static final String BRF_38 = "038";

    public static final String BRF_40 = "040";

    public static final String BRF_46 = "046";

    public static final String BRF_51 = "051";

    public static final String BRF_52 = "052";

    public static final String BRF_53 = "053";

    public static final String BRF_13 = "013";

    public static final String BRF_06 = "006";

    public static final String BRF_60 = "060";

    public static final String BRF_67 = "067";


    public static final String BRF_68 = "068";

    public static final String BRF_93 = "093";


    public static final String HTTPS_PROTOCOL = "https";

}
