package com.neobank.regulatory.reporting.brf.brf00;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.config.CrossBrfValidationConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.entity.BusinessAccountBalance;
import com.neobank.regulatory.reporting.entity.TreasuryInvestment;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import com.neobank.regulatory.reporting.model.IncomeExpenseReportingData;
import com.neobank.regulatory.reporting.model.CrossBrfValidationReportingData;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.AnalyticsAccountInfoRepository;
import com.neobank.regulatory.reporting.repository.InvestmentRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import static com.neobank.regulatory.reporting.model.AccountType.CURRENT_ACCOUNT;
import static com.neobank.regulatory.reporting.model.AccountType.REGULAR_SAVINGS;

import static com.neobank.regulatory.reporting.model.InvestmentProduct.*;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_00;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static java.time.format.DateTimeFormatter.ISO_DATE;


@Slf4j
@Component
public class BRF00Processor extends AbstractBRFProcessor {

    private final BRF00Transformer brf00Transformer;
    private final AccountClosingBalanceRepository accountClosingBalanceRepository;


    private final AccountsClosingBalanceService accountsClosingBalanceService;
    private final InvestmentRepository investmentRepository;
    private final AnalyticsAccountInfoRepository analyticsAccountInfoRepository;


    private final CrossBrfValidationConfig crossBrfValidationConfig;


    public BRF00Processor(BRF00Transformer brf00Transformer,
                          AccountClosingBalanceRepository accountClosingBalanceRepository,
                          AccountsClosingBalanceService accountClosingBalanceService,
                          CrossBrfValidationConfig crossBrfValidationConfig,
                          InvestmentRepository investmentRepository,
                          AnalyticsAccountInfoRepository analyticsAccountInfoRepository) {
        this.brf00Transformer = brf00Transformer;
        this.accountClosingBalanceRepository = accountClosingBalanceRepository;
        this.accountsClosingBalanceService = accountClosingBalanceService;
        this.crossBrfValidationConfig = crossBrfValidationConfig;
        this.investmentRepository = investmentRepository;
        this.analyticsAccountInfoRepository = analyticsAccountInfoRepository;

    }

    @Override
    public String getBrfId() {
        return BRF + BRF_00;
    }

    @Override
    public BRFTransformer<CrossBrfValidationReportingData> getBrfTransformer() {
        return brf00Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return null;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();

        brf00Transformer.transform(wb.getSheetAt(0), List.of(reportingData(reportingDate)));

        log.info("{} generated successfully.", getBrfId());
    }

    private List<AccountClosingBalance> getClosingBalanceForAccounts(LocalDate reportingDate) {
        return accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(reportingDate);
    }


    private double closingBalance(List<AccountClosingBalance> accounts, ClosingBalanceQueryKey queryKey) {
        return NumberUtils.roundOffValue(accountsClosingBalanceService.closingBalance(accounts, queryKey));
    }

    private List<BusinessAccountBalance> getAccountBalanceInfo(LocalDate reportingDate, String accountType){
        return analyticsAccountInfoRepository.getSumOfAccountBalance(reportingDate, accountType);

    }

    private double getTotalAccountBalance(List<BusinessAccountBalance> accountBalances){
        log.debug("account balances: " + Arrays.deepToString(accountBalances.toArray()));
        return NumberUtils.roundOffValue(accountBalances.stream()
                .mapToDouble(BusinessAccountBalance::getAccountBalance).sum());

    }

    private List<TreasuryInvestment> getTreasuryInvestmentInfo(LocalDate reportingDate, String productName){
        return investmentRepository.findTreasuryInvestmentByDateEqualsAndProductEquals(reportingDate.format(ISO_DATE), productName);

    }

    private double productBookValue(List<TreasuryInvestment> investments){
        return NumberUtils.roundOffValue(
                investments.stream().mapToDouble(TreasuryInvestment::getBookValue).sum());

    }


    private CrossBrfValidationReportingData reportingData(LocalDate reportingDate) {
        var accounts = getClosingBalanceForAccounts(reportingDate);

        log.debug("accounts: " + Arrays.deepToString(accounts.toArray()));
        

        return CrossBrfValidationReportingData.builder()
                .mbillDynamicsBalance(closingBalance(accounts, crossBrfValidationConfig.getMbillKeys()))
                .callDynamicsBalance(closingBalance(accounts, crossBrfValidationConfig.getCallDepositKeys()))
                .termDynamicsBalance(closingBalance(accounts, crossBrfValidationConfig.getTermDepositKeys()))
                .ncdDynamicsBalance(closingBalance(accounts, crossBrfValidationConfig.getNcdInvestmentKeys()))
                .currentDynamicsBalance(closingBalance(accounts, crossBrfValidationConfig.getCurrentAccountKeys()))
                .savingsDynamicsBalance(closingBalance(accounts, crossBrfValidationConfig.getRegularSavingKeys()))
                .mbillTreasuryBalance(productBookValue(getTreasuryInvestmentInfo(reportingDate, MBILL.getCode())))
                .callTreasuryBalance(productBookValue(getTreasuryInvestmentInfo(reportingDate, CALL_DEPOSIT.getCode())))
                .termTreasuryBalance(productBookValue(getTreasuryInvestmentInfo(reportingDate, TERM_DEPOSIT.getCode())))
                .ncdTreasuryBalance(productBookValue(getTreasuryInvestmentInfo(reportingDate, NCD.getCode())))
                .currentTreasuryBalance(getTotalAccountBalance(getAccountBalanceInfo(reportingDate, CURRENT_ACCOUNT.getType())))
                .savingsTreasuryBalance(getTotalAccountBalance(getAccountBalanceInfo(reportingDate, REGULAR_SAVINGS.getType())))
                .build();
    }

}
