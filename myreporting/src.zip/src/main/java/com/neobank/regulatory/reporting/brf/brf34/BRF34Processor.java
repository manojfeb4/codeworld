package com.neobank.regulatory.reporting.brf.brf34;


import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.brf.services.GTreasuryService;
import com.neobank.regulatory.reporting.entity.TreasuryInvestment;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.InvestmentRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static com.neobank.regulatory.reporting.model.InvestmentProduct.*;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_34;
import static java.lang.String.format;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component
public class BRF34Processor extends AbstractBRFProcessor {

    private static final String UNITED_ARAB_EMIRATES = "United Arab Emirates";

    private static final String C_D = "C%d";

    private static final String D_D = "D%d";

    private static final String H_D = "H%d";

    private final BRF34Transformer brf34Transformer;

    private final InvestmentRepository investmentRepository;

    private final GTreasuryService gTreasuryService;

    public BRF34Processor(BRF34Transformer brf34Transformer, InvestmentRepository investmentRepository,
                          GTreasuryService gTreasuryService) {
        this.brf34Transformer = brf34Transformer;
        this.investmentRepository = investmentRepository;
        this.gTreasuryService = gTreasuryService;
    }

    @Override
    public String getBrfId() {
        return BRF + BRF_34;
    }

    @Override
    public BRFTransformer<TreasuryInvestment> getBrfTransformer() {
        return brf34Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return investmentRepository;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {

        log.info("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();
        updateSheet(wb.getSheetAt(0), reportingDate);

        log.info("{} generated successfully.", getBrfId());
    }

    private void updateSheet(Sheet sheet, LocalDate reportingDate) {

        var totalBookValuesForBanksAndProducts = investmentRepository
                .getTotalBookValueGroupByHeadOfficeCountryAndBankAndProductForCountry(UNITED_ARAB_EMIRATES,
                        reportingDate.format(ISO_DATE), NCD.getCode(), TERM_DEPOSIT.getCode(),
                        CALL_DEPOSIT.getCode());


        log.debug("Fetched Total {} Domestic and Foreign Banks' Products Records",
                totalBookValuesForBanksAndProducts.size());
        var totalBookValueForDomesticBankByProduct = gTreasuryService.getTotalBookValueGroupByBankAndProduct(
                totalBookValuesForBanksAndProducts, s -> s.equals(UNITED_ARAB_EMIRATES));

        log.debug("Domestic Products Records : {}", totalBookValueForDomesticBankByProduct);
        var totalBookValueForForeignBankByProduct = gTreasuryService.getTotalBookValueGroupByBankAndProduct(
                totalBookValuesForBanksAndProducts, s -> !s.equals(UNITED_ARAB_EMIRATES));

        log.debug("Foreign Products Records : {}", totalBookValueForForeignBankByProduct);

        addRows(sheet, totalBookValueForDomesticBankByProduct, 11);
        addRows(sheet, totalBookValueForForeignBankByProduct, 43);


    }

    private void addRows(Sheet sheet, Map<String, Map<String, Double>> data, int row) {
        AtomicInteger dRow = new AtomicInteger(row);

        log.debug("allBankBalances : {}", data);
        var nonZeroBankBalances = data.entrySet().stream()
                .filter(e -> e.getValue().values().stream().anyMatch(v -> v > 0))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        log.debug("nonZeroBankBalances : {}", nonZeroBankBalances);
        nonZeroBankBalances.forEach((bank, products) -> {


            getCell(sheet, format(C_D, dRow.get())).setCellValue(bank);

            products.entrySet().stream()
                    .filter(e -> e.getValue() > 0.00)
                    .forEach(e -> {

                        String col = e.getKey().equals("TERM") ? D_D : H_D;

                        var amountValue = NumberUtils.roundOffValue(e.getValue());
                        getCell(sheet, format(col, dRow.get())).setCellValue(amountValue);

                    });

            dRow.getAndAdd(1);
        });

    }

}
