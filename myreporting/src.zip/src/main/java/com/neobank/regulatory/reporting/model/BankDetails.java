package com.neobank.regulatory.reporting.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class BankDetails {

    private String bankName;

    private String countryOfBranch;

    private String countryOfHeadOffice;

}
