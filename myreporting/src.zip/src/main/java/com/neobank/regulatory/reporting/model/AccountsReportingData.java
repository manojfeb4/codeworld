package com.neobank.regulatory.reporting.model;

import lombok.Builder;
import lombok.Data;

import java.text.DecimalFormat;


@Data
@Builder
public class AccountsReportingData {

    /**
     * Cash in hand in AED ('000)
     */
    private double cashInHand;
    /**
     * State reserve held at CB in AED ('000)
     */
    private double reserveHeldCB;
    /**
     * Other balances in AED ('000)
     */
    private double otherBalances;
    /**
     * Repoed to UAE Central Bank (gross)
     */
    private double repoedToUAECB;
    /**
     * Due from overseas BR of national banks/ Banking Subs.
     */
    private double overseasBRNB;
    /**
     * Money at call and short notice, placements on demand and remaining balances
     * held with other resident banks
     */
    private double callAccountBookValue;
    /**
     * Interbank placements with other resident banks
     */
    private double interbankPlacements;
    /**
     * Other term placements (loans)
     */
    private double otherTermPlacements;
    /**
     * Lending covered by repurchase agreements
     */
    private double lendingCoveredRepurchaseAgreements;
    /**
     * Debt securities
     */
    private double equities1;
    /**
     * Equities
     */
    private double debtSecurities1;
    /**
     * Debt securities
     */
    private double debtSecurities2;
    /**
     * Equities
     */
    private double equities2;
    /**
     * Assets Held to Maturity (M-Bills) in AED ('000)
     */
    private double assetsHeldMBills;
    /**
     * Investment in subsidiaries (Cost or fair value)
     */
    private double investmentSubsidiaries;
    /**
     * Investment in affiliates (Cost or fair value)
     */
    private double investmentAffiliates;
    /**
     * Net Fixed Assets - Business premises including staff premises in AED ('000)
     */
    private double netFixedAsset1;
    /**
     * Net Fixed Assets - Furniture and fixtures in AED ('000)
     */
    private double netFixedAsset2;
    /**
     * Capital work in progress
     */
    private double capitalWorkInProgress;
    /**
     * Interest receivable
     */
    private double interestReceivable1;
    /**
     * Prepaid Expenses
     */
    private double prepaidExpenses;
    /**
     * Interest receivable
     */
    private double interestReceivable2;
    /**
     * Dividend receivables/Others
     */
    private double dividendReceivable;
    /**
     * Market value Forward contracts (including FX swaps)
     */
    private double marketValueForwardContacts;
    /**
     * Market value Financial Futures
     */
    private double marketValueFinancialFutures;
    /**
     * Market value Credit derivatives
     */
    private double marketValueCreditDerivatives;


    String toString(double amount) {
        final DecimalFormat df = new DecimalFormat("0.00");
        return df.format(Double.valueOf(amount));
    }

}
