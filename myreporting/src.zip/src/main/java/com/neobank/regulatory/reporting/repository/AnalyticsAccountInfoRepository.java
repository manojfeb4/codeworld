package com.neobank.regulatory.reporting.repository;

import com.neobank.regulatory.reporting.entity.BusinessAccountBalance;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface AnalyticsAccountInfoRepository
        extends CrudRepository<BusinessAccountBalance, String>, ReportingRepository {

    @Query(nativeQuery = true)
    List<BusinessAccountBalance> getTop15ResidentDepositors(LocalDate reportingDate);

    @Query(nativeQuery = true)
    List<BusinessAccountBalance> getTop15NonResidentDepositors(LocalDate reportingDate);

    @Query(nativeQuery = true)
    List<BusinessAccountBalance> getSumOfAccountBalance(LocalDate reportingDate, String accountType);

}
