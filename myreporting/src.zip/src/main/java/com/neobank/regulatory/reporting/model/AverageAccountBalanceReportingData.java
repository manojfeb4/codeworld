package com.neobank.regulatory.reporting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AverageAccountBalanceReportingData {


    private double totalAverageGovtDemand;
    private double totalAverageGovtSavings;

    private double totalAverageOtherDemand;
    private double totalAverageOtherSavings;


}
