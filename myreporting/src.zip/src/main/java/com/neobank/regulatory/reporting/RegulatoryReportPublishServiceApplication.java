package com.neobank.regulatory.reporting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@EnableConfigurationProperties
@SpringBootApplication(scanBasePackages = {"com.neobank"})
public class RegulatoryReportPublishServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(RegulatoryReportPublishServiceApplication.class, args);
    }

}
