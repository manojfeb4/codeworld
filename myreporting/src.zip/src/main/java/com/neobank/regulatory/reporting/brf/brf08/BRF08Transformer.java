package com.neobank.regulatory.reporting.brf.brf08;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.model.LiquidAssetsRatio;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class BRF08Transformer implements BRFTransformer<LiquidAssetsRatio> {

    private void transform(Sheet sheet, LiquidAssetsRatio data) {
        getCell(sheet, "D8").setCellValue(data.getPhysicalCashInHand());
        getCell(sheet, "D9").setCellValue(data.getStatutoryReservesCB());
        getCell(sheet, "D10").setCellValue(data.getFreeOtherAccountBalancesCB());
        getCell(sheet, "D14").setCellValue(data.getGovernmentPubliclyTradedDebtSecurities());
        getCell(sheet, "E21").setCellValue(data.getTotalLiabilities());
    }

    @Override
    public void transform(Sheet sheet, List<LiquidAssetsRatio> dataset) {
        transform(sheet, dataset.get(0));
    }

}
