package com.neobank.regulatory.reporting.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Data
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountClosingBalance {

    @EmbeddedId
    private MainAccountProductId id;

    @Column(name = "SUM_CLOSING_BALANCE")
    private double closingBalance;

}

