package com.neobank.regulatory.reporting.brf.brf67;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.OutstandingBalanceInfo;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class BRF67Transformer implements BRFTransformer<OutstandingBalanceInfo> {
    private static List<String> nationalityTypeList = List.of("SAME", "FILLER", "OTHER");

    public void transform(Sheet sheet, List<OutstandingBalanceInfo> outstandingBalanceList) {

        int startColNum = 3;
        int startRowNum = 18;


        outstandingBalanceList.stream().forEach(outstandingBalanceInfo -> {
                    var nationalityType = outstandingBalanceInfo.getOutstandingBalanceId().getNationalityType();
                    var sizeCategory = outstandingBalanceInfo.getOutstandingBalanceId().getSizeCategory();
                    var numberOfAccounts = outstandingBalanceInfo.getNumberOfAccounts();
                    var totalAccountBalance = outstandingBalanceInfo.getTotalAccountBalance();
                    var dRow = startRowNum + sizeCategory;
                    var dCol = nationalityTypeList.indexOf(nationalityType) + startColNum;

                    log.debug("sizeCategory: {}, numberOfAccounts: {}, sumOfAccountBalance: {}, row: {}", sizeCategory,
                            numberOfAccounts, totalAccountBalance, dRow);

                    getCell(sheet, dRow, dCol).setCellValue(numberOfAccounts);
                    getCell(sheet, dRow, dCol + 1).setCellValue(NumberUtils.roundOffValue(totalAccountBalance));
                }

        );

    }

}
