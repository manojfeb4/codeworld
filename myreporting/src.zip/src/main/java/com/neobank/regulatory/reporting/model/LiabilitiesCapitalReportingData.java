package com.neobank.regulatory.reporting.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LiabilitiesCapitalReportingData {

    /**
     * Private sector - demand
     */
    private long countOfDemands;
    /**
     * Private Sector - Demand
     */
    private double demands;
    /**
     * Private sector - savings
     */
    private long countOfSavings;
    /**
     * Private Sector - Savings
     */
    private double savings;
    /**
     * Money at call and short notice, borrowing on demand and remaining balances
     */
    private double moneyBorrowingRemainingBalance;
    /**
     * Interbank borrowings
     */
    private double interbankBorrowing;
    /**
     * Other term borrowings
     */
    private double otherTermBorrowings;
    /**
     * Borrowings under repurchase agreement
     */
    private double borrowingUnderRepurchase;
    /**
     * Staff benefits (pension, ESB etc)
     */
    private double staffBenefits;
    /**
     * Other Provisions
     */
    private double otherProvisions;
    /**
     * Interest payable on deposits/ other liabilities
     */
    private double interestPayable;
    /**
     * Income tax liability
     */
    private double incomeTaxLiability;
    /**
     * Accounts payable and sundry creditors
     */
    private double accountsPayable;
    /**
     * Acceptances
     */
    private double acceptances;
    /**
     * All Other Borrowings
     */
    private double allOtherBorrowings;
    /**
     * Share Capital
     */
    private double shareCapital;
    /**
     * Treasury shares held
     */
    private double treasuryShares;
    /**
     * Statutory/ legal reserves
     */
    private double legalReserves;
    /**
     * Accumulated other comprehensive income
     */
    private double otherComprehensiveIncome;
    /**
     * Other reserves (incl. IFRS 9 reserves)
     */
    private double otherReserves;
    /**
     * Retained earnings
     */
    private double retainedEarnings;
    /**
     * Current Year Profit/(loss)
     */
    private double currentYearProfit;
    /**
     * Instruments such as Perpetual Notes
     */
    private double instrumentsPerpetual;
}
