package com.neobank.regulatory.reporting.services;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.neobank.regulatory.reporting.config.AzureStorageAccountProperties;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Slf4j
@Component
@RequiredArgsConstructor
public class AzureStorageAccountConnectorService {

    private final BlobContainerClientBuilder blobContainerClientBuilder;

    private final AzureStorageAccountProperties azureStorageAccountProperties;


    public void uploadExcel(File fileToUpload, String fileName, TransformationContext payloadData) {
        if (!azureStorageAccountProperties.isEnabled()) {
            return;
        }
        String date = DateTimeFormatter.ofPattern("yyyy-MM-dd").format(payloadData.getReportingToDate());
        String blobName = fileName + "/" + fileName + "_" + date + "_" + payloadData.getEncodedKey() + ".xls";
        BlobContainerClient blobContainerClient = blobContainerClientBuilder.buildClient();
        BlobClient blobClient = blobContainerClient.getBlobClient(blobName);


        log.info("Uploading the file into the container from a file: " + blobName);
        String fileNameToUpload = fileToUpload.toPath().toString();
        blobClient.uploadFromFile(fileToUpload.toPath().toString(), true);


        log.info("File {} uploaded successfully" + fileNameToUpload);

    }


}
