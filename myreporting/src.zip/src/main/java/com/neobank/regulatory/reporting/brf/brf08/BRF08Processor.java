package com.neobank.regulatory.reporting.brf.brf08;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.config.LiquidAssetsRatioConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.entity.ProductIssueRatingBookValue;
import com.neobank.regulatory.reporting.model.LiquidAssetsRatio;
import com.neobank.regulatory.reporting.model.LiquidAssetsRatioQueryKey;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.ProductIssueRatingBookValueRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.services.ProductsBookValueService;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_08;

@Slf4j
@Component
public class BRF08Processor extends AbstractBRFProcessor {

    private final BRF08Transformer brf08Transformer;

    private final AccountClosingBalanceRepository accountClosingBalanceRepository;

    private final ProductIssueRatingBookValueRepository productIssueRatingBookValueRepository;

    private final LiquidAssetsRatioConfig liquidAssetsRatioConfig;

    private final AccountsClosingBalanceService accountsClosingBalanceService;

    private final ProductsBookValueService productsBookValueService;

    public BRF08Processor(BRF08Transformer brf08Transformer,
                          AccountClosingBalanceRepository accountClosingBalanceRepository,
                          ProductIssueRatingBookValueRepository productIssueRatingBookValueRepository,
                          LiquidAssetsRatioConfig liquidAssetsRatioConfig,
                          AccountsClosingBalanceService accountsClosingBalanceService,
                          ProductsBookValueService productsBookValueService) {
        this.brf08Transformer = brf08Transformer;
        this.accountClosingBalanceRepository = accountClosingBalanceRepository;
        this.productIssueRatingBookValueRepository = productIssueRatingBookValueRepository;
        this.liquidAssetsRatioConfig = liquidAssetsRatioConfig;
        this.accountsClosingBalanceService = accountsClosingBalanceService;
        this.productsBookValueService = productsBookValueService;
    }

    @Override
    public String getBrfId() {
        return BRF + BRF_08;
    }

    @Override
    public BRFTransformer<LiquidAssetsRatio> getBrfTransformer() {
        return brf08Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return null;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();

        brf08Transformer.transform(wb.getSheetAt(0), List.of(reportingData(reportingDate)));

        log.info("{} generated successfully.", getBrfId());
    }

    private List<AccountClosingBalance> getClosingBalanceForAccounts(LocalDate reportingDate) {
        return accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(reportingDate);
    }

    private List<ProductIssueRatingBookValue> getBookValuePerProductPerIssueRating(LocalDate reportingDate) {
        return productIssueRatingBookValueRepository.getIssueRatingsForProduct(reportingDate);
    }

    private double productBookValue(List<ProductIssueRatingBookValue> bookValues, LiquidAssetsRatioQueryKey queryKey) {
        return NumberUtils.roundOffValue(productsBookValueService.liquidAssetsRatio(bookValues, queryKey));
    }

    private double closingBalance(List<AccountClosingBalance> accounts, LiquidAssetsRatioQueryKey queryKey) {
        return NumberUtils.roundOffValue(accountsClosingBalanceService.liquidAssetsRatio(accounts, queryKey));
    }

    private LiquidAssetsRatio reportingData(LocalDate reportingDate) {
        var accounts = getClosingBalanceForAccounts(reportingDate);
        var bookValues = getBookValuePerProductPerIssueRating(reportingDate);
        return LiquidAssetsRatio.builder()
                .physicalCashInHand(closingBalance(accounts, liquidAssetsRatioConfig.getPhysicalCashInHand()))
                .statutoryReservesCB(closingBalance(accounts, liquidAssetsRatioConfig.getStatutoryReservesCB()))
                .freeOtherAccountBalancesCB(
                        closingBalance(accounts, liquidAssetsRatioConfig.getFreeOtherAccountBalancesCB()))
                .governmentPubliclyTradedDebtSecurities(productBookValue(bookValues,
                        liquidAssetsRatioConfig.getGovernmentPubliclyTradedDebtSecurities()))
                .totalLiabilities(closingBalance(accounts, liquidAssetsRatioConfig.getTotalLiabilities())).build();
    }

}
