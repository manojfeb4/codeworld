package com.neobank.regulatory.reporting.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CrossBrfValidationReportingData {


    private double mbillDynamicsBalance;
    private double termDynamicsBalance;
    private double callDynamicsBalance;
    private double ncdDynamicsBalance;
    private double currentDynamicsBalance;
    private double savingsDynamicsBalance;

    private double mbillTreasuryBalance;
    private double termTreasuryBalance;
    private double callTreasuryBalance;
    private double ncdTreasuryBalance;
    private double currentTreasuryBalance;
    private double savingsTreasuryBalance;



}
