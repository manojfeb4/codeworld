package com.neobank.regulatory.reporting.brf.brf01;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.model.AccountsReportingData;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class BRF01Transformer implements BRFTransformer<AccountsReportingData> {

    private void transform(Sheet sheet, AccountsReportingData data) {
        getCell(sheet, "F12").setCellValue(data.getCashInHand());
        getCell(sheet, "F13").setCellValue(data.getReserveHeldCB());
        getCell(sheet, "F15").setCellValue(data.getOtherBalances());
        getCell(sheet, "F17").setCellValue(data.getRepoedToUAECB());
        getCell(sheet, "F21").setCellValue(data.getOverseasBRNB());
        getCell(sheet, "F24").setCellValue(data.getCallAccountBookValue());
        getCell(sheet, "F25").setCellValue(data.getInterbankPlacements());
        getCell(sheet, "F26").setCellValue(data.getOtherTermPlacements());
        getCell(sheet, "F29").setCellValue(data.getLendingCoveredRepurchaseAgreements());
        getCell(sheet, "F36").setCellValue(data.getDebtSecurities1());
        getCell(sheet, "F37").setCellValue(data.getEquities1());
        getCell(sheet, "F41").setCellValue(data.getDebtSecurities2());
        getCell(sheet, "F42").setCellValue(data.getEquities2());
        getCell(sheet, "F43").setCellValue(data.getAssetsHeldMBills());
        getCell(sheet, "F45").setCellValue(data.getInvestmentSubsidiaries());
        getCell(sheet, "F46").setCellValue(data.getInvestmentAffiliates());
        getCell(sheet, "F68").setCellValue(data.getNetFixedAsset1());
        getCell(sheet, "F70").setCellValue(data.getNetFixedAsset2());
        getCell(sheet, "F72").setCellValue(data.getCapitalWorkInProgress());
        getCell(sheet, "F75").setCellValue(data.getInterestReceivable1());
        getCell(sheet, "F76").setCellValue(data.getPrepaidExpenses());
        getCell(sheet, "F78").setCellValue(data.getInterestReceivable2());
        getCell(sheet, "F81").setCellValue(data.getDividendReceivable());
        getCell(sheet, "F84").setCellValue(data.getMarketValueForwardContacts());
        getCell(sheet, "F87").setCellValue(data.getMarketValueFinancialFutures());
        getCell(sheet, "F88").setCellValue(data.getMarketValueCreditDerivatives());
    }

    @Override
    public void transform(Sheet sheet, List<AccountsReportingData> dataset) {
        transform(sheet, dataset.get(0));
    }

}
