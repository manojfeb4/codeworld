package com.neobank.regulatory.reporting.repository;

import com.neobank.regulatory.reporting.entity.AverageAccountBalanceInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountBalanceRepository extends CrudRepository<AverageAccountBalanceInfo, String>, ReportingRepository {

    @Query(nativeQuery = true)
    List<AverageAccountBalanceInfo> getAverageAccountBalance(String reportingFromDate, String reportingToDate,
                                                             List<String> accountState, List<String> accountType);

}
