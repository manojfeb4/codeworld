package com.neobank.regulatory.reporting.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Date;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AnalyticsAccountId implements Serializable {

    @Column(name = "ACCOUNT_ID")
    private String accountId;

    private Date loadDate;


}
