package com.neobank.regulatory.reporting.brf.brf04;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.config.IncomeExpenseAccountsConfig;
import com.neobank.regulatory.reporting.entity.AccountClosingBalance;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import com.neobank.regulatory.reporting.model.IncomeExpenseReportingData;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AccountClosingBalanceRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.services.AccountsClosingBalanceService;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_04;

@Slf4j
@Component
public class BRF04Processor extends AbstractBRFProcessor {

    private final BRF04Transformer brf04Transformer;
    private final AccountClosingBalanceRepository accountClosingBalanceRepository;


    private final AccountsClosingBalanceService accountsClosingBalanceService;


    private final IncomeExpenseAccountsConfig incomeExpenseAccountsConfig;


    public BRF04Processor(BRF04Transformer brf04Transformer,
                          AccountClosingBalanceRepository accountClosingBalanceRepository,
                          AccountsClosingBalanceService accountClosingBalanceService,
                          IncomeExpenseAccountsConfig incomeExpenseAccountsConfig) {
        this.brf04Transformer = brf04Transformer;
        this.accountClosingBalanceRepository = accountClosingBalanceRepository;
        this.accountsClosingBalanceService = accountClosingBalanceService;
        this.incomeExpenseAccountsConfig = incomeExpenseAccountsConfig;

    }

    @Override
    public String getBrfId() {
        return BRF + BRF_04;
    }

    @Override
    public BRFTransformer<IncomeExpenseReportingData> getBrfTransformer() {
        return brf04Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return null;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.debug("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();

        brf04Transformer.transform(wb.getSheetAt(0), List.of(reportingData(reportingDate)));

        log.info("{} generated successfully.", getBrfId());
    }

    private List<AccountClosingBalance> getClosingBalanceForAccounts(LocalDate reportingDate) {
        return accountClosingBalanceRepository.getSumOfClosingBalanceForAccounts(reportingDate);
    }


    private double closingBalance(List<AccountClosingBalance> accounts, ClosingBalanceQueryKey queryKey) {
        return NumberUtils.roundOffValue(accountsClosingBalanceService.closingBalance(accounts, queryKey));
    }

    private IncomeExpenseReportingData reportingData(LocalDate reportingDate) {
        var accounts = getClosingBalanceForAccounts(reportingDate);
        log.debug("accounts: " + Arrays.deepToString(accounts.toArray()));

        return IncomeExpenseReportingData.builder().personalConsumerLoans(closingBalance(accounts, incomeExpenseAccountsConfig.getPersonalConsumerLoanKeys()))
                .carLoans(closingBalance(accounts, incomeExpenseAccountsConfig.getCarLoanKeys()))
                .overdraft(closingBalance(accounts, incomeExpenseAccountsConfig.getOverdraftKeys()))
                .creditCardLoans(closingBalance(accounts, incomeExpenseAccountsConfig.getCreditCardLoanKeys()))
                .realEstateHousingLoans(closingBalance(accounts, incomeExpenseAccountsConfig.getRealEstateHousingLoanKeys()))
                .smallBusinessLoans(closingBalance(accounts, incomeExpenseAccountsConfig.getSmallBusinessLoanKeys()))
                .centralBankCds(closingBalance(accounts, incomeExpenseAccountsConfig.getCentralBankCdKeys()))
                .interbankInterestIncomeFrom(closingBalance(accounts, incomeExpenseAccountsConfig.getInterbankInterestIncomeFromKeys()))
                .investmentIncome(closingBalance(accounts, incomeExpenseAccountsConfig.getInvestmentIncomeKeys()))
                .interestOrProfitIncome(closingBalance(accounts, incomeExpenseAccountsConfig.getInterestOrProfitIncomeKeys()))
                .privateSectorCorporate(closingBalance(accounts, incomeExpenseAccountsConfig.getPrivateSectorCorporateKeys()))
                .marginalLendingAndOverdraft(
                        closingBalance(accounts, incomeExpenseAccountsConfig.getMarginalLendingAndOverdraftKeys()))
                .interbankInterestExpensesPaidTo(closingBalance(accounts, incomeExpenseAccountsConfig.getInterbankInterestExpensesPaidToKeys()))
                .capitalMarketOtherBorrowings(closingBalance(accounts, incomeExpenseAccountsConfig.getCapitalMarketOtherBorrowingKeys()))
                .foreignExchangeContracts(closingBalance(accounts, incomeExpenseAccountsConfig.getForeignExchangeContractKeys()))
                .derivativesAndFinancialFutures(closingBalance(accounts, incomeExpenseAccountsConfig.getDerivativeAndFinancialFutureKeys()))
                .otherDerivatives(closingBalance(accounts, incomeExpenseAccountsConfig.getOtherDerivativeKeys()))
                .otherFeesIncome(
                        closingBalance(accounts, incomeExpenseAccountsConfig.getOtherFeesIncomeKeys()))
                .staffExpenses(closingBalance(accounts, incomeExpenseAccountsConfig.getStaffExpenseKeys()))
                .bonusExpenses(closingBalance(accounts, incomeExpenseAccountsConfig.getBonusExpenseKeys()))
                .premisesExpenses(closingBalance(accounts, incomeExpenseAccountsConfig.getPremisesExpenseKeys()))
                .itExpenses(
                        closingBalance(accounts, incomeExpenseAccountsConfig.getItExpenseKeys()))
                .depreciationAndAmortisation(closingBalance(accounts, incomeExpenseAccountsConfig.getDepreciationAndAmortisationKeys()))
                .otherOutsourcingExpenses(closingBalance(accounts, incomeExpenseAccountsConfig.getOtherOutsourcingExpenseKeys()))
                .build();
    }

}
