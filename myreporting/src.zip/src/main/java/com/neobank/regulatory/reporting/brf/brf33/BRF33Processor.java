package com.neobank.regulatory.reporting.brf.brf33;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.BusinessAccountBalance;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.AnalyticsAccountInfoRepository;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_33;

@Slf4j
@Component
public class BRF33Processor extends AbstractBRFProcessor {

    private final BRF33Transformer brf33Transformer;

    private final AnalyticsAccountInfoRepository analyticsAccountInfoRepository;

    public BRF33Processor(BRF33Transformer brf33Transformer,
                          AnalyticsAccountInfoRepository analyticsAccountInfoRepository) {
        this.brf33Transformer = brf33Transformer;
        this.analyticsAccountInfoRepository = analyticsAccountInfoRepository;
    }

    @Override
    public String getBrfId() {
        return BRF + BRF_33;
    }

    @Override
    public BRFTransformer<BusinessAccountBalance> getBrfTransformer() {
        return brf33Transformer;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return analyticsAccountInfoRepository;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        Sheet sheet = wb.getSheetAt(0);

        var reportingDate = payloadData.getReportingToDate();
        log.debug("Fetching top depositors for resident accounts");
        List<BusinessAccountBalance> bankingAndMonetaryDataListForResident = getTopDepositors(
                analyticsAccountInfoRepository, true, reportingDate);
        log.info("Fetched account details for residents: {}", bankingAndMonetaryDataListForResident);
        brf33Transformer.transform(sheet, bankingAndMonetaryDataListForResident);

        log.debug("Fetching top depositors for non resident accounts");
        List<BusinessAccountBalance> bankingAndMonetaryDataListForNonResident = getTopDepositors(
                analyticsAccountInfoRepository, false, reportingDate);
        log.info("Fetched account details for non residents: {}", bankingAndMonetaryDataListForNonResident);
        brf33Transformer.transform(sheet, bankingAndMonetaryDataListForNonResident);

    }

    private List<BusinessAccountBalance> getTopDepositors(AnalyticsAccountInfoRepository analyticsAccountInfoRepository,
                                                          boolean isResident, LocalDate reportingDate) {
        log.info("Fetching account details for resident: {}", isResident);
        return isResident ? analyticsAccountInfoRepository.getTop15ResidentDepositors(reportingDate)
                : analyticsAccountInfoRepository.getTop15NonResidentDepositors(reportingDate);
    }

}
