package com.neobank.regulatory.reporting.brf.brf13;

import com.neobank.regulatory.reporting.brf.AbstractBRFProcessor;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.ResidualMaturityInfo;
import com.neobank.regulatory.reporting.model.event.TransformationContext;
import com.neobank.regulatory.reporting.repository.ReportingRepository;
import com.neobank.regulatory.reporting.repository.ResidualMaturityRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.util.Arrays;

import static com.neobank.regulatory.reporting.model.InvestmentProduct.*;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF;
import static com.neobank.regulatory.reporting.util.BankReportingForms.BRF_13;
import static java.time.format.DateTimeFormatter.ISO_DATE;

@Slf4j
@Component

public class BRF13Processor extends AbstractBRFProcessor {

    private static final String UNITED_ARAB_EMIRATES = "United Arab Emirates";

    private final BRF13Transformer brf13Transformer;

    private final ResidualMaturityRepository residualMaturityRepository;

    public BRF13Processor(BRF13Transformer brf13Transformer, ResidualMaturityRepository residualMaturityRepository) {
        this.brf13Transformer = brf13Transformer;
        this.residualMaturityRepository = residualMaturityRepository;
    }

    @Override
    public String getBrfId() {
        return BRF + BRF_13;
    }

    @Override
    public ReportingRepository getReportingRepository() {
        return residualMaturityRepository;
    }

    @Override
    public BRFTransformer<ResidualMaturityInfo> getBrfTransformer() {
        return brf13Transformer;
    }

    @Override
    public void process(Workbook wb, TransformationContext payloadData) {
        log.info("Start processing {}.", getBrfId());
        var reportingDate = payloadData.getReportingToDate();
        var totalBookValueByResidualMaturity = residualMaturityRepository
                .getTotalBookValueByResidualMaturity(reportingDate.format(ISO_DATE), NCD.getCode(),
                        CALL_DEPOSIT.getCode(), TERM_DEPOSIT.getCode(), UNITED_ARAB_EMIRATES);

        log.info("Fetched Residual Maturity {} Banks' Products Records",
                totalBookValueByResidualMaturity.size());
        log.info("Reporting Date : {}", reportingDate.format(ISO_DATE));
        log.debug(Arrays.deepToString(totalBookValueByResidualMaturity.toArray()));
        var sheet = wb.getSheetAt(0);


        getBrfTransformer().transform(sheet, totalBookValueByResidualMaturity);

        log.info("{} generated successfully.", getBrfId());
    }

}
