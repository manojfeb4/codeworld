package com.neobank.regulatory.reporting.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import java.math.BigDecimal;


@NoArgsConstructor
@Data
@Entity
public class ResidualMaturityInfo {

    @EmbeddedId
    ResidualMaturityId residualMaturityId;

    @Column(name = "TOTALBOOKVALUE")
    private BigDecimal totalBookValue;

}
