package com.neobank.regulatory.reporting.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
@Data
@NoArgsConstructor
public class RemittanceInfo {

    @EmbeddedId
    RemittanceId remittanceId;

    @Column(name = "TOTAL_TRANSFERRED_AMOUNT")
    private double totalTransferredAmount;

}
