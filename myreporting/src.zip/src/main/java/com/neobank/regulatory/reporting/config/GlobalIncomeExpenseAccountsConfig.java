package com.neobank.regulatory.reporting.config;

import com.neobank.common.config.YamlPropertySourceFactory;
import com.neobank.regulatory.reporting.model.ClosingBalanceQueryKey;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Data
@Configuration
@ConfigurationProperties(prefix = "global-income-expense-accounts")
@PropertySource(value = "classpath:mapping/global-income-expense-accounts.yml", factory = YamlPropertySourceFactory.class)
public class GlobalIncomeExpenseAccountsConfig {

    private ClosingBalanceQueryKey interestIncomeKeys;
    private ClosingBalanceQueryKey investmentIncomeKeys;
    private ClosingBalanceQueryKey otherOperatingIncomeKeys;
    private ClosingBalanceQueryKey interestExpenseKeys;
    private ClosingBalanceQueryKey staffExpenseKeys;
    private ClosingBalanceQueryKey premisesExpenseKeys;
    private ClosingBalanceQueryKey depreciationAndAmortisationKeys;
    private ClosingBalanceQueryKey otherAdminAndGeneralExpenseKeys;


}
