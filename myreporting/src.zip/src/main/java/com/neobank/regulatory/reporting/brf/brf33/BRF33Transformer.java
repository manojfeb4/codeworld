package com.neobank.regulatory.reporting.brf.brf33;

import com.neobank.ods.schema.enums.Country;
import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.BusinessAccountBalance;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class BRF33Transformer implements BRFTransformer<BusinessAccountBalance> {

    private static final String UAE = "ARE";

    @Override
    public void transform(Sheet sheet, List<BusinessAccountBalance> bankingAndMonetaryDataList) {
        if (CollectionUtils.isEmpty(bankingAndMonetaryDataList)) {
            return;
        }
        int rowNumStart = bankingAndMonetaryDataList.get(0).getCountryOfIncorporation().equalsIgnoreCase(UAE) ? 8 : 27;

        fillBankAndMonetaryData(sheet, bankingAndMonetaryDataList, rowNumStart);
    }

    private void fillBankAndMonetaryData(Sheet sheet, List<BusinessAccountBalance> bankingAndMonetaryDataList,
                                         int rowNumStart) {
        for (BusinessAccountBalance businessAccountBalance : bankingAndMonetaryDataList) {
            setBankAndMonetaryData(sheet, rowNumStart, businessAccountBalance);
            rowNumStart++;
        }
    }

    private void setBankAndMonetaryData(Sheet sheet, int rowNum, BusinessAccountBalance bankingAndMonetaryData) {

        Cell cell = getCell(sheet, rowNum, 2);
        cell.setCellValue(bankingAndMonetaryData.getBusinessName());
        cell = getCell(sheet, rowNum, 3);
        try {
            Country country = Country.valueOf(bankingAndMonetaryData.getCountryOfIncorporation());
            cell.setCellValue(country.getCountryIso2());
        } catch (IllegalArgumentException e) {
            log.error("Invalid country received in data set: {} Setting as received",
                    bankingAndMonetaryData.getCountryOfIncorporation(), e);
            cell.setCellValue(bankingAndMonetaryData.getCountryOfIncorporation());
        }

        cell = getCell(sheet, rowNum, 4);
        cell.setCellValue(NumberUtils.roundOffValue(bankingAndMonetaryData.getAccountBalance()));
    }

}
