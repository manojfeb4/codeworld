package com.neobank.regulatory.reporting.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class IncomeExpenseReportingData {


    private double personalConsumerLoans;
    private double carLoans;
    private double overdraft;
    private double creditCardLoans;
    private double realEstateHousingLoans;
    private double smallBusinessLoans;

    private double centralBankCds;
    private double interbankInterestIncomeFrom;
    private double investmentIncome;
    private double interestOrProfitIncome;
    private double privateSectorCorporate;
    private double marginalLendingAndOverdraft;
    private double interbankInterestExpensesPaidTo;

    private double capitalMarketOtherBorrowings;
    private double foreignExchangeContracts;
    private double derivativesAndFinancialFutures;
    private double otherDerivatives;
    private double otherFeesIncome;

    private double staffExpenses;
    private double bonusExpenses;
    private double premisesExpenses;
    private double itExpenses;
    private double depreciationAndAmortisation;

    private double otherOutsourcingExpenses;


}
