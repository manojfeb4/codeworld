package com.neobank.regulatory.reporting.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@NoArgsConstructor
@Embeddable
public class RemittanceId implements Serializable {


    @Column(name = "RECIPIENT_COUNTRY")
    private String recipientCountry;

    @Column(name = "TRANSFER_PURPOSE")
    private String transferPurpose;

}
