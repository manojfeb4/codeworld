package com.neobank.regulatory.reporting.util;

import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

@UtilityClass
public class NumberUtils {

    private static final Integer ROUND_TO_PLACES = 2;

    public static double getAmountInThousands(String amountInString) {
        double amount = StringUtils.isNotEmpty(amountInString) ? Double.parseDouble(amountInString.replace(",", ""))
                : 0d;
        return getAmountInThousands(amount);
    }

    private static double getAmountInThousands(double amount) {
        if (Double.compare(amount, 0d) != 0) {
            double amountInThousand = amount / 1000;
            BigDecimal bd = BigDecimal.valueOf(amountInThousand);
            bd = bd.setScale(ROUND_TO_PLACES, RoundingMode.HALF_UP);
            return bd.doubleValue();
        }
        return 0d;
    }

    public static double fixValue(Double value) {
        return null == value ? 0.0d : getAmountInThousands(value);
    }

    public static double roundOffValue(double amount) {
        final DecimalFormat df = new DecimalFormat("0.00");
        return Double.parseDouble(df.format(Double.valueOf(amount)));

    }

}
