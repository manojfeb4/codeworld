package com.neobank.regulatory.reporting.brf.brf13;

import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.ResidualMaturityInfo;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class BRF13Transformer implements BRFTransformer<ResidualMaturityInfo> {
    private static final List<String> productValueList = List.of("NCD", "DEP");

    @Override
    public void transform(Sheet sheet, List<ResidualMaturityInfo> residualMaturityInfoList) {
        residualMaturityInfoList.stream().forEach(residualMaturityInfo -> {

                    var productValue = residualMaturityInfo.getResidualMaturityId().getProduct();
                    var startRow = 12;
                    var bucketValue = residualMaturityInfo.getResidualMaturityId().getBucket();
                    var dCol = bucketValue + 5;
                    var dRow = startRow + productValueList.indexOf(productValue);

                    var updatedTotalBookValue = residualMaturityInfo.getTotalBookValue().doubleValue() + getCell(sheet, dRow, dCol).getNumericCellValue();
                    log.debug("productValue: {}, bucketValue: {}, row: {}, col: {}", productValue, bucketValue, dRow, dCol);
                    log.debug("updatedTotalBookValue: {}", updatedTotalBookValue);

                    getCell(sheet, dRow, dCol).setCellValue(NumberUtils.roundOffValue(updatedTotalBookValue));
                }

        );

    }

}
