package com.neobank.regulatory.reporting.brf.brf68;


import com.neobank.regulatory.reporting.brf.BRFTransformer;
import com.neobank.regulatory.reporting.entity.EmirateDepositInfo;
import com.neobank.regulatory.reporting.util.NumberUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.neobank.ods.schema.enums.Emirate.*;
import static com.neobank.regulatory.reporting.model.AccountType.CURRENT_ACCOUNT;
import static com.neobank.regulatory.reporting.model.AccountType.REGULAR_SAVINGS;

@Component
@RequiredArgsConstructor
@Slf4j
public class BRF68Transformer implements BRFTransformer<EmirateDepositInfo> {
    private static final List<String> accountTypeList = List.of(CURRENT_ACCOUNT.getType(), REGULAR_SAVINGS.getType());

    public void transform(Sheet sheet, List<EmirateDepositInfo> emirateDepositInfoList) {

        int startColNum = 10;
        int startRowNum = 22;

        emirateDepositInfoList.stream().forEach(emirateDepositInfo -> {
                    int dCol = 0;

                    var registeredAddressEmirateList = List.of(ABU_DHABI.getValue(), DUBAI.getValue(), SHARJAH.getValue(),
                            AJMAN.getValue(), RAS_AL_KHAIMAH.getValue(), UMM_AL_QUWAIN.getValue(), FUJAIRAH.getValue());

                    var registeredAddressEmirate = emirateDepositInfo.getEmirateDepositId().getRegisteredAddressEmirate();
                    var accountType = emirateDepositInfo.getEmirateDepositId().getAccountType();
                    var dRow = accountTypeList.indexOf(accountType) + startRowNum;

                    var numberOfCustomers = getCell(sheet, dRow, 6).getNumericCellValue() + emirateDepositInfo.getNumberOfCustomers();
                    var numberOfAccounts = emirateDepositInfo.getNumberOfAccounts();
                    var totalAccountBalance = emirateDepositInfo.getTotalAccountBalance();
                    var registeredAddressEmirateIndex = registeredAddressEmirateList.indexOf(registeredAddressEmirate);
                    dCol = startColNum + (4 * registeredAddressEmirateIndex);

                    log.debug("registeredAddressEmirateIndex: {}, registeredAddressEmirate: {}, accountType: {}, numberOfAccounts: {}, sumOfAccountBalance: {}, row: {}",
                            registeredAddressEmirateIndex, registeredAddressEmirate, accountType, numberOfAccounts, totalAccountBalance, dRow);

                    getCell(sheet, dRow, 6).setCellValue(numberOfCustomers);
                    getCell(sheet, dRow, dCol).setCellValue(numberOfAccounts);
                    getCell(sheet, dRow, dCol + 1).setCellValue(NumberUtils.roundOffValue(totalAccountBalance));

                }

        );

    }


}


