package com.neobank.regulatory.reporting.repository;

import com.neobank.regulatory.reporting.entity.TreasuryInvestment;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InvestmentRepository extends CrudRepository<TreasuryInvestment, String>, ReportingRepository {

    @Query(nativeQuery = true)
    List<String[]> getTotalBookValueGroupByHeadOfficeCountryAndBankAndProductForCountry(String countryOfBranch,
                                                                                        String reportingDate,
                                                                                        String ncdProduct,
                                                                                        String termProduct,
                                                                                        String callProduct);

    @Query(nativeQuery = true)
    List<String[]> getTotalBookValueGroupByBranchAndHeadOfficeCountryAndBankAndProductNotForCountry(
            String countryOfBranch, String reportingDate, String ncdProduct, String termProduct,
            String callProduct);

    @Query(nativeQuery = true)
    List<TreasuryInvestment> findTreasuryInvestmentByDateEqualsAndProductEquals(String reportingDate, String product);

}
