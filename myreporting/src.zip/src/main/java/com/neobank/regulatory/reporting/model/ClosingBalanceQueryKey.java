package com.neobank.regulatory.reporting.model;

import lombok.Data;

import java.util.List;

@Data
public class ClosingBalanceQueryKey {

    private List<String> products;

    private List<String> accounts;
}
